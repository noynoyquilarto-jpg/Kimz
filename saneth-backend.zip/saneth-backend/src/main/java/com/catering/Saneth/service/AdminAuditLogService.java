package com.catering.Saneth.service;

import com.catering.Saneth.dto.response.AdminAuditLogResponse;
import com.catering.Saneth.model.AdminAuditLog;
import com.catering.Saneth.repository.AdminAuditLogRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AdminAuditLogService {

    private final AdminAuditLogRepo adminAuditLogRepo;

    public void record(String action, String targetType, Object targetId, String details) {
        recordForActor(getCurrentAdminEmail(), action, targetType, targetId, details);
    }

    public void recordForActor(String actor, String action, String targetType, Object targetId, String details) {
        String description = action.toLowerCase(java.util.Locale.ROOT).replace('_', ' ')
                + " - " + targetType.toLowerCase(java.util.Locale.ROOT).replace('_', ' ')
                + (targetId == null ? "" : " #" + targetId)
                + (details == null || details.isBlank() ? "" : ": " + details.trim());
        adminAuditLogRepo.save(AdminAuditLog.builder()
                .adminEmail(actor)
                .action(action)
                .targetType(targetType)
                .targetId(targetId != null ? String.valueOf(targetId) : null)
                .details(description.length() > 1000 ? description.substring(0, 1000) : description)
                .build());
    }

    public List<AdminAuditLogResponse> getRecentLogs() {
        return adminAuditLogRepo.findTop200ByOrderByCreatedAtDesc()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    private String getCurrentAdminEmail() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || authentication.getName() == null) {
            return "unknown";
        }
        return authentication.getName();
    }

    private AdminAuditLogResponse mapToResponse(AdminAuditLog log) {
        return AdminAuditLogResponse.builder()
                .id(log.getId())
                .adminEmail(log.getAdminEmail())
                .action(log.getAction())
                .targetType(log.getTargetType())
                .targetId(log.getTargetId())
                .details(log.getDetails())
                .createdAt(log.getCreatedAt())
                .build();
    }
}
