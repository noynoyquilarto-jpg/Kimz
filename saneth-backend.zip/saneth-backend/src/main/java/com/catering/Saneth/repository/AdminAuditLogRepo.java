package com.catering.Saneth.repository;

import com.catering.Saneth.model.AdminAuditLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AdminAuditLogRepo extends JpaRepository<AdminAuditLog, Long> {
    List<AdminAuditLog> findTop200ByOrderByCreatedAtDesc();
}
