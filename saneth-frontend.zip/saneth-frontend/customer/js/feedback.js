import { apiRequest, getQueryParam, safe, setResult, clearResult } from './customer-api.js';
import { initCustomerLayout } from './customer-layout.js';

initCustomerLayout();

const feedbackForm = document.getElementById('feedbackForm');
const feedbackResult = document.getElementById('feedbackResult');
const referenceInput = document.getElementById('bookingReference');
const emailInput = document.getElementById('email');
const submitButton = feedbackForm.querySelector('[type="submit"]');
let isSubmitting = false;

const ref = getQueryParam('ref');
if (ref) referenceInput.value = ref.trim();
emailInput.value = (getQueryParam('email') || '').trim();

feedbackForm?.addEventListener('submit', submitFeedback);

async function submitFeedback(event) {
  event.preventDefault();
  if (isSubmitting) return;
  referenceInput.value = referenceInput.value.trim();
  emailInput.value = emailInput.value.trim();
  if (!feedbackForm.reportValidity()) return;
  clearResult(feedbackResult);

  const form = new FormData(feedbackForm);
  const body = {
    bookingReference: form.get('bookingReference').trim(),
    email: form.get('email').trim(),
    rating: Number(form.get('rating')),
    comment: form.get('comment').trim()
  };

  isSubmitting = true;
  submitButton.disabled = true;
  submitButton.textContent = 'Submitting feedback...';
  feedbackForm.setAttribute('aria-busy', 'true');
  try {
    await apiRequest('/api/feedbacks', {
      method: 'POST',
      body: JSON.stringify(body)
    });

    feedbackForm.reset();
    setResult(feedbackResult, '<strong>Thank you for your feedback.</strong><br>Your review helps improve Saneth Catering.', 'success');
  } catch (error) {
    const message = /booking.*(not exist|not found)/i.test(error.message)
      ? 'No booking matches that reference and email. Copy the reference from your booking confirmation and use the email address entered when booking.'
      : error.message;
    setResult(feedbackResult, safe(message), 'error');
  } finally {
    isSubmitting = false;
    submitButton.disabled = false;
    submitButton.textContent = 'Submit feedback';
    feedbackForm.setAttribute('aria-busy', 'false');
  }
}
