package com.catering.Saneth.service;

import com.catering.Saneth.model.BookingPayment;
import com.catering.Saneth.repository.BookingPaymentRepo;
import com.catering.Saneth.repository.BookingRepo;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class AnalyticsServiceTest {
    @Test
    void installmentsAreCountedInPaymentMonthInChronologicalOrder() {
        var bookings = mock(BookingRepo.class);
        var payments = mock(BookingPaymentRepo.class);
        when(payments.findAll()).thenReturn(List.of(
                BookingPayment.builder().amount(300.0).createdAt(LocalDateTime.of(2026, 1, 2, 12, 0)).build(),
                BookingPayment.builder().amount(700.0).createdAt(LocalDateTime.of(2026, 2, 2, 12, 0)).build()));
        var service = new AnalyticsService(bookings, payments);
        assertThat(service.getDashboardAnalytics().getTotalSales()).isEqualTo(1000);
        var monthly = service.getMonthlySalesTrend();
        assertThat(monthly).extracting(row -> row.getMonth()).containsExactly("Jan 2026", "Feb 2026");
    }
}
