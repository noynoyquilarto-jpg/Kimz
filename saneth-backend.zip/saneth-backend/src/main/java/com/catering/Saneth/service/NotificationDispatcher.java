package com.catering.Saneth.service;

import com.catering.Saneth.model.EmailNotification;
import com.catering.Saneth.repository.EmailNotificationRepo;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.mail.javamail.*;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;
import org.slf4j.LoggerFactory;
import java.time.Instant;
import java.util.*;

@Service
public class NotificationDispatcher {
    private final EmailNotificationRepo repo;
    private final NotificationCipher cipher;
    private final JavaMailSender sender;
    private final MailIdentity identity;
    private final TransactionTemplate tx;
    private final boolean enabled;
    public NotificationDispatcher(EmailNotificationRepo repo, NotificationCipher cipher, JavaMailSender sender,
            MailIdentity identity, PlatformTransactionManager manager, @Value("${saneth.mail.enabled:true}") boolean enabled) {
        this.repo = repo; this.cipher = cipher; this.sender = sender; this.identity = identity; this.enabled = enabled;
        tx = new TransactionTemplate(manager); tx.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    }
    @Scheduled(fixedDelayString = "${saneth.mail.retry.poll-ms:5000}", initialDelayString = "${saneth.mail.retry.initial-delay-ms:5000}")
    public void dispatch() {
        if (!enabled) return;
        try {
            for (String id : repo.due(Instant.now(), PageRequest.of(0, 20))) deliver(id);
        } catch (RuntimeException error) {
            LoggerFactory.getLogger(getClass()).warn("Notification worker deferred ({})", error.getClass().getSimpleName());
        }
    }
    public void deliver(String id) {
        if (!enabled) return;
        EmailNotification n = tx.execute(s -> {
            var row = repo.lock(id).orElse(null);
            if (row == null || !List.of("QUEUED", "RETRY_PENDING", "SENDING").contains(row.getStatus())
                    || row.getNextAttemptAt().isAfter(Instant.now())) return null;
            if (row.getExpiresAt() != null && !row.getExpiresAt().isAfter(Instant.now())) {
                row.setStatus("EXPIRED"); row.setEncryptedContent(null); return null;
            }
            if (row.getAttempts() >= 12) { row.setStatus("FAILED"); row.setLeaseToken(null); return null; }
            row.setStatus("SENDING"); row.setAttempts(row.getAttempts() + 1);
            row.setLeaseToken(UUID.randomUUID().toString());
            row.setNextAttemptAt(Instant.now().plusSeconds(120));
            return row;
        });
        if (n == null || !enabled) return;
        String errorCode = null;
        try {
            String[] content = NotificationQueue.unpack(cipher.decrypt(n.getEncryptedContent()));
            var message = sender.createMimeMessage();
            // These notifications have no attachments: use only text/plain + text/html alternatives.
            var helper = new MimeMessageHelper(message, false, "UTF-8");
            identity.apply(helper); helper.setValidateAddresses(true); helper.setTo(content[0]); helper.setSubject(content[1]);
            var alternatives = new jakarta.mail.internet.MimeMultipart("alternative");
            var plain = new jakarta.mail.internet.MimeBodyPart();
            plain.setText(content[2], "UTF-8"); alternatives.addBodyPart(plain);
            var html = new jakarta.mail.internet.MimeBodyPart();
            html.setContent(content[3], "text/html; charset=UTF-8"); alternatives.addBodyPart(html);
            message.setContent(alternatives);
            message.setSentDate(new java.util.Date());
            message.setHeader("Auto-Submitted", "auto-generated");
            message.saveChanges();
            message.setHeader("Message-ID", "<saneth-" + n.getId() + "@" + identity.from().substring(identity.from().indexOf('@') + 1) + ">");
            // JavaMailSenderImpl calls saveChanges; preserve our stable ID through that call.
            sender.send(message);
        } catch (Exception error) {
            errorCode = error.getClass().getSimpleName();
            // Provider exception messages can contain addresses, credentials, or message bodies.
            LoggerFactory.getLogger(getClass()).warn("Notification {} ({}) SMTP attempt {} failed: {} ({})",
                    id, n.getKind(), n.getAttempts(), failureHint(error), errorCode);
        }
        final String failure = errorCode;
        tx.executeWithoutResult(s -> repo.lock(id).ifPresent(row -> {
            if (!Objects.equals(row.getLeaseToken(), n.getLeaseToken()) || !"SENDING".equals(row.getStatus())) return;
            row.setLeaseToken(null);
            if (failure == null) {
                row.setStatus("SMTP_ACCEPTED"); row.setAcceptedAt(Instant.now()); row.setLastError(null); row.setEncryptedContent(null);
                LoggerFactory.getLogger(getClass()).info("Notification {} accepted by SMTP; inbox delivery is unconfirmed", id);
            } else {
                row.setStatus(row.getAttempts() >= 12 ? "FAILED" : "RETRY_PENDING");
                row.setLastError(failure);
                row.setNextAttemptAt(Instant.now().plusSeconds(Math.min(3600, 15L * (1L << Math.min(row.getAttempts() - 1, 8)))));
                if (row.getExpiresAt() != null && !row.getExpiresAt().isAfter(Instant.now())) {
                    row.setStatus("EXPIRED"); row.setEncryptedContent(null);
                }
            }
        }));
    }

    private String failureHint(Throwable error) {
        Set<Throwable> seen = Collections.newSetFromMap(new IdentityHashMap<>());
        for (Throwable cause = error; cause != null && seen.add(cause); cause = cause.getCause()) {
            if (cause instanceof org.springframework.mail.MailAuthenticationException
                    || cause instanceof jakarta.mail.AuthenticationFailedException)
                return "check the SMTP account and Gmail App Password";
            if (cause instanceof javax.net.ssl.SSLException)
                return "check SMTP TLS and the certificate trust store";
            if (cause instanceof java.net.ConnectException || cause instanceof java.net.UnknownHostException
                    || cause instanceof java.net.SocketTimeoutException)
                return "check SMTP connectivity, DNS and timeouts";
        }
        return "check SMTP configuration and notification retry status";
    }
}
