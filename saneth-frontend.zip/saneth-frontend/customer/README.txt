Saneth Catering customer frontend

All existing customer pages and assets are preserved here.
See ../README.md for local startup, API configuration, tests, and Vercel deployment.
Customer home: /customer/customer-home.html
Customer registration, OTP, and sign-in: /customer/customer-login.html
