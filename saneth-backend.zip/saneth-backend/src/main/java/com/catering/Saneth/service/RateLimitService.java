package com.catering.Saneth.service;

import com.catering.Saneth.exception.RateLimitException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class RateLimitService {

    private final Map<String, Deque<Long>> attemptsByKey = new ConcurrentHashMap<>();
    private final java.util.function.LongSupplier clock;
    public RateLimitService() { this(System::currentTimeMillis); }
    RateLimitService(java.util.function.LongSupplier clock) { this.clock = clock; }

    public void check(HttpServletRequest request, String action, int maxAttempts, Duration window) {
        checkKey(action + ":ip:" + getClientIp(request), maxAttempts, window);
    }

    public void checkKey(String key, int maxAttempts, Duration window) {
        long now = clock.getAsLong();
        long windowStart = now - window.toMillis();

        Deque<Long> attempts = attemptsByKey.computeIfAbsent(key.toLowerCase(), ignored -> new ArrayDeque<>());

        synchronized (attempts) {
            while (!attempts.isEmpty() && attempts.peekFirst() <= windowStart) {
                attempts.removeFirst();
            }

            if (attempts.size() >= maxAttempts) {
                long seconds = Math.max(1, (attempts.peekFirst() + window.toMillis() - now + 999) / 1000);
                throw new RateLimitException("Too many requests. Please try again in " + seconds + " seconds.", seconds);
            }

            attempts.addLast(now);
        }
    }

    private String getClientIp(HttpServletRequest request) {
        String forwardedFor = request.getHeader("X-Forwarded-For");
        if (forwardedFor != null && !forwardedFor.isBlank()) {
            return forwardedFor.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }
}
