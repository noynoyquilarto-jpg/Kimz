package com.catering.Saneth.repository;

import com.catering.Saneth.model.MenuPackage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.w3c.dom.stylesheets.LinkStyle;

import java.awt.*;
import java.util.List;
import java.util.Optional;

public interface MenuPackageRepo extends JpaRepository<MenuPackage, Long> {
    @Query("SELECT DISTINCT p FROM MenuPackage p LEFT JOIN FETCH p.items")
    List<MenuPackage> findAllWithItems();

    @Query("SELECT DISTINCT p FROM MenuPackage p LEFT JOIN FETCH p.items WHERE p.id = :id")
    Optional<MenuPackage> findWithItemsById(@Param("id") Long id);

    List<MenuPackage> findByAvailableTrueAndPackagePriceLessThanEqualAndGoodForPaxGreaterThanEqual(
            Double budget,
            Integer numberOfPax
    );
}
