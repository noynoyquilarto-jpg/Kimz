import { apiRequest } from './customer-api.js';

const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const verifyForm = document.getElementById('verifyForm');
const verifiedStep = document.getElementById('verifiedStep');
const message = document.getElementById('message');
const value = id => document.getElementById(id).value;
const registrationKey = 'saneth_pending_registration';
let registration = readRegistration();
let otpMonitor = 0;
let resendTimer;
let redirectTimer;
let redirecting = false;

function readRegistration() {
  try {
    const saved = JSON.parse(sessionStorage.getItem(registrationKey));
    return saved && typeof saved.email === 'string' && ['verify', 'verified'].includes(saved.step) ? saved : null;
  } catch { return null; }
}
function saveRegistration() {
  // Keep names/email and progress for refresh recovery; never store a password or OTP.
  try {
    if (registration) sessionStorage.setItem(registrationKey, JSON.stringify(registration));
    else sessionStorage.removeItem(registrationKey);
  } catch { /* The current page still works if session storage is unavailable. */ }
}
function stopVerificationWork() {
  ++otpMonitor;
  clearInterval(resendTimer);
  clearTimeout(redirectTimer);
}

function selectAuthTab(tab) {
  for (const [id, active] of [['loginTab', tab === 'login'], ['registerTab', tab === 'register']]) {
    const button = document.getElementById(id);
    button.classList.toggle('active', active);
    button.setAttribute('aria-pressed', String(active));
  }
}

function switchTab(tab) {
  if (registration?.step === 'verified') { proceedToSignIn(); return; }
  if (tab === 'register' && registration?.step === 'verify') { showVerification(registration.email); return; }
  stopVerificationWork();
  verifyForm.hidden = true;
  verifiedStep.hidden = true;
  document.getElementById('verificationHelp').hidden = false;
  const reg = tab === 'register';
  loginForm.hidden = reg;
  registerForm.hidden = !reg;
  selectAuthTab(tab);
  document.getElementById('heading').textContent = reg ? 'Create Account' : 'Welcome Back';
  document.getElementById('subtitle').textContent = reg ? 'Join us to plan your next memorable event.' : 'Sign in to manage your catering bookings.';
  message.hidden = true;
}
for (const [id, tab] of [['loginTab', 'login'], ['registerTab', 'register'], ['toRegister', 'register'], ['toLogin', 'login']]) {
  document.getElementById(id).addEventListener('click', () => switchTab(tab));
}
document.querySelectorAll('.show').forEach(button => button.addEventListener('click', () => {
  const input = document.getElementById(button.dataset.target);
  input.type = input.type === 'password' ? 'text' : 'password';
  button.textContent = input.type === 'password' ? 'Show' : 'Hide';
  button.setAttribute('aria-label', button.textContent + ' password');
}));
function notify(text) {
  message.textContent = text;
  message.hidden = false;
}
async function submit(form, action) {
  const button = form.querySelector('.submit');
  button.disabled = true;
  message.hidden = true;
  try { await action(); }
  catch (error) { notify(error.message || 'Please try again.'); }
  finally { button.disabled = false; }
}
registerForm.addEventListener('submit', event => {
  event.preventDefault();
  const password = value('registerPassword'), confirmPassword = value('confirmPassword');
  if (password !== confirmPassword) { notify('Passwords do not match'); return; }
  return submit(registerForm, async () => {
    const email = value('registerEmail').trim().toLowerCase();
    const firstName = value('firstName').trim(), lastName = value('lastName').trim();
    const data = await apiRequest('/api/customer/auth/register', {
      method: 'POST',
      body: JSON.stringify({firstName, lastName, email, password, confirmPassword})
    });
    registration = {firstName, lastName, email, step: 'verify', notificationId: data.notificationId, resendAvailableAt: Date.now() + 60000};
    saveRegistration();
    document.getElementById('registerPassword').value = '';
    document.getElementById('confirmPassword').value = '';
    showVerification(email);
    notify('Registration successful! We have sent a verification code to your email address.');
  });
});
function showVerification(email = '') {
  if (registration?.step === 'verified') { showVerified(); return; }
  stopVerificationWork();
  selectAuthTab('register');
  loginForm.hidden = true;
  registerForm.hidden = true;
  verifyForm.hidden = false;
  verifiedStep.hidden = true;
  document.getElementById('verificationHelp').hidden = true;
  document.getElementById('heading').textContent = 'Verify Your Email';
  document.getElementById('subtitle').textContent = 'One more step to activate your account.';
  document.getElementById('verificationInstructions').textContent = `We have sent a 6-digit verification code to ${email || 'your email'}. Please enter the code below to verify your account.`;
  document.getElementById('verifyEmail').value = email;
  document.getElementById('verifyEmail').readOnly = registration?.step === 'verify';
  document.getElementById('verificationCode').value = '';
  message.hidden = true;
  const remaining = Math.max(0, ((registration?.resendAvailableAt || 0) - Date.now()) / 1000);
  startResendCooldown(remaining);
  if (registration?.notificationId) monitorOtp(registration.notificationId);
}
document.getElementById('toVerify').addEventListener('click', () => showVerification(registration?.email || value('loginEmail').trim()));

function startResendCooldown(seconds = 60) {
  const button = document.getElementById('resendCode');
  clearInterval(resendTimer);
  const until = Date.now() + seconds * 1000;
  if (registration?.step === 'verify') {
    registration.resendAvailableAt = until;
    saveRegistration();
  }
  button.disabled = true;
  const tick = () => {
    const seconds = Math.max(0, Math.ceil((until - Date.now()) / 1000));
    button.textContent = seconds ? `Resend OTP (${seconds}s)` : 'Resend OTP';
    button.disabled = seconds > 0;
    if (!seconds) clearInterval(resendTimer);
  };
  resendTimer = setInterval(tick, 1000);
  tick();
}
async function monitorOtp(id) {
  const current = ++otpMonitor;
  if (!id) return;
  for (let attempt = 0; attempt < 12; attempt++) {
    await new Promise(resolve => setTimeout(resolve, 5000));
    if (current !== otpMonitor || verifyForm.hidden) return;
    try {
      const status = await apiRequest(`/api/customer/auth/notifications/${encodeURIComponent(id)}`);
      if (current !== otpMonitor || verifyForm.hidden) return;
      notify(status.message);
      if (['SMTP_ACCEPTED', 'EXPIRED', 'CANCELLED', 'FAILED', 'DISABLED'].includes(status.status)) return;
    } catch { notify('Email status could not be checked. Check your inbox or request a new code after the cooldown.'); return; }
  }
}
document.getElementById('backToLogin').addEventListener('click', () => switchTab('login'));
verifyForm.addEventListener('submit', event => {
  event.preventDefault();
  return submit(verifyForm, async () => {
    const email = value('verifyEmail').trim();
    await apiRequest('/api/customer/auth/verify', {method: 'POST', body: JSON.stringify({email, code: value('verificationCode')})});
    registration = {firstName: registration?.firstName || '', lastName: registration?.lastName || '',
      email, step: 'verified', redirectAt: Date.now() + 3000};
    saveRegistration();
    showVerified();
  });
});
document.getElementById('resendCode').addEventListener('click', async event => {
  const emailInput = document.getElementById('verifyEmail');
  if (!emailInput.reportValidity()) return;
  const button = event.currentTarget;
  button.disabled = true;
  try {
    const data = await apiRequest('/api/customer/auth/resend', {method: 'POST', body: JSON.stringify({email: emailInput.value.trim()})});
    if (registration?.step === 'verify') {
      registration.notificationId = data.notificationId;
      saveRegistration();
    }
    notify(data.message + ' Please wait 60 seconds before requesting another.');
    startResendCooldown();
    monitorOtp(data.notificationId);
  } catch (error) {
    notify(error.message);
    if (error.retryAfterSeconds) startResendCooldown(error.retryAfterSeconds);
    else button.disabled = false;
  }
});
function showVerified() {
  stopVerificationWork();
  selectAuthTab('register');
  loginForm.hidden = true;
  registerForm.hidden = true;
  verifyForm.hidden = true;
  verifiedStep.hidden = false;
  document.getElementById('verificationHelp').hidden = true;
  document.getElementById('heading').textContent = 'Email Verified Successfully!';
  document.getElementById('subtitle').textContent = 'Your Saneth Catering account has been successfully verified. You can now sign in using your email address and password.';
  document.getElementById('verificationCode').value = '';
  message.hidden = true;
  redirectTimer = setTimeout(proceedToSignIn, Math.max(0, registration.redirectAt - Date.now()));
}
function proceedToSignIn() {
  if (redirecting) return;
  redirecting = true;
  stopVerificationWork();
  // Both existing Sign In and Register views live on this page. Keep email out of the URL.
  window.location.replace('customer-login.html?verified=1');
}
document.getElementById('proceedToSignIn').addEventListener('click', proceedToSignIn);
loginForm.addEventListener('submit', event => {
  event.preventDefault();
  return submit(loginForm, async () => {
    const data = await apiRequest('/api/customer/auth/login', {
      method: 'POST', body: JSON.stringify({email: value('loginEmail').trim(), password: value('loginPassword')})
    });
    if (!data?.token) throw new Error('Sign-in could not be completed. Please try again.');
    sessionStorage.setItem('saneth_customer_token', data.token);
    sessionStorage.setItem('saneth_customer_name', data.firstName || '');
    window.location.assign('customer-home.html');
  });
});

if (registration) {
  for (const field of ['firstName', 'lastName']) document.getElementById(field).value = registration[field] || '';
  document.getElementById('registerEmail').value = registration.email;
  if (registration.step === 'verified' && new URLSearchParams(window.location.search).get('verified') === '1') {
    const email = registration.email;
    registration = null;
    saveRegistration();
    switchTab('login');
    document.getElementById('loginEmail').value = email;
    notify('Your email is verified. Sign in with your registered email address and password.');
  } else if (registration.step === 'verified') showVerified();
  else showVerification(registration.email);
}
