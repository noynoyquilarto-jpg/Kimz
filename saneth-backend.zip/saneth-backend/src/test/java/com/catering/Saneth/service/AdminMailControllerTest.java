package com.catering.Saneth.service;

import com.catering.Saneth.controller.AdminMailController;
import org.junit.jupiter.api.Test;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class AdminMailControllerTest {
    JavaMailSenderImpl sender() {
        var sender = mock(JavaMailSenderImpl.class);
        when(sender.getUsername()).thenReturn("rerazo@usa.edu.ph");
        when(sender.getPassword()).thenReturn("test-only");
        return sender;
    }

    @Test void disabledMailDoesNotConnect() {
        var sender = mock(JavaMailSenderImpl.class);
        assertThat(new AdminMailController(sender, false).check().get("status")).isEqualTo("DISABLED");
        verifyNoInteractions(sender);
    }

    @Test void missingPasswordIsReported() {
        var sender = sender();
        when(sender.getPassword()).thenReturn("");
        assertThat(new AdminMailController(sender, true).check().get("status")).isEqualTo("NOT_CONFIGURED");
    }

    @Test void successfulLoginDoesNotClaimInboxDelivery() throws Exception {
        var sender = sender();
        var result = new AdminMailController(sender, true).check();
        assertThat(result.get("status")).isEqualTo("READY");
        assertThat(result.get("message")).contains("not guaranteed");
        verify(sender).testConnection();
    }

    @Test void rejectedLoginGivesActionableMessageWithoutCredentials() throws Exception {
        var sender = sender();
        doThrow(new jakarta.mail.AuthenticationFailedException("private server details")).when(sender).testConnection();
        var result = new AdminMailController(sender, true).check();
        assertThat(result.get("status")).isEqualTo("AUTHENTICATION_FAILED");
        assertThat(result.get("message")).contains("App Password").doesNotContain("private server details", "test-only");
    }

    @Test void tlsFailureIsReportedSeparately() throws Exception {
        var sender = sender();
        doThrow(new jakarta.mail.MessagingException("PKIX")).when(sender).testConnection();
        assertThat(new AdminMailController(sender, true).check().get("status")).isEqualTo("CONNECTION_FAILED");
    }
}
