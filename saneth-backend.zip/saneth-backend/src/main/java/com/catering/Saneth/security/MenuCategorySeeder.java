package com.catering.Saneth.security;

public class MenuCategorySeeder {
}
