package com.catering.Saneth.dto.response;
import java.time.LocalDate;
public record DateAvailabilityResponse(LocalDate eventDate, int capacity, long booked, long remainingSlots, boolean available) {}
