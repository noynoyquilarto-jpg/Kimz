package com.catering.Saneth.dto.response;

import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.model.enums.BookingType;
import com.catering.Saneth.model.enums.PaymentMethod;
import com.catering.Saneth.model.enums.PaymentStatus;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Getter
@Setter
@Builder
public class BookingResponse {

    private Long id;
    private String bookingReference;

    private String customerName;
    private String email;
    private String phoneNumber;
    private String customerAddress;

    private String eventPlace;
    private LocalDate eventDate;
    private LocalTime eventTime;
    private String eventType;
    private Integer numberOfPax;

    private BookingType bookingType;

    private Long menuPackageId;
    private String menuPackageName;
    private Double packagePrice;
    private Integer goodForPax;

    private List<MenuItemResponse> packageMenuItems;
    private List<MenuItemResponse> customMenuItems;

    // =========================
    // ADD-ONS
    // =========================

    private Boolean projector;
    private Boolean videoke;
    private Boolean lechon;
    private Boolean cake;
    private String specialRequest;

    // =========================
    // PAYMENT
    // =========================

    /**
     * Final price agreed by admin.
     */
    private BigDecimal quotedPrice;

    /**
     * Amount customer is REQUIRED to pay as downpayment.
     */
    private BigDecimal requiredDownPayment;

    /**
     * Amount customer has ACTUALLY PAID so far.
     */
    private Double downPaymentAmount;

    /**
     * Automatically calculated:
     *
     * quotedPrice - downPaymentAmount
     */
    private BigDecimal balance;

    private PaymentMethod paymentMethod;
    private String paymentReferenceNumber;
    private String paymentNote;

    private BookingStatus bookingStatus;
    private PaymentStatus paymentStatus;

    private String archiveReason;
    private BookingStatus statusBeforeArchive;
    private List<com.catering.Saneth.service.NotificationQueue.Status> emailNotifications;
}
