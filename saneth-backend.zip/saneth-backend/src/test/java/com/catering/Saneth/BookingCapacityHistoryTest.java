package com.catering.Saneth;

import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.repository.BookingRepo;
import com.catering.Saneth.service.BookingService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.LocalTime;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Transactional
class BookingCapacityHistoryTest {
    @Autowired BookingRepo bookings;
    @Autowired BookingService service;

    @Test
    void pendingCancellationCompletionAndArchivingPreserveDailyCapacity() {
        var date = LocalDate.of(2090, 6, 12);
        var first = save(date);
        var second = save(date);
        var third = save(date);
        assertThat(service.getDateAvailability(date).booked()).isZero();
        first.setBookingStatus(BookingStatus.CONFIRMED);
        bookings.flush();
        assertThat(service.getDateAvailability(date).remainingSlots()).isEqualTo(2);
        second.setBookingStatus(BookingStatus.CONFIRMED);
        third.setBookingStatus(BookingStatus.CONFIRMED);
        bookings.flush();
        assertThat(service.getDateAvailability(date).available()).isFalse();
        second.setBookingStatus(BookingStatus.CANCELLED);
        second.setBookingStatus(BookingStatus.ARCHIVED);
        bookings.flush();
        assertThat(second.getStatusBeforeArchive()).isEqualTo(BookingStatus.CANCELLED);
        assertThat(service.getDateAvailability(date).remainingSlots()).isEqualTo(1);
        first.setBookingStatus(BookingStatus.COMPLETED);
        first.setBookingStatus(BookingStatus.ARCHIVED);
        bookings.flush();
        assertThat(first.getStatusBeforeArchive()).isEqualTo(BookingStatus.COMPLETED);
        assertThat(service.getDateAvailability(date).booked()).isEqualTo(2);
        assertThat(bookings.countByEventDateAndBookingStatusInAndIdNot(date,
                BookingService.CAPACITY_STATUSES, third.getId())).isEqualTo(1);
        assertThat(service.getDateAvailability(date.plusDays(1)).booked()).isZero();
    }

    private Booking save(LocalDate date) {
        return bookings.saveAndFlush(Booking.builder().customerName("Capacity test")
                .email("capacity@example.invalid").phoneNumber("09000000000")
                .customerAddress("Test address").eventPlace("Test venue")
                .eventDate(date).eventTime(LocalTime.NOON).eventType("Test")
                .numberOfPax(10).bookingStatus(BookingStatus.PENDING).build());
    }
}
