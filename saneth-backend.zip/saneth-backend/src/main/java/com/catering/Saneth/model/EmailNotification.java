package com.catering.Saneth.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.Instant;

/** Durable notification metadata. Encrypted content is never exposed through controllers. */
@Entity @Table(name = "email_notifications") @Getter @Setter
public class EmailNotification {
    @Id @Column(length = 36) private String id;
    @Column(nullable = false, unique = true, length = 180) private String eventKey;
    @Column(nullable = false, length = 30) private String kind;
    private Long bookingId;
    private Long customerId;
    @Column(nullable = false, length = 30) private String status = "QUEUED";
    @Column(columnDefinition = "MEDIUMTEXT") private String encryptedContent;
    @Column(nullable = false) private int attempts;
    @Column(nullable = false) private Instant createdAt = Instant.now();
    @Column(nullable = false) private Instant nextAttemptAt = Instant.now();
    private Instant expiresAt;
    private Instant acceptedAt;
    @Column(length = 36) private String leaseToken;
    @Column(length = 80) private String lastError;
}
