package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.MenuItemRequest;
import com.catering.Saneth.dto.response.MenuItemResponse;
import com.catering.Saneth.model.MenuItem;
import com.catering.Saneth.repository.MenuRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MenuItemServiceTest {

    @Mock
    private MenuRepo menuRepo;

    @Mock
    private com.catering.Saneth.repository.MenuCategoryRepo menuCategoryRepo;

    @InjectMocks
    private MenuItemService menuItemService;

    private MenuItem menuItem;

    @BeforeEach
    void setUp() {
        menuItem = MenuItem.builder()
                .id(1L)
                .name("Fried Chicken")
                .category(com.catering.Saneth.model.MenuCategory.builder().id(1L).name("Main Dish").build())
                .description("Crispy fried chicken")
                .imageUrl("/images/menu/fried-chicken.jpg")
                .available(true)
                .build();
    }

    @Test
    void createMenuItem_shouldReturnSavedMenuItem() {
        MenuItemRequest request = new MenuItemRequest();
        request.setName("Fried Chicken");
        request.setCategoryId(1L);
        when(menuCategoryRepo.findById(1L)).thenReturn(Optional.of(menuItem.getCategory()));
        request.setDescription("Crispy fried chicken");
        request.setImageUrl("/images/menu/fried-chicken.jpg");
        request.setAvailable(true);

        when(menuRepo.save(any(MenuItem.class))).thenReturn(menuItem);

        MenuItemResponse response = menuItemService.createMenuItem(request);

        assertThat(response).isNotNull();
        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getName()).isEqualTo("Fried Chicken");
        assertThat(response.getCategoryName()).isEqualTo("Main Dish");
        assertThat(response.getAvailable()).isTrue();

        verify(menuRepo, times(1)).save(any(MenuItem.class));
    }

    @Test
    void getAllMenu_shouldReturnListOfMenuItems() {
        when(menuRepo.findAll()).thenReturn(List.of(menuItem));

        List<MenuItemResponse> response = menuItemService.getAllMenu();

        assertThat(response).hasSize(1);
        assertThat(response.get(0).getName()).isEqualTo("Fried Chicken");

        verify(menuRepo, times(1)).findAll();
    }

    @Test
    void getMenuById_shouldReturnMenuItem_whenMenuExists() {
        when(menuRepo.findById(1L)).thenReturn(Optional.of(menuItem));

        MenuItemResponse response = menuItemService.getMenuById(1L);

        assertThat(response).isNotNull();
        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getName()).isEqualTo("Fried Chicken");

        verify(menuRepo, times(1)).findById(1L);
    }

    @Test
    void getMenuById_shouldThrowException_whenMenuDoesNotExist() {
        when(menuRepo.findById(99L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            menuItemService.getMenuById(99L);
        });

        assertThat(exception.getMessage()).isEqualTo("Menu item not found.");

        verify(menuRepo, times(1)).findById(99L);
    }

    @Test
    void updateMenu_shouldReturnUpdatedMenuItem() {
        MenuItemRequest request = new MenuItemRequest();
        request.setName("Updated Chicken");
        request.setCategoryId(1L);
        when(menuCategoryRepo.findById(1L)).thenReturn(Optional.of(menuItem.getCategory()));
        request.setDescription("Updated description");
        request.setImageUrl("/images/menu/updated-chicken.jpg");
        request.setAvailable(false);

        MenuItem updatedMenuItem = MenuItem.builder()
                .id(1L)
                .name("Updated Chicken")
                .category(com.catering.Saneth.model.MenuCategory.builder().id(1L).name("Main Dish").build())
                .description("Updated description")
                .imageUrl("/images/menu/updated-chicken.jpg")
                .available(false)
                .build();

        when(menuRepo.findById(1L)).thenReturn(Optional.of(menuItem));
        when(menuRepo.save(any(MenuItem.class))).thenReturn(updatedMenuItem);

        MenuItemResponse response = menuItemService.updateMenu(1L, request);

        assertThat(response.getName()).isEqualTo("Updated Chicken");
        assertThat(response.getDescription()).isEqualTo("Updated description");
        assertThat(response.getAvailable()).isFalse();

        verify(menuRepo, times(1)).findById(1L);
        verify(menuRepo, times(1)).save(any(MenuItem.class));
    }

    @Test
    void deleteMenuItem_shouldDeleteMenuItem_whenMenuExists() {
        when(menuRepo.findById(1L)).thenReturn(Optional.of(menuItem));

        menuItemService.deleteMenuItem(1L);

        verify(menuRepo, times(1)).findById(1L);
        verify(menuRepo, times(1)).delete(menuItem);
    }
}
