package com.catering.Saneth.service;

import com.catering.Saneth.exception.RateLimitException;
import org.junit.jupiter.api.Test;
import java.time.Duration;
import java.util.concurrent.atomic.AtomicLong;
import static org.assertj.core.api.Assertions.*;

class RateLimitServiceTest {
    @Test void blockedRequestsDoNotExtendTheWindow() {
        var now = new AtomicLong(1000);
        var service = new RateLimitService(now::get);
        service.checkKey("booking", 1, Duration.ofSeconds(10));
        now.addAndGet(2000);
        var error = catchThrowableOfType(() -> service.checkKey("booking", 1, Duration.ofSeconds(10)), RateLimitException.class);
        assertThat(error.getRetryAfterSeconds()).isEqualTo(8);
        now.addAndGet(8000);
        assertThatCode(() -> service.checkKey("booking", 1, Duration.ofSeconds(10))).doesNotThrowAnyException();
    }
    @Test void unrelatedCustomersHaveIndependentLimits() {
        var service = new RateLimitService(() -> 1000);
        service.checkKey("customer:a", 1, Duration.ofMinutes(1));
        assertThatCode(() -> service.checkKey("customer:b", 1, Duration.ofMinutes(1))).doesNotThrowAnyException();
    }
}
