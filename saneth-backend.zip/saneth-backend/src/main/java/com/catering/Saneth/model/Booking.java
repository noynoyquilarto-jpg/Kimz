package com.catering.Saneth.model;


import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.model.enums.BookingType;
import com.catering.Saneth.model.enums.PaymentMethod;
import com.catering.Saneth.model.enums.PaymentStatus;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "bookings")
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String bookingReference;

    @Column(nullable = false)
    private String customerName;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String phoneNumber;

    @Column(nullable = false)
    private String customerAddress;

    @Column(nullable = false, length = 1000)
    private String eventPlace;

    @Column(nullable = false)
    private LocalDate eventDate;

    @Column(nullable = false)
    private LocalTime eventTime;

    @Column(nullable = false)
    private String eventType;

    @Column(nullable = false)
    private Integer numberOfPax;

    @ManyToOne
    @JoinColumn(name = "menu_package_id")
    private MenuPackage menuPackage;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private BookingType bookingType;

    @Enumerated(EnumType.STRING)
    private PaymentMethod paymentMethod;

    private Double downPaymentAmount;

    private String paymentReferenceNumber;

    private String paymentNote;

    @Enumerated(EnumType.STRING)
    private BookingStatus bookingStatus;

    @Enumerated(EnumType.STRING)
    private BookingStatus statusBeforeArchive;

    public void setBookingStatus(BookingStatus status) {
        if (status == BookingStatus.ARCHIVED && bookingStatus != BookingStatus.ARCHIVED) {
            statusBeforeArchive = bookingStatus;
        }
        bookingStatus = status;
    }

    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus;

    private String paymentRejectionReason;

    private String cancellationReason;

    private String archiveReason;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    @OneToMany(
            mappedBy = "booking",
            cascade = CascadeType.ALL,
            orphanRemoval = true
    )
    @Builder.Default
    private List<BookingMenuItem> customMenuItems = new ArrayList<>();

    @PrePersist
    protected void onCreate(){
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();

        if(bookingStatus == null){
            bookingStatus = BookingStatus.PENDING;
        }
        if(paymentStatus == null){
            paymentStatus = PaymentStatus.NOT_REQUIRED_YET;
        }
        if (bookingType == null) {
            bookingType = BookingType.PACKAGE;
        }
    }

    @PreUpdate
    protected void onUpdate(){
        updatedAt = LocalDateTime.now();
    }

    @Builder.Default
    private Boolean projector = false;

    @Builder.Default
    private Boolean videoke = false;

    @Builder.Default
    private Boolean lechon = false;

    @Builder.Default
    private Boolean cake = false;

    @Column(length = 500)
    private String specialRequest;

    private BigDecimal quotedPrice;

    private BigDecimal downPayment;

}
