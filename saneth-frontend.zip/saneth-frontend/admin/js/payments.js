import { showAlert as alert, showConfirm as confirm, showPrompt as prompt } from '../../js/dialogs.js';
import { apiRequest, requireAuth, getToken, peso, badge, safe } from './api.js';
import { initLayout } from './layout.js';
import { emailNotices, watchEmail } from './email-notifications.js';

requireAuth();
initLayout();

const table = document.getElementById('paymentsTable');
const refreshBtn = document.getElementById('refreshBtn');
const filterTabs = document.querySelectorAll('[data-payment-filter]');
const paymentsSectionTitle = document.getElementById('paymentsSectionTitle');
const paymentsSectionMeta = document.getElementById('paymentsSectionMeta');
const countAll = document.getElementById('countAll');
const countNotRequired = document.getElementById('countNotRequired');
const countAwaiting = document.getElementById('countAwaiting');
const countDownPayment = document.getElementById('countDownPayment');
const countPartial = document.getElementById('countPartial');
const countFullyPaid = document.getElementById('countFullyPaid');
const countRejected = document.getElementById('countRejected');

const paymentModal = document.getElementById('paymentModal');
const closeModalBtn = document.getElementById('closeModalBtn');
const paymentForm = document.getElementById('paymentForm');

const bookingIdInput = document.getElementById('bookingId');
const paymentMethodInput = document.getElementById('paymentMethod');
const paymentAmountInput = document.getElementById('paymentAmount');
const paymentReferenceNumberInput = document.getElementById('paymentReferenceNumber');
const paymentNoteInput = document.getElementById('paymentNote');

let paymentsCache = [];
let activePaymentFilter = 'ALL';
let savingPayment = false;
let paymentSubmissionKey;
let requestedBookingId = new URLSearchParams(window.location.search).get('bookingId');

refreshBtn.addEventListener('click', loadPayments);
closeModalBtn.addEventListener('click', closePaymentModal);
paymentForm.addEventListener('submit', submitPayment);
paymentAmountInput.addEventListener('input', updatePaymentPreview);
paymentMethodInput.addEventListener('change', updateReferenceRequirement);

filterTabs.forEach(tab => {
  tab.addEventListener('click', () => {
    activePaymentFilter = tab.dataset.paymentFilter;
    updateFilterTabs();
    renderPayments(getFilteredPayments());
  });
});

loadPayments();

async function loadPayments() {
  table.innerHTML = '<tr><td colspan="9">Loading payments...</td></tr>';

  try {
    paymentsCache = await apiRequest('/api/admin/payments', { redirectOnAuthFailure: false }) || [];
    updatePaymentCounts();
    renderPayments(getFilteredPayments());
    if (requestedBookingId) {
      const id = requestedBookingId;
      requestedBookingId = null;
      openPaymentModal(id);
    }
  } catch (error) {
    table.innerHTML = `<tr><td colspan="9">${safe(error.message)}</td></tr>`;
  }
}

function getFilteredPayments() {
  if (activePaymentFilter === 'ALL') {
    return paymentsCache;
  }

  return paymentsCache.filter(payment => payment.paymentStatus === activePaymentFilter);
}

function updateFilterTabs() {
  filterTabs.forEach(tab => {
    tab.classList.toggle('active', tab.dataset.paymentFilter === activePaymentFilter);
  });

  const label = getFilterLabel(activePaymentFilter);
  paymentsSectionTitle.textContent = `${label} Payments`;
  paymentsSectionMeta.textContent = activePaymentFilter === 'ALL'
    ? 'Showing every active payment.'
    : `Showing ${label.toLowerCase()} payments only.`;
}

function updatePaymentCounts() {
  const counts = paymentsCache.reduce((result, payment) => {
    result.ALL += 1;
    if (result[payment.paymentStatus] !== undefined) {
      result[payment.paymentStatus] += 1;
    }
    return result;
  }, {
    ALL: 0,
    NOT_REQUIRED_YET: 0,
    AWAITING_PAYMENT: 0,
    DOWN_PAYMENT_CONFIRMED: 0,
    PARTIALLY_PAID: 0,
    FULLY_PAID: 0,
    REJECTED: 0
  });

  countAll.textContent = counts.ALL;
  countNotRequired.textContent = counts.NOT_REQUIRED_YET;
  countAwaiting.textContent = counts.AWAITING_PAYMENT;
  countDownPayment.textContent = counts.DOWN_PAYMENT_CONFIRMED;
  countPartial.textContent = counts.PARTIALLY_PAID;
  countFullyPaid.textContent = counts.FULLY_PAID;
  countRejected.textContent = counts.REJECTED;
}

function getFilterLabel(status) {
  return {
    ALL: 'All',
    NOT_REQUIRED_YET: 'Not Required',
    AWAITING_PAYMENT: 'Awaiting',
    DOWN_PAYMENT_CONFIRMED: 'Down Payment',
    PARTIALLY_PAID: 'Partial',
    FULLY_PAID: 'Fully Paid',
    REJECTED: 'Rejected'
  }[status] || 'All';
}

function renderPayments(payments) {
  if (!payments.length) {
    table.innerHTML = `<tr><td colspan="9">No ${getFilterLabel(activePaymentFilter).toLowerCase()} payments found.</td></tr>`;
    return;
  }

  table.innerHTML = payments.map(payment => {
    const total = Number(payment.packagePrice || 0);
    const downPayment = Number(payment.downPaymentAmount ?? 0);
    const paymentRecords = payment.payments || [];
    const recordedTotalPaid = paymentRecords.filter(record => !record.verificationStatus || record.verificationStatus === 'VERIFIED').reduce((sum, record) => sum + Number(record.amount || 0), 0);
    const totalPaid = Number(payment.totalPaid ?? recordedTotalPaid);
    const balance = Number(payment.remainingBalance ?? Math.max(total - totalPaid, 0));
    const latestPayment = getLatestPayment(payment);

    return `
      <tr>
        <td><strong>${safe(payment.bookingReference)}</strong></td>

        <td>
          ${safe(payment.customerName)}<br>
          <span class="muted">${safe(payment.email)}</span>
        </td>

        <td>${peso(total)}</td>
        <td>${peso(downPayment)}</td>
        <td>${peso(totalPaid)}</td>
        <td>${peso(balance)}</td>
        <td>${renderLatestPayment(latestPayment)}</td>
        <td>${badge(payment.paymentStatus)}${emailNotices(payment.emailNotifications)}</td>

        <td>
          <div class="actions">
            ${renderActions(payment)}
          </div>
        </td>
      </tr>
    `;
  }).join('');

  table.querySelectorAll('[data-add-payment]').forEach(button => {
    button.addEventListener('click', () => openPaymentModal(button.dataset.addPayment));
  });

  table.querySelectorAll('[data-reject]').forEach(button => {
    button.addEventListener('click', () => rejectPayment(button.dataset.reject));
  });
  table.querySelectorAll('[data-verify-submitted], [data-reject-submitted]').forEach(button => {
    button.addEventListener('click', () => reviewSubmitted(button));
  });
}

function renderActions(payment) {
  const pending = (payment.payments || []).filter(record => record.verificationStatus === 'PENDING_VERIFICATION');
  if (pending.length) return pending.map(record => `
    <span>${peso(record.amount)} ${safe(record.paymentMethod)}: ${safe(record.paymentReferenceNumber || 'Cash')} — pending verification</span>
    <button class="btn btn-light btn-small" data-verify-submitted="${record.id}" data-booking="${payment.bookingId}">Verify Payment</button>
    <button class="btn btn-danger btn-small" data-reject-submitted="${record.id}" data-booking="${payment.bookingId}">Reject Submission</button>`).join('');
  if (payment.paymentStatus === 'FULLY_PAID') {
    return '<span class="muted">Paid</span>';
  }

  if (payment.paymentStatus === 'NOT_REQUIRED_YET') {
    return '<span class="muted">Waiting for booking confirmation</span>';
  }

  return `
    <button class="btn btn-light btn-small" data-add-payment="${payment.bookingId}">
      Add Payment
    </button>
    <button class="btn btn-danger btn-small" data-reject="${payment.bookingId}">
      Reject
    </button>
  `;
}

function getLatestPayment(payment) {
  const records = payment.payments || [];
  if (records.length) {
    return records[records.length - 1];
  }

  if (payment.downPaymentAmount) {
    return {
      amount: payment.downPaymentAmount,
      paymentMethod: payment.paymentMethod,
      paymentReferenceNumber: payment.paymentReferenceNumber
    };
  }

  return null;
}

function renderLatestPayment(payment) {
  if (!payment) {
    return '<span class="muted">N/A</span>';
  }

  return `
    ${peso(payment.amount)} ${safe(payment.paymentMethod)}<br>
    <span class="muted">${safe(payment.paymentReferenceNumber || 'No reference')}</span>
  `;
}

function openPaymentModal(bookingId) {
  if (savingPayment) return;
  const payment = paymentsCache.find(item => String(item.bookingId) === String(bookingId));
  const balance = Number(payment?.remainingBalance);
  if (!payment || !Number.isFinite(balance) || balance <= 0 || payment.paymentStatus === 'NOT_REQUIRED_YET') {
    alert('This booking has no payable balance. Confirm its quote before adding a payment.');
    return;
  }

  bookingIdInput.value = bookingId;
  paymentSubmissionKey = newSubmissionKey();
  document.getElementById('paymentError').hidden = true;
  document.getElementById('paymentSignIn').hidden = true;
  paymentAmountInput.max = balance.toFixed(2);
  paymentMethodInput.value = 'GCASH';
  paymentAmountInput.value = '';
  document.getElementById('paymentFundsVerified').checked = false;
  document.getElementById('paymentSummary').innerHTML = `
    <p>Booking Reference: <strong>${safe(payment.bookingReference)}</strong></p>
    <p>Quoted Price: <strong>${peso(payment.packagePrice)}</strong></p>
    <p>Previously Verified: <strong>${peso(payment.totalPaid ?? 0)}</strong></p>`;
  paymentReferenceNumberInput.value = '';
  paymentNoteInput.value = 'Payment verified by admin';
  updateReferenceRequirement();
  updatePaymentPreview();

  paymentModal.classList.remove('hidden');
  paymentAmountInput.focus();
  paymentAmountInput.select();
}

function updateReferenceRequirement() {
  paymentReferenceNumberInput.required = paymentMethodInput.value !== 'CASH';
  paymentReferenceNumberInput.placeholder = paymentReferenceNumberInput.required
    ? 'Enter transaction reference' : 'Optional for cash payments';
}

function updatePaymentPreview() {
  const payment = paymentsCache.find(item => String(item.bookingId) === String(bookingIdInput.value));
  if (!payment) return;
  const amount = Number(paymentAmountInput.value) || 0;
  const total = Math.round((Number(payment.totalPaid ?? 0) + amount) * 100) / 100;
  document.getElementById('paymentPreview').innerHTML = `
    <p>Amount Received Now: <strong>${peso(amount)}</strong></p>
    <p>Total Paid After Verification: <strong>${peso(total)}</strong></p>
    <p>Remaining Balance: <strong>${peso(Math.max(Number(payment.packagePrice) - total, 0))}</strong></p>`;
}

function closePaymentModal() {
  paymentModal.classList.add('hidden');
}

async function submitPayment(event) {
  event.preventDefault();
  if (savingPayment) return;
  if (!paymentForm.reportValidity()) return;
  savingPayment = true;
  const saveButton = paymentForm.querySelector('button[type="submit"]');
  if (saveButton) saveButton.disabled = true;
  closeModalBtn.disabled = true;
  document.getElementById('paymentError').hidden = true;

  const bookingId = bookingIdInput.value;

  const body = {
    paymentMethod: paymentMethodInput.value,
    amount: Number(paymentAmountInput.value),
    paymentReferenceNumber: paymentReferenceNumberInput.value.trim(),
    note: paymentNoteInput.value.trim(),
    submissionKey: paymentSubmissionKey
  };

  try {
    const updated = await apiRequest(`/api/admin/payments/booking/${bookingId}/payments`, {
      method: 'POST',
      redirectOnAuthFailure: false,
      body: JSON.stringify(body)
    });

    closePaymentModal();
    paymentsCache = paymentsCache.map(payment => String(payment.bookingId) === String(bookingId) ? updated : payment);
    updatePaymentCounts();
    renderPayments(getFilteredPayments());
    paymentsSectionMeta.textContent = `Payment successfully verified. Remaining balance: ${peso(updated.remainingBalance)}. Receipt email is queued.`;
    watchEmail(bookingId, 'PAYMENT_RECEIPT', status => { paymentsSectionMeta.textContent = 'Payment successfully verified. ' + status; });
  } catch (error) {
    const message = document.getElementById('paymentError');
    message.textContent = error.message;
    message.hidden = false;
    document.getElementById('paymentSignIn').hidden = Boolean(getToken());
  } finally {
    savingPayment = false;
    if (saveButton) saveButton.disabled = false;
    closeModalBtn.disabled = false;
  }
}

async function rejectPayment(bookingId) {
  const reason = await prompt('Reason for rejection:');
  if (!reason) return;

  try {
    await apiRequest(`/api/admin/payments/booking/${bookingId}/reject`, {
      method: 'PUT',
      body: JSON.stringify({
        status: 'REJECTED',
        reason
      })
    });

    loadPayments();
  } catch (error) {
    alert(error.message);
  }
}

function newSubmissionKey() {
  return '10000000-1000-4000-8000-100000000000'.replace(/[018]/g, char =>
    (Number(char) ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> Number(char) / 4).toString(16));
}
async function reviewSubmitted(button) {
  const verify = Boolean(button.dataset.verifySubmitted);
  const paymentId = button.dataset.verifySubmitted || button.dataset.rejectSubmitted;
  const bookingId = button.dataset.booking;
  if (verify && !await confirm('Verify this payment only after checking that the funds were received. Continue?')) return;
  const reason = verify ? null : await prompt('Reason for rejecting this payment submission:');
  if (!verify && !reason) return;
  button.disabled = true;
  try {
    const updated = await apiRequest(`/api/admin/payments/booking/${bookingId}/payments/${paymentId}/${verify ? 'verify' : 'reject'}`, {
      method: 'PUT', ...(verify ? {} : { body: JSON.stringify({ status: 'REJECTED', reason }) })
    });
    paymentsCache = paymentsCache.map(item => String(item.bookingId) === String(bookingId) ? updated : item);
    updatePaymentCounts(); renderPayments(getFilteredPayments());
    paymentsSectionMeta.textContent = verify ? 'Payment successfully verified. Receipt email is queued.' : 'Payment submission rejected. Verified totals are unchanged.';
    if (verify) watchEmail(bookingId, 'PAYMENT_RECEIPT', status => { paymentsSectionMeta.textContent = 'Payment successfully verified. ' + status; });
  } catch (error) { alert(error.message); button.disabled = false; }
}
