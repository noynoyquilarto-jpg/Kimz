package com.catering.Saneth.service;

import com.catering.Saneth.model.AdminAuditLog;
import com.catering.Saneth.repository.AdminAuditLogRepo;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

class AdminAuditLogServiceTest {
    private final AdminAuditLogRepo repo = mock(AdminAuditLogRepo.class);
    private final AdminAuditLogService service = new AdminAuditLogService(repo);

    @AfterEach
    void clearSecurity() { SecurityContextHolder.clearContext(); }

    @Test
    void recordsAdminIdentityAndAutomaticDescription() {
        SecurityContextHolder.getContext().setAuthentication(
                new UsernamePasswordAuthenticationToken("admin@example.com", "unused", List.of()));
        service.record("PAYMENT_ADDED", "BOOKING", 12L, "PHP 5000");
        ArgumentCaptor<AdminAuditLog> captor = ArgumentCaptor.forClass(AdminAuditLog.class);
        verify(repo).save(captor.capture());
        assertThat(captor.getValue().getAdminEmail()).isEqualTo("admin@example.com");
        assertThat(captor.getValue().getDetails()).isEqualTo("payment added - booking #12: PHP 5000");
    }

    @Test
    void recordsCustomerIdentityWithoutAnAdminSessionAndBoundsDescription() {
        service.recordForActor("customer@example.com", "CUSTOMER_BOOKING_CREATED", "BOOKING", 3L, "x".repeat(1500));
        ArgumentCaptor<AdminAuditLog> captor = ArgumentCaptor.forClass(AdminAuditLog.class);
        verify(repo).save(captor.capture());
        assertThat(captor.getValue().getAdminEmail()).isEqualTo("customer@example.com");
        assertThat(captor.getValue().getDetails()).hasSize(1000).startsWith("customer booking created - booking #3:");
    }

    @Test
    void preservesHistoricalLogsWithTheirOriginalDescription() {
        when(repo.findTop200ByOrderByCreatedAtDesc()).thenReturn(List.of(AdminAuditLog.builder()
                .id(1L).adminEmail("admin@example.com").action("BOOKING_UPDATED").details("Original note").build()));
        assertThat(service.getRecentLogs()).singleElement().satisfies(log -> {
            assertThat(log.getDetails()).isEqualTo("Original note");
            assertThat(log.getId()).isEqualTo(1L);
        });
    }
}
