package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.RecommendationRequest;
import com.catering.Saneth.dto.response.MostBoughtPackageResponse;
import com.catering.Saneth.dto.response.MustTryPackageResponse;
import com.catering.Saneth.dto.response.RecommendationResponse;
import com.catering.Saneth.model.MenuPackage;
import com.catering.Saneth.repository.BookingRepo;
import com.catering.Saneth.repository.FeedbackRepo;
import com.catering.Saneth.repository.MenuPackageRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RecommendationServiceTest {

    @Mock
    private MenuPackageRepo menuPackageRepo;

    @Mock
    private BookingRepo bookingRepo;

    @Mock
    private FeedbackRepo feedbackRepo;

    @InjectMocks
    private RecommendationService recommendationService;

    private MenuPackage packageA;
    private MenuPackage packageB;

    @BeforeEach
    void setUp() {
        packageA = MenuPackage.builder()
                .id(1L)
                .name("Package A")
                .description("Budget-friendly package")
                .packagePrice(15000.0)
                .goodForPax(50)
                .available(true)
                .build();

        packageB = MenuPackage.builder()
                .id(2L)
                .name("Package B")
                .description("Premium package")
                .packagePrice(30000.0)
                .goodForPax(100)
                .available(true)
                .build();
    }

    @Test
    void generateRecommendation_shouldReturnPackagesThatFitBudgetAndPax() {
        RecommendationRequest request = new RecommendationRequest();
        request.setNumberOfPax(50);
        request.setBudget(20000.0);

        when(menuPackageRepo.findByAvailableTrueAndPackagePriceLessThanEqualAndGoodForPaxGreaterThanEqual(
                20000.0,
                50
        )).thenReturn(List.of(packageA));

        List<RecommendationResponse> response = recommendationService.generateRecommendation(request);

        assertThat(response).hasSize(1);
        assertThat(response.get(0).getPackageId()).isEqualTo(1L);
        assertThat(response.get(0).getPackageName()).isEqualTo("Package A");
        assertThat(response.get(0).getPackagePrice()).isEqualTo(15000.0);
        assertThat(response.get(0).getGoodForPax()).isEqualTo(50);

        verify(menuPackageRepo, times(1))
                .findByAvailableTrueAndPackagePriceLessThanEqualAndGoodForPaxGreaterThanEqual(20000.0, 50);
    }

    @Test
    void getAvailablePackages_shouldReturnOnlyAvailablePackages() {
        MenuPackage unavailablePackage = MenuPackage.builder()
                .id(3L)
                .name("Package C")
                .description("Unavailable package")
                .packagePrice(10000.0)
                .goodForPax(30)
                .available(false)
                .build();

        when(menuPackageRepo.findAll()).thenReturn(List.of(packageA, packageB, unavailablePackage));

        List<RecommendationResponse> response = recommendationService.getAvailablePackages();

        assertThat(response).hasSize(2);
        assertThat(response.get(0).getPackageName()).isEqualTo("Package A");
        assertThat(response.get(1).getPackageName()).isEqualTo("Package B");

        verify(menuPackageRepo, times(1)).findAll();
    }

    @Test
    void getMostBoughtPackages_shouldReturnMostBoughtPackages() {
        List<MostBoughtPackageResponse> mostBought = List.of(
                new MostBoughtPackageResponse(1L, "Package A", 5L),
                new MostBoughtPackageResponse(2L, "Package B", 2L)
        );

        when(bookingRepo.findMostBoughtPackages()).thenReturn(mostBought);

        List<MostBoughtPackageResponse> response = recommendationService.getMostBoughtPackages();

        assertThat(response).hasSize(2);
        assertThat(response.get(0).getPackageName()).isEqualTo("Package A");
        assertThat(response.get(0).getTotalBookings()).isEqualTo(5L);

        verify(bookingRepo, times(1)).findMostBoughtPackages();
    }

    @Test
    void getMustTryPackages_shouldReturnHighestRatedPackages() {
        List<MustTryPackageResponse> mustTry = List.of(
                new MustTryPackageResponse(1L, "Package A", 5.0, 3L),
                new MustTryPackageResponse(2L, "Package B", 4.5, 2L)
        );

        when(feedbackRepo.findMustTryPackages()).thenReturn(mustTry);

        List<MustTryPackageResponse> response = recommendationService.getMustTryPackages();

        assertThat(response).hasSize(2);
        assertThat(response.get(0).getPackageName()).isEqualTo("Package A");
        assertThat(response.get(0).getAverageRating()).isEqualTo(5.0);
        assertThat(response.get(0).getTotalReviews()).isEqualTo(3L);

        verify(feedbackRepo, times(1)).findMustTryPackages();
    }
}