import { apiRequest, peso, safe, assetUrl } from './customer-api.js';
import { initCustomerLayout } from './customer-layout.js';

initCustomerLayout();

const featuredPackages = document.getElementById('featuredPackages');
const eventGallery = document.getElementById('eventGallery');
const galleryDots = document.getElementById('galleryDots');
const galleryPrev = document.getElementById('galleryPrev');
const galleryNext = document.getElementById('galleryNext');

const galleryImages = [
  '473825423_3893368667598889_1641253395558002992_n.jpg',
  '119312338_2724014721200962_6831450921133745787_n.jpg',
  '152183225_2851848075084292_1876565973352918463_n.jpg',
  '152645594_2851848121750954_2790343199446987781_n.jpg',
  '152905693_2851848311750935_2569787795441986725_n.jpg',
  '152996398_2851848161750950_620976075090334974_n.jpg',
  '153119018_2851848131750953_1306951446468986539_n.jpg',
  '153165376_2851848171750949_1331594943323574972_n.jpg',
  '83734539_2535179610084475_1732255585736327168_n.jpg',
  '84419164_2535179636751139_5843275385273319424_n.jpg',
  '84595357_2535179586751144_4863410087391133696_n.jpg',
  '84635919_2535179530084483_1075877006861664256_n.jpg'
];

let currentGalleryIndex = 0;
let touchStartX = 0;

renderEventGallery();
loadFeaturedPackages();

function renderEventGallery() {
  if (!eventGallery) return;

  eventGallery.innerHTML = galleryImages.map((fileName, index) => {
    return `
      <figure class="gallery-slide" data-gallery-slide="${index}">
        <img src="Pictures/${fileName}" alt="Saneth Catering event photo ${index + 1}" loading="${index === 0 ? 'eager' : 'lazy'}">
      </figure>
    `;
  }).join('');

  if (galleryDots) {
    galleryDots.innerHTML = galleryImages.map((_, index) => `
      <button class="slider-dot" type="button" data-gallery-dot="${index}" aria-label="Show photo ${index + 1}"></button>
    `).join('');

    galleryDots.addEventListener('click', event => {
      const dot = event.target.closest('[data-gallery-dot]');
      if (!dot) return;
      setGallerySlide(Number(dot.dataset.galleryDot));
    });
  }

  galleryPrev?.addEventListener('click', () => setGallerySlide(currentGalleryIndex - 1));
  galleryNext?.addEventListener('click', () => setGallerySlide(currentGalleryIndex + 1));

  eventGallery.addEventListener('touchstart', event => {
    touchStartX = event.touches[0].clientX;
  }, { passive: true });

  eventGallery.addEventListener('touchend', event => {
    const touchEndX = event.changedTouches[0].clientX;
    const distance = touchEndX - touchStartX;
    if (Math.abs(distance) < 44) return;
    setGallerySlide(currentGalleryIndex + (distance < 0 ? 1 : -1));
  });

  document.addEventListener('keydown', event => {
    if (event.key === 'ArrowLeft') setGallerySlide(currentGalleryIndex - 1);
    if (event.key === 'ArrowRight') setGallerySlide(currentGalleryIndex + 1);
  });

  setGallerySlide(0);
}

function setGallerySlide(index) {
  if (!eventGallery) return;
  currentGalleryIndex = (index + galleryImages.length) % galleryImages.length;
  eventGallery.style.setProperty('--slide-index', currentGalleryIndex);

  document.querySelectorAll('[data-gallery-slide]').forEach(slide => {
    slide.classList.toggle('active', Number(slide.dataset.gallerySlide) === currentGalleryIndex);
  });

  document.querySelectorAll('[data-gallery-dot]').forEach(dot => {
    const isActive = Number(dot.dataset.galleryDot) === currentGalleryIndex;
    dot.classList.toggle('active', isActive);
    dot.setAttribute('aria-current', isActive ? 'true' : 'false');
  });
}

async function loadFeaturedPackages() {
  if (!featuredPackages) return;
  featuredPackages.innerHTML = '<div class="skeleton">Loading packages...</div>';

  try {
    const data = await apiRequest('/api/menu-packages');
    if (!Array.isArray(data)) throw new Error('Invalid packages response. Please refresh.');
    const packages = await loadFeaturedPackageItems(
      data.filter(pkg => pkg.available !== false).slice(0, 3)
    );

    if (!packages.length) {
      featuredPackages.innerHTML = '<div class="skeleton">No packages available yet.</div>';
      return;
    }

    featuredPackages.innerHTML = packages.map(renderPackageCard).join('');
  } catch (error) {
    featuredPackages.innerHTML = `<div class="skeleton">${safe(error.message)}</div>`;
  }
}

async function loadFeaturedPackageItems(packages) {
  return Promise.all(packages.map(async pkg => {
    if (!pkg.items?.length && Array.isArray(pkg.menuItems)) pkg = { ...pkg, items: pkg.menuItems };
    if (Array.isArray(pkg.items) && pkg.items.length) return pkg;

    try {
      const details = await apiRequest(`/api/menu-packages/${encodeURIComponent(pkg.id)}`);
      if (details && !details.items?.length && Array.isArray(details.menuItems)) details.items = details.menuItems;
      if (!details || String(details.id) !== String(pkg.id) || !Array.isArray(details.items)) {
        throw new Error('Package menu items were not returned.');
      }
      return { ...pkg, ...details };
    } catch (error) {
      return { ...pkg, itemDetailsError: error.message || 'Could not load package menu items.' };
    }
  }));
}

function renderPackageCard(pkg) {
  const image = pkg.imageUrl
    ? `<img src="${safe(assetUrl(pkg.imageUrl))}" alt="${safe(pkg.name)}">`
    : `<div class="placeholder">${safe((pkg.name || 'S').charAt(0))}</div>`;
  const items = (pkg.items || []).map(item => `<span class="chip">${safe(item.name)}</span>`).join('');
  const includedMenu = /^package\s+a$/i.test(String(pkg.name || '').trim())
    ? '<p class="package-desc">Good for birthday</p>'
    : /^package\s+b$/i.test(String(pkg.name || '').trim())
    ? '<p class="package-desc">Good for Reunion</p>'
    : /^package\s+c$/i.test(String(pkg.name || '').trim())
    ? '<p class="package-desc">Good for Christmas parties</p>'
    : items
    ? `<div class="package-included-menu"><strong>Included menu</strong><div class="chip-row">${items}</div></div>`
    : `<p class="package-desc">${/^package\s+c$/i.test(String(pkg.name || '').trim()) ? 'Good for Christmas parties.' : /^package\s+b$/i.test(String(pkg.name || '').trim()) ? 'Good for reunions.' : 'Good for birthdays.'}</p>`;

  return `
    <article class="package-card">
      <div class="package-image">${image}</div>
      <div class="package-body">
        <div class="package-title-row">
          <h3>${safe(pkg.name)}</h3>
          <span class="price">${peso(pkg.packagePrice)}</span>
        </div>
        ${renderPackageDescription(pkg)}
        <div class="chip-row">
          <span class="chip">Good for ${safe(pkg.goodForPax)} pax</span>
          <span class="chip">${pkg.available === false ? 'Unavailable' : 'Available'}</span>
        </div>
        ${includedMenu}
        <div class="package-actions">
          <a class="btn btn-dark" href="customer-booking.html?packageId=${pkg.id}">Book this</a>
          <a class="btn btn-ghost" href="customer-packages.html">View all</a>
        </div>
      </div>
    </article>
  `;
}

function renderPackageDescription(pkg) {
  const description = String(pkg.description || '').trim();
  if (!/^package\s+[abc]$/i.test(String(pkg.name || '').trim()) || !description) {
    return `<p class="package-desc">${safe(description || 'A complete catering package for your event.')}</p>`;
  }
  const inclusions = description.replace(/^inclusions?\s*:?\s*/i, '')
    .split(/[;\r\n]+|,\s*:/)
    .map(item => item.replace(/^[\s:•-]+|[\s,;]+$/g, '').trim())
    .filter(Boolean);
  return `<div class="package-desc package-inclusions"><strong>Inclusions</strong><ul>${inclusions.map(item => `<li>${safe(item)}</li>`).join('')}</ul></div>`;
}