package com.catering.Saneth.dto.request;

import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;

@Setter
@Getter
public class AdminUpdateBookingRequest {

    private String eventType;

    private LocalDate eventDate;

    private LocalTime eventTime;
    private String eventPlace;

    @Positive(message = "Number of pax must be greater than zero")
    private Integer numberOfPax;

    @Positive(message = "Menu package must be valid")
    private Long menuPackageId;

    private String adminNote;

}
