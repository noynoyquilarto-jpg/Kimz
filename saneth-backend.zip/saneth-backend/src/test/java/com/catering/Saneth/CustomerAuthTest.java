package com.catering.Saneth;

import com.catering.Saneth.repository.CustomerRepo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import tools.jackson.databind.ObjectMapper;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties="saneth.mail.enabled=true")
@AutoConfigureMockMvc
class CustomerAuthTest {
    @Autowired MockMvc mvc;
    @Autowired CustomerRepo customers;
    @Autowired PasswordEncoder encoder;
    @Autowired ObjectMapper json;
    @org.springframework.test.context.bean.override.mockito.MockitoBean
    org.springframework.mail.javamail.JavaMailSender mail;
    @Autowired com.catering.Saneth.service.CustomerVerificationService verification;
    @Autowired com.catering.Saneth.service.NotificationDispatcher dispatcher;
    @Autowired com.catering.Saneth.repository.EmailNotificationRepo notifications;
    @org.junit.jupiter.api.BeforeEach void mimeMessages() {
        org.mockito.Mockito.when(mail.createMimeMessage()).thenAnswer(invocation -> new jakarta.mail.internet.MimeMessage(jakarta.mail.Session.getInstance(new java.util.Properties())));
    }

    @Test
    void expiredCodesAttemptLimitResendAndDeliveryFailure() throws Exception {
        var c = new com.catering.Saneth.model.Customer();
        c.setFirstName("Test"); c.setLastName("Expiry"); c.setEmail("expiry@example.invalid");
        c.setPassword(encoder.encode("Password123"));
        c.setVerificationHash(encoder.encode("123456"));
        c.setVerificationExpiresAt(java.time.Instant.now().minusSeconds(1));
        customers.saveAndFlush(c);
        assertThat(verification.verify(c.getEmail(), "123456")).isFalse();
        c.setVerificationExpiresAt(java.time.Instant.now().plusSeconds(300));
        customers.saveAndFlush(c);
        for(int i=0;i<5;i++) assertThat(verification.verify(c.getEmail(), "999999")).isFalse();
        assertThat(verification.verify(c.getEmail(), "123456")).isFalse();
        String notificationId = verification.resend(c.getEmail());
        assertThat(verification.verify(c.getEmail(), "123456")).isFalse();
        String code = deliverCode(notificationId);
        assertThat(verification.verify(c.getEmail(), code)).isTrue();
        org.mockito.Mockito.doThrow(new org.springframework.mail.MailSendException("offline"))
                .when(mail).send(org.mockito.ArgumentMatchers.any(jakarta.mail.internet.MimeMessage.class));
        var failed = new com.catering.Saneth.model.Customer();
        failed.setFirstName("Test"); failed.setLastName("Failure"); failed.setEmail("failure@example.invalid");
        failed.setPassword(encoder.encode("Password123"));
        String failedId = verification.register(failed);
        dispatcher.deliver(failedId);
        assertThat(customers.existsByEmailIgnoreCase(failed.getEmail())).isTrue();
        assertThat(notifications.findById(failedId).orElseThrow().getStatus()).isEqualTo("RETRY_PENDING");
    }

    @Test
    void verificationCodeBelongsToOneCustomerAndIsConsumedOnSuccess() {
        String suffix = java.util.UUID.randomUUID().toString();
        var first = new com.catering.Saneth.model.Customer();
        first.setFirstName("First"); first.setLastName("Customer"); first.setEmail("first-"+suffix+"@example.invalid");
        first.setPassword(encoder.encode("Password123")); first.setVerificationHash(encoder.encode("123456"));
        first.setVerificationExpiresAt(java.time.Instant.now().plusSeconds(300)); customers.saveAndFlush(first);
        var second = new com.catering.Saneth.model.Customer();
        second.setFirstName("Second"); second.setLastName("Customer"); second.setEmail("second-"+suffix+"@example.invalid");
        second.setPassword(encoder.encode("Password123")); second.setVerificationHash(encoder.encode("654321"));
        second.setVerificationExpiresAt(java.time.Instant.now().plusSeconds(300)); customers.saveAndFlush(second);
        assertThat(verification.verify(second.getEmail(), "123456")).isFalse();
        assertThat(customers.findById(second.getId()).orElseThrow().isEmailVerified()).isFalse();
        assertThat(verification.verify(first.getEmail(), "123456")).isTrue();
        var verified = customers.findById(first.getId()).orElseThrow();
        assertThat(verified.isEmailVerified()).isTrue();
        assertThat(verified.getVerificationHash()).isNull();
        assertThat(verified.getVerificationExpiresAt()).isNull();
        assertThat(verification.verify(first.getEmail(), "123456")).isFalse();
    }

    @Test
    void registrationLoginAndRoleIsolation() throws Exception {
        String registration = """
            {"firstName":"Test","lastName":"Customer","email":"Customer@example.invalid",
             "password":"CustomerPassword123","confirmPassword":"CustomerPassword123"}
            """;
        mvc.perform(post("/api/customer/auth/register").contentType(MediaType.APPLICATION_JSON).content(registration))
                .andExpect(status().isCreated()).andExpect(jsonPath("$.notificationId").isString())
                .andExpect(jsonPath("$.verificationStatus").value("UNVERIFIED"))
                .andExpect(jsonPath("$.email").value("customer@example.invalid"))
                .andExpect(jsonPath("$.code").doesNotExist()).andExpect(jsonPath("$.otp").doesNotExist());
        assertThat(encoder.matches("CustomerPassword123", customers.findByEmailIgnoreCase("customer@example.invalid").orElseThrow().getPassword())).isTrue();
        mvc.perform(post("/api/customer/auth/login").contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"customer@example.invalid\",\"password\":\"CustomerPassword123\"}"))
                .andExpect(status().isForbidden());
        String id = notifications.findAll().stream().filter(n -> java.util.Objects.equals(n.getCustomerId(), customers.findByEmailIgnoreCase("customer@example.invalid").orElseThrow().getId()) && "QUEUED".equals(n.getStatus())).findFirst().orElseThrow().getId();
        String code = deliverCode(id);
        mvc.perform(get("/api/customer/auth/notifications/"+id))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("SMTP_ACCEPTED"))
                .andExpect(jsonPath("$.code").doesNotExist()).andExpect(jsonPath("$.encryptedContent").doesNotExist());
        assertThat(customers.findByEmailIgnoreCase("customer@example.invalid").orElseThrow().getVerificationHash()).isNotEqualTo(code);
        mvc.perform(post("/api/customer/auth/resend").contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"customer@example.invalid\"}"))
                .andExpect(status().isTooManyRequests());
        mvc.perform(post("/api/customer/auth/verify").contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"customer@example.invalid\",\"code\":\"" + code + "\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.verificationStatus").value("VERIFIED"))
                .andExpect(jsonPath("$.token").doesNotExist());
        mvc.perform(post("/api/customer/auth/verify").contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"customer@example.invalid\",\"code\":\"" + code + "\"}"))
                .andExpect(status().isBadRequest());
        mvc.perform(post("/api/customer/auth/register").contentType(MediaType.APPLICATION_JSON).content(registration))
                .andExpect(status().isConflict());
        mvc.perform(post("/api/customer/auth/login").contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"customer@example.invalid\",\"password\":\"wrong\"}"))
                .andExpect(status().isUnauthorized());
        String login = mvc.perform(post("/api/customer/auth/login").contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"CUSTOMER@example.invalid\",\"password\":\"CustomerPassword123\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.role").value("CUSTOMER"))
                .andReturn().getResponse().getContentAsString();
        String token = json.readTree(login).get("token").asText();
        mvc.perform(get("/api/admin/auth/me").header("Authorization", "Bearer " + token))
                .andExpect(status().isForbidden());
        mvc.perform(post("/api/customer/auth/register").contentType(MediaType.APPLICATION_JSON)
                .content(registration.replace("Customer@example.invalid", "other@example.invalid")
                        .replace("\"confirmPassword\":\"CustomerPassword123\"", "\"confirmPassword\":\"different\"")))
                .andExpect(status().isBadRequest());
    }

    private String deliverCode(String id) throws Exception {
        dispatcher.deliver(id);
        var sent = org.mockito.ArgumentCaptor.forClass(jakarta.mail.internet.MimeMessage.class);
        org.mockito.Mockito.verify(mail, org.mockito.Mockito.atLeastOnce()).send(sent.capture());
        String text = plainText(sent.getValue());
        return java.util.regex.Pattern.compile("(?m)^[0-9]{6}$").matcher(text).results().findFirst().orElseThrow().group();
    }
    private String plainText(jakarta.mail.Part part) throws Exception {
        if (part.isMimeType("text/plain")) return part.getContent().toString();
        if (part.getContent() instanceof jakarta.mail.Multipart multipart) {
            for (int i=0;i<multipart.getCount();i++) { String text=plainText(multipart.getBodyPart(i)); if (!text.isEmpty()) return text; }
        }
        return "";
    }
}
