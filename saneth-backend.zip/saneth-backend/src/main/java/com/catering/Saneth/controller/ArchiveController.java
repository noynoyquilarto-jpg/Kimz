package com.catering.Saneth.controller;

import com.catering.Saneth.dto.request.ArchiveBookingRequest;
import com.catering.Saneth.dto.response.BookingResponse;
import com.catering.Saneth.service.AdminAuditLogService;
import com.catering.Saneth.service.ArchiveService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@org.springframework.transaction.annotation.Transactional
@RestController
@RequestMapping("/api/admin/archives")
@RequiredArgsConstructor
public class ArchiveController {

    private final ArchiveService archiveService;
    private final AdminAuditLogService adminAuditLogService;

    @PutMapping("/bookings/{id}")
    public BookingResponse archiveBooking(
            @PathVariable Long id,
            @Valid @RequestBody ArchiveBookingRequest request
    ) {
        BookingResponse response = archiveService.archiveBooking(id, request.getReason());
        adminAuditLogService.record("BOOKING_ARCHIVED", "BOOKING", id, request.getReason());
        return response;
    }

    @GetMapping("/bookings")
    public List<BookingResponse> getArchivedBookings() {
        return archiveService.getArchivedBookings();
    }
}
