ALTER TABLE customers ADD COLUMN email_verified BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE customers ALTER COLUMN email_verified SET DEFAULT FALSE;
ALTER TABLE customers ADD COLUMN verification_hash VARCHAR(255);
ALTER TABLE customers ADD COLUMN verification_expires_at TIMESTAMP(6) NULL;
ALTER TABLE customers ADD COLUMN verification_sent_at TIMESTAMP(6) NULL;
ALTER TABLE customers ADD COLUMN verification_attempts INT NOT NULL DEFAULT 0;
