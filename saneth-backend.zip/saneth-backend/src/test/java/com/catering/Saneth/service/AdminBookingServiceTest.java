package com.catering.Saneth.service;

import com.catering.Saneth.dto.response.BookingResponse;
import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.MenuCategory;
import com.catering.Saneth.model.MenuItem;
import com.catering.Saneth.model.MenuPackage;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.model.enums.PaymentMethod;
import com.catering.Saneth.model.enums.PaymentStatus;
import com.catering.Saneth.repository.BookingRepo;
import com.catering.Saneth.repository.MenuPackageRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AdminBookingServiceTest {

    @Mock
    private BookingRepo bookingRepo;

    @Mock
    private BookingTrackingEmailService bookingTrackingEmailService;

    @Mock
    private ReceiptEmailService receiptEmailService;

    @Mock
    private MenuPackageRepo menuPackageRepo;

    @Mock
    private com.catering.Saneth.repository.BookingPaymentRepo bookingPaymentRepo;

    @Test
    void confirmationRejectsFullDateWithoutSaving() {
        booking.setBookingStatus(BookingStatus.PENDING);
        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingRepo.countByEventDateAndBookingStatusIn(booking.getEventDate(), BookingService.CAPACITY_STATUSES)).thenReturn(3L);
        var request = new com.catering.Saneth.dto.request.ConfirmBookingRequest();
        request.setQuotedPrice(new java.math.BigDecimal("1000"));
        request.setDownPayment(new java.math.BigDecimal("300"));
        assertThat(assertThrows(RuntimeException.class, () -> adminBookingService.confirmBooking(1L, request))).hasMessageContaining("fully booked");
        verify(bookingRepo).lockDailyCapacity();
        verify(bookingRepo, never()).save(any());
    }

    @Test void editPaymentRejectsMissingMethodBeforeInsert() {
        booking.setBookingStatus(BookingStatus.CONFIRMED);
        booking.setQuotedPrice(new java.math.BigDecimal("20000"));
        booking.setPaymentMethod(null);
        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(1L)).thenReturn(List.of());
        var request = new com.catering.Saneth.dto.request.UpdatePaymentRequest();
        request.setDownPaymentAmount(10000.0);
        assertThat(assertThrows(RuntimeException.class, () -> adminBookingService.updatePayment(1L, request)))
                .hasMessageContaining("Select a payment method");
        verify(bookingPaymentRepo, never()).save(any());
    }

    @Test void editPaymentSavesSelectedMethodOnLedger() {
        booking.setBookingStatus(BookingStatus.CONFIRMED);
        booking.setQuotedPrice(new java.math.BigDecimal("20000"));
        booking.setPaymentMethod(null);
        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingRepo.save(any())).thenAnswer(call -> call.getArgument(0));
        when(bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(1L)).thenReturn(List.of());
        var request = new com.catering.Saneth.dto.request.UpdatePaymentRequest();
        request.setDownPaymentAmount(10000.0);
        request.setPaymentMethod(PaymentMethod.GCASH);
        adminBookingService.updatePayment(1L, request);
        verify(bookingPaymentRepo).save(argThat(payment -> payment.getPaymentMethod() == PaymentMethod.GCASH));
    }

    @Test
    void editPaymentUpdatesTotalAndPreservesHistory() {
        booking.setBookingStatus(BookingStatus.CONFIRMED);
        booking.setQuotedPrice(new java.math.BigDecimal("20000"));
        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingRepo.save(any())).thenAnswer(call -> call.getArgument(0));
        when(bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(1L)).thenReturn(List.of(
                com.catering.Saneth.model.BookingPayment.builder().amount(15000.0).build()));
        var request = new com.catering.Saneth.dto.request.UpdatePaymentRequest();
        request.setDownPaymentAmount(20000.0);
        adminBookingService.updatePayment(1L, request);
        assertThat(booking.getDownPaymentAmount()).isEqualTo(20000.0);
        assertThat(booking.getPaymentStatus()).isEqualTo(PaymentStatus.FULLY_PAID);
        verify(bookingPaymentRepo).save(argThat(payment -> payment.getAmount() == 5000.0));
    }

    @InjectMocks
    private AdminBookingService adminBookingService;

    private Booking booking;
    private MenuPackage menuPackage;

    @BeforeEach
    void setUp() {
        menuPackage = MenuPackage.builder()
                .id(1L)
                .name("Package A")
                .packagePrice(15000.0)
                .goodForPax(50)
                .available(true)
                .items(List.of(MenuItem.builder()
                        .id(2L)
                        .name("Rice")
                        .category(MenuCategory.builder().id(1L).name("Sides").build())
                        .build()))
                .build();

        booking = Booking.builder()
                .id(1L)
                .bookingReference("CAT-2026-0001")
                .customerName("Juan Dela Cruz")
                .email("juan@gmail.com")
                .phoneNumber("09123456789")
                .customerAddress("Barangay Anono-o, Guimbal")
                .eventPlace("Jaro Plaza Function Hall")
                .eventDate(LocalDate.of(2026, 6, 20))
                .eventTime(LocalTime.of(18, 0))
                .eventType("Birthday")
                .numberOfPax(50)
                .menuPackage(menuPackage)
                .paymentMethod(PaymentMethod.GCASH)
                .downPaymentAmount(5000.0)
                .paymentReferenceNumber("GCASH123456")
                .bookingStatus(BookingStatus.PENDING)
                .paymentStatus(PaymentStatus.NOT_REQUIRED_YET)
                .build();
    }

    @Test
    void getAllBookings_shouldReturnBookingList() {
        when(bookingRepo.findByBookingStatusNotOrderByCreatedAtDesc(BookingStatus.ARCHIVED)).thenReturn(List.of(booking));

        List<BookingResponse> response = adminBookingService.getAllBookings();

        assertThat(response).hasSize(1);
        assertThat(response.get(0).getBookingReference()).isEqualTo("CAT-2026-0001");
        assertThat(response.get(0).getCustomerName()).isEqualTo("Juan Dela Cruz");
        assertThat(response.get(0).getPackageMenuItems())
                .extracting(item -> item.getName())
                .containsExactly("Rice");

        verify(bookingRepo, times(1)).findByBookingStatusNotOrderByCreatedAtDesc(BookingStatus.ARCHIVED);
    }

    @Test
    void getBookingById_shouldReturnBooking_whenBookingExists() {
        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));

        BookingResponse response = adminBookingService.getBookingById(1L);

        assertThat(response).isNotNull();
        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getBookingReference()).isEqualTo("CAT-2026-0001");

        verify(bookingRepo, times(1)).findForUpdateById(1L);
    }

    @Test
    void getBookingById_shouldThrowException_whenBookingNotFound() {
        when(bookingRepo.findForUpdateById(99L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            adminBookingService.getBookingById(99L);
        });

        assertThat(exception.getMessage()).isEqualTo("Booking does not exist!");

        verify(bookingRepo, times(1)).findForUpdateById(99L);
    }

    @Test
    void statusEndpointCannotBypassQuote() {
        assertThrows(RuntimeException.class, () -> adminBookingService.updateBookingStatus(1L, BookingStatus.CONFIRMED));
        verifyNoInteractions(bookingRepo);
    }

    @Test
    void confirmBooking_shouldSetStatusToConfirmed() {
        Booking confirmedBooking = Booking.builder()
                .id(booking.getId())
                .bookingReference(booking.getBookingReference())
                .customerName(booking.getCustomerName())
                .email(booking.getEmail())
                .phoneNumber(booking.getPhoneNumber())
                .eventDate(booking.getEventDate())
                .eventTime(booking.getEventTime())
                .eventType(booking.getEventType())
                .eventPlace(booking.getEventPlace())
                .numberOfPax(booking.getNumberOfPax())
                .menuPackage(menuPackage)
                .bookingStatus(BookingStatus.CONFIRMED)
                .paymentStatus(PaymentStatus.AWAITING_PAYMENT)
                .quotedPrice(confirmation().getQuotedPrice())
                .downPayment(confirmation().getDownPayment())
                .build();

        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingRepo.existsByEventDateAndEventTimeAndBookingStatusAndIdNot(
                booking.getEventDate(),
                booking.getEventTime(),
                BookingStatus.CONFIRMED,
                booking.getId()
        )).thenReturn(false);
        when(bookingRepo.save(any(Booking.class))).thenReturn(confirmedBooking);

        BookingResponse response = adminBookingService.confirmBooking(1L, confirmation());
        verify(bookingTrackingEmailService).sendAfterBookingConfirmed(
                eq(confirmedBooking), eq(confirmedBooking.getQuotedPrice()),
                eq(confirmedBooking.getDownPayment()), anyList());
        verify(receiptEmailService, never()).sendConfirmation(any());

        assertThat(response.getBookingStatus()).isEqualTo(BookingStatus.CONFIRMED);

        verify(bookingRepo, times(1)).findForUpdateById(1L);
        verify(bookingRepo, times(1)).save(any(Booking.class));
    }

    @Test
    void completeBooking_shouldSetStatusToCompleted() {
        booking.setEventDate(java.time.LocalDate.now(java.time.ZoneId.of("Asia/Manila")).minusDays(1));
        booking.setBookingStatus(BookingStatus.CONFIRMED);
        booking.setPaymentStatus(PaymentStatus.FULLY_PAID);
        booking.setQuotedPrice(java.math.BigDecimal.valueOf(5000));

        Booking completedBooking = Booking.builder()
                .id(booking.getId())
                .bookingReference(booking.getBookingReference())
                .customerName(booking.getCustomerName())
                .email(booking.getEmail())
                .phoneNumber(booking.getPhoneNumber())
                .eventDate(booking.getEventDate())
                .eventTime(booking.getEventTime())
                .eventType(booking.getEventType())
                .eventPlace(booking.getEventPlace())
                .numberOfPax(booking.getNumberOfPax())
                .menuPackage(menuPackage)
                .bookingStatus(BookingStatus.COMPLETED)
                .paymentStatus(PaymentStatus.FULLY_PAID)
                .build();

        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingRepo.save(any(Booking.class))).thenReturn(completedBooking);

        BookingResponse response = adminBookingService.completeBooking(1L);

        assertThat(response.getBookingStatus()).isEqualTo(BookingStatus.COMPLETED);

        verify(bookingRepo, times(1)).findForUpdateById(1L);
        verify(bookingRepo, times(1)).save(any(Booking.class));
    }

    @Test
    void cancelBooking_shouldSetStatusToCancelledAndSaveReason() {
        Booking cancelledBooking = booking;
        cancelledBooking.setBookingStatus(BookingStatus.CANCELLED);
        cancelledBooking.setCancellationReason("Customer requested cancellation");

        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingRepo.save(any(Booking.class))).thenReturn(cancelledBooking);

        BookingResponse response = adminBookingService.cancelBooking(1L, "Customer requested cancellation");

        assertThat(response.getBookingStatus()).isEqualTo(BookingStatus.CANCELLED);

        verify(bookingRepo, times(1)).findForUpdateById(1L);
        verify(bookingRepo, times(1)).save(any(Booking.class));
    }
    private com.catering.Saneth.dto.request.ConfirmBookingRequest confirmation() {
        var request = new com.catering.Saneth.dto.request.ConfirmBookingRequest();
        request.setQuotedPrice(java.math.BigDecimal.valueOf(15000));
        request.setDownPayment(java.math.BigDecimal.valueOf(4500));
        return request;
    }
}
