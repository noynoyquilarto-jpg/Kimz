package com.catering.Saneth.controller;

import com.catering.Saneth.dto.request.MenuSubCategoryRequest;
import com.catering.Saneth.dto.response.MenuSubCategoryResponse;
import com.catering.Saneth.service.MenuSubCategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/menu-subcategories")
@RequiredArgsConstructor
public class MenuSubCategoryController {

    private final MenuSubCategoryService service;

    @PostMapping
    public MenuSubCategoryResponse create(@jakarta.validation.Valid @RequestBody MenuSubCategoryRequest request){
        return service.create(request);
    }

    @GetMapping
    public List<MenuSubCategoryResponse> getAll(){
        return service.getAll();
    }

    @GetMapping("/public")
    public List<MenuSubCategoryResponse> getAllPublic() {
        return service.getAll();
    }

}