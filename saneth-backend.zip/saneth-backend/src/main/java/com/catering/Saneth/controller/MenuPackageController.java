package com.catering.Saneth.controller;

import com.catering.Saneth.dto.request.MenuPackageRequest;
import com.catering.Saneth.dto.response.MenuPackageResponse;
import com.catering.Saneth.service.AdminAuditLogService;
import com.catering.Saneth.service.MenuPackageService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@org.springframework.transaction.annotation.Transactional
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class MenuPackageController {

    private final MenuPackageService menuPackageService;
    private final AdminAuditLogService adminAuditLogService;

    @PostMapping("/admin/menu-packages")
    public MenuPackageResponse createMenuPackage(@Valid @RequestBody MenuPackageRequest request) {
        MenuPackageResponse response = menuPackageService.createMenuPackage(request);
        adminAuditLogService.record("MENU_PACKAGE_CREATED", "MENU_PACKAGE", response.getId(), response.getName());
        return response;
    }

    @GetMapping("/menu-packages")
    public List<MenuPackageResponse> getAllMenuPackages() {
        return menuPackageService.getAllMenuPackages();
    }

    @GetMapping("/menu-packages/{id}")
    public MenuPackageResponse getMenuPackageById(@PathVariable Long id) {
        return menuPackageService.getMenuPackageById(id);
    }

    @GetMapping("/admin/menu-packages/{id}/items")
    public List<com.catering.Saneth.dto.response.MenuItemResponse> getPackageItems(@PathVariable Long id) {
        return menuPackageService.getPackageItems(id);
    }

    @PutMapping("/admin/menu-packages/{id}")
    public MenuPackageResponse updateMenuPackage(
            @PathVariable Long id,
            @Valid @RequestBody MenuPackageRequest request
    ) {
        MenuPackageResponse response = menuPackageService.updateMenuPackage(id, request);
        adminAuditLogService.record("MENU_PACKAGE_UPDATED", "MENU_PACKAGE", id, response.getName());
        return response;
    }

    @DeleteMapping("/admin/menu-packages/{id}")
    public String deleteMenuPackage(@PathVariable Long id) {
        menuPackageService.deleteMenuPackage(id);
        adminAuditLogService.record("MENU_PACKAGE_DELETED", "MENU_PACKAGE", id, "Menu package deleted");
        return "Menu package deleted successfully";
    }
}
