package com.catering.Saneth.repository;

import com.catering.Saneth.model.EmailNotification;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.data.domain.Pageable;
import java.time.Instant;
import java.util.*;

public interface EmailNotificationRepo extends JpaRepository<EmailNotification, String> {
    Optional<EmailNotification> findByEventKey(String eventKey);
    long countByCustomerIdAndKindAndCreatedAtAfter(Long customerId, String kind, Instant since);
    List<EmailNotification> findByBookingIdOrderByCreatedAtDesc(Long bookingId);
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    List<EmailNotification> findByCustomerIdAndStatusIn(Long customerId, Collection<String> statuses);
    @Query("select n.id from EmailNotification n where n.status in ('QUEUED','RETRY_PENDING','SENDING') and n.nextAttemptAt <= :now order by n.createdAt")
    List<String> due(@Param("now") Instant now, Pageable page);
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select n from EmailNotification n where n.id = :id")
    Optional<EmailNotification> lock(@Param("id") String id);
}
