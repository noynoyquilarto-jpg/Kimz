package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.BookingRequest;
import com.catering.Saneth.dto.request.TrackBookingRequest;
import com.catering.Saneth.dto.response.BookingResponse;
import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.MenuPackage;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.model.enums.PaymentMethod;
import com.catering.Saneth.model.enums.PaymentStatus;
import com.catering.Saneth.repository.BookingRepo;
import com.catering.Saneth.repository.MenuPackageRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookingServiceTest {

    @Mock
    private BookingRepo bookingRepo;

    @Mock
    private MenuPackageRepo menuPackageRepo;

    @Mock
    private com.catering.Saneth.repository.BookingMenuItemRepo bookingMenuItemRepo;
    @Mock
    private BookingTrackingEmailService bookingTrackingEmailService;

    @InjectMocks
    private BookingService bookingService;

    private MenuPackage menuPackage;
    private Booking booking;

    @Test
    void dateAvailabilityUsesConfirmedAndCompletedAndClampsRemainingSlots() {
        var date = LocalDate.now().plusDays(10);
        for (long count : new long[]{0, 2, 3, 4}) {
            when(bookingRepo.countByEventDateAndBookingStatusIn(date, List.of(BookingStatus.CONFIRMED, BookingStatus.COMPLETED))).thenReturn(count);
            var result = bookingService.getDateAvailability(date);
            assertThat(result.remainingSlots()).isEqualTo(Math.max(0, 3 - count));
            assertThat(result.available()).isEqualTo(count < 3);
        }
    }

    @BeforeEach
    void setUp() {
        menuPackage = MenuPackage.builder()
                .id(1L)
                .name("Package A")
                .description("Budget-friendly package")
                .packagePrice(15000.0)
                .goodForPax(50)
                .available(true)
                .build();

        booking = Booking.builder()
                .id(1L)
                .bookingReference("CAT-2026-0001")
                .customerName("Juan Dela Cruz")
                .email("juan@gmail.com")
                .phoneNumber("09123456789")
                .customerAddress("Barangay Anono-o, Guimbal")
                .eventPlace("Jaro Plaza Function Hall")
                .eventDate(LocalDate.now().plusDays(10))
                .eventTime(LocalTime.of(18, 0))
                .eventType("Birthday")
                .numberOfPax(50)
                .menuPackage(menuPackage)
                .paymentMethod(PaymentMethod.GCASH)
                .downPaymentAmount(5000.0)
                .paymentReferenceNumber("GCASH123456")
                .bookingStatus(BookingStatus.PENDING)
                .paymentStatus(PaymentStatus.NOT_REQUIRED_YET)
                .build();
    }

    @Test
    void createBooking_shouldReturnCreatedBooking() {
        BookingRequest request = new BookingRequest();
        request.setBookingType(com.catering.Saneth.model.enums.BookingType.PACKAGE);
        request.setNumberOfPax(50);
        request.setEmail("juan@gmail.com");
        request.setPhoneNumber("09123456789");
        request.setCustomerName("Juan Dela Cruz");
        request.setEmail("juan@gmail.com");
        request.setPhoneNumber("09123456789");
        request.setCustomerAddress("Barangay Anono-o, Guimbal");
        request.setEventPlace("Jaro Plaza Function Hall");
        request.setEventDate(LocalDate.now().plusDays(10));
        request.setEventTime(LocalTime.of(18, 0));
        request.setEventType("Birthday");
        request.setNumberOfPax(50);
        request.setMenuPackageId(1L);
        Booking firstSave = Booking.builder()
                .id(1L)
                .customerName(request.getCustomerName())
                .email(request.getEmail())
                .phoneNumber(request.getPhoneNumber())
                .customerAddress(request.getCustomerAddress())
                .eventPlace(request.getEventPlace())
                .eventDate(request.getEventDate())
                .eventTime(request.getEventTime())
                .eventType(request.getEventType())
                .numberOfPax(request.getNumberOfPax())
                .menuPackage(menuPackage)
                .downPaymentAmount(0.0)
                .bookingStatus(BookingStatus.PENDING)
                .paymentStatus(PaymentStatus.NOT_REQUIRED_YET)
                .build();

        when(menuPackageRepo.findById(1L)).thenReturn(Optional.of(menuPackage));
        when(bookingRepo.existsByEventDateAndBookingStatusInAndEmailIgnoreCaseOrEventDateAndBookingStatusInAndPhoneNumber(
                request.getEventDate(),
                List.of(BookingStatus.PENDING, BookingStatus.CONFIRMED),
                request.getEmail(),
                request.getEventDate(),
                List.of(BookingStatus.PENDING, BookingStatus.CONFIRMED),
                request.getPhoneNumber()
        )).thenReturn(false);
        when(bookingRepo.save(any(Booking.class)))
                .thenReturn(firstSave)
                .thenReturn(booking);

        BookingResponse response = bookingService.createBooking(request);

        assertThat(firstSave.getBookingReference()).isEqualTo("saneth-" + request.getEventDate().getYear() + "-0001");
        assertThat(response).isNotNull();
        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getBookingReference()).isEqualTo("CAT-2026-0001");
        assertThat(response.getCustomerName()).isEqualTo("Juan Dela Cruz");
        assertThat(response.getMenuPackageName()).isEqualTo("Package A");
        assertThat(response.getBookingStatus()).isEqualTo(BookingStatus.PENDING);
        assertThat(response.getPaymentStatus()).isEqualTo(PaymentStatus.NOT_REQUIRED_YET);

        verify(menuPackageRepo, times(1)).findById(1L);
        verify(bookingRepo, times(2)).save(any(Booking.class));
    }

    @Test
    void createBooking_shouldThrowException_whenCustomerHasActiveBookingOnSameDate() {
        BookingRequest request = new BookingRequest();
        request.setBookingType(com.catering.Saneth.model.enums.BookingType.PACKAGE);
        request.setNumberOfPax(50);
        request.setEmail("juan@gmail.com");
        request.setPhoneNumber("09123456789");
        request.setCustomerName("Juan Dela Cruz");
        request.setEmail("juan@gmail.com");
        request.setPhoneNumber("09123456789");
        request.setCustomerAddress("Barangay Anono-o, Guimbal");
        request.setEventPlace("Jaro Plaza Function Hall");
        request.setEventDate(LocalDate.now().plusDays(10));
        request.setEventTime(LocalTime.of(18, 0));
        request.setEventType("Birthday");
        request.setNumberOfPax(50);
        request.setMenuPackageId(1L);

        when(menuPackageRepo.findById(1L)).thenReturn(Optional.of(menuPackage));
        when(bookingRepo.existsByEventDateAndBookingStatusInAndEmailIgnoreCaseOrEventDateAndBookingStatusInAndPhoneNumber(
                request.getEventDate(),
                List.of(BookingStatus.PENDING, BookingStatus.CONFIRMED),
                request.getEmail(),
                request.getEventDate(),
                List.of(BookingStatus.PENDING, BookingStatus.CONFIRMED),
                request.getPhoneNumber()
        )).thenReturn(true);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.createBooking(request);
        });

        assertThat(exception.getMessage())
                .isEqualTo("You already have an active booking request for this event date. Please track your existing booking instead.");

        verify(bookingRepo, never()).save(any(Booking.class));
    }

    @Test
    void createBooking_shouldThrowException_whenEventDateIsTooSoon() {
        BookingRequest request = new BookingRequest();
        request.setBookingType(com.catering.Saneth.model.enums.BookingType.PACKAGE);
        request.setNumberOfPax(50);
        request.setEmail("juan@gmail.com");
        request.setPhoneNumber("09123456789");
        request.setEventDate(LocalDate.now().plusDays(2));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.createBooking(request);
        });

        assertThat(exception.getMessage()).isEqualTo("Bookings must be made at least 3 days before the event date.");

        verify(menuPackageRepo, never()).findById(anyLong());
        verify(bookingRepo, never()).save(any(Booking.class));
    }

    @Test
    void createBooking_shouldThrowException_whenMenuPackageNotFound() {
        BookingRequest request = new BookingRequest();
        request.setBookingType(com.catering.Saneth.model.enums.BookingType.PACKAGE);
        request.setNumberOfPax(50);
        request.setEmail("juan@gmail.com");
        request.setPhoneNumber("09123456789");
        request.setEventDate(LocalDate.now().plusDays(10));
        request.setMenuPackageId(99L);

        when(menuPackageRepo.findById(99L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.createBooking(request);
        });

        assertThat(exception.getMessage()).isEqualTo("Menu package not found.");

        verify(menuPackageRepo, times(1)).findById(99L);
        verify(bookingRepo, never()).save(any(Booking.class));
    }

    @Test
    void trackBooking_shouldReturnBooking_whenReferenceAndEmailMatch() {
        TrackBookingRequest request = new TrackBookingRequest();
        request.setBookingReference("CAT-2026-0001");
        request.setEmail("juan@gmail.com");

        when(bookingRepo.findByBookingReferenceAndEmail("CAT-2026-0001", "juan@gmail.com"))
                .thenReturn(Optional.of(booking));

        BookingResponse response = bookingService.trackBooking(request);

        assertThat(response).isNotNull();
        assertThat(response.getBookingReference()).isEqualTo("CAT-2026-0001");
        assertThat(response.getEmail()).isEqualTo("juan@gmail.com");
        assertThat(response.getMenuPackageName()).isEqualTo("Package A");

        verify(bookingRepo, times(1))
                .findByBookingReferenceAndEmail("CAT-2026-0001", "juan@gmail.com");
    }

    @Test
    void trackBooking_shouldThrowException_whenBookingNotFound() {
        TrackBookingRequest request = new TrackBookingRequest();
        request.setBookingReference("CAT-2026-9999");
        request.setEmail("wrong@gmail.com");

        when(bookingRepo.findByBookingReferenceAndEmail("CAT-2026-9999", "wrong@gmail.com"))
                .thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            bookingService.trackBooking(request);
        });

        assertThat(exception.getMessage()).isEqualTo("Booking not exist!");

        verify(bookingRepo, times(1))
                .findByBookingReferenceAndEmail("CAT-2026-9999", "wrong@gmail.com");
    }
}
