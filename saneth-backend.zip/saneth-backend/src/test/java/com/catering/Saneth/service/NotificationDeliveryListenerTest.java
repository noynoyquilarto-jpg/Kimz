package com.catering.Saneth.service;

import org.junit.jupiter.api.Test;
import org.springframework.core.task.TaskExecutor;
import org.springframework.core.task.TaskRejectedException;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class NotificationDeliveryListenerTest {
    @Test void saturatedExecutorLeavesCommittedWorkForTheScheduledWorker() {
        var dispatcher = mock(NotificationDispatcher.class);
        TaskExecutor executor = task -> { throw new TaskRejectedException("full"); };
        var listener = new NotificationDeliveryListener(dispatcher, executor, true);
        assertThatCode(() -> listener.committed(new NotificationDeliveryListener.Ready("test-id"))).doesNotThrowAnyException();
        verifyNoInteractions(dispatcher);
    }

    @Test void disabledImmediateDeliveryKeepsScheduledDeliveryAvailable() {
        var dispatcher = mock(NotificationDispatcher.class);
        var executor = mock(TaskExecutor.class);
        new NotificationDeliveryListener(dispatcher, executor, false)
                .committed(new NotificationDeliveryListener.Ready("test-id"));
        verifyNoInteractions(executor, dispatcher);
    }
}
