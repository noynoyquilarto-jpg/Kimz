package com.catering.Saneth.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class MenuPackageRequest {

    @NotBlank(message = "Package name is required")
    private String name;

    private String description;

    @NotNull(message = "Package price is required")
    @Positive(message = "Package price must be greater than zero")
    private Double packagePrice;

    @NotNull(message = "Good for pax is required")
    @Positive(message = "Good for pax must be greater than zero")
    private Integer goodForPax;

    @NotBlank(message = "Package image is required")
    private String imageUrl;

    private Boolean available;

    @NotEmpty(message = "Menu items are required")
    private List<Long> menuItemIds;
}
