package com.catering.Saneth.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryRequest {

    @jakarta.validation.constraints.NotBlank(message = "Category name is required")
    private String name;

}
