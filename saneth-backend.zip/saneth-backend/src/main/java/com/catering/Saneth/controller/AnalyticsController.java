package com.catering.Saneth.controller;

import com.catering.Saneth.dto.response.AnalyticsResponse;
import com.catering.Saneth.dto.response.MonthlySalesResponse;
import com.catering.Saneth.dto.response.MostBoughtPackageResponse;
import com.catering.Saneth.service.AnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/analytics")
@RequiredArgsConstructor
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    @GetMapping("/dashboard")
    public AnalyticsResponse getDashboardAnalytics() {
        return analyticsService.getDashboardAnalytics();
    }

    @GetMapping("/most-bought-packages")
    public List<MostBoughtPackageResponse> getMostBoughtPackages() {
        return analyticsService.getMostBoughtPackages();
    }

    @GetMapping("/monthly-sales")
    public List<MonthlySalesResponse> getMonthlySalesTrend() {
        return analyticsService.getMonthlySalesTrend();
    }
}