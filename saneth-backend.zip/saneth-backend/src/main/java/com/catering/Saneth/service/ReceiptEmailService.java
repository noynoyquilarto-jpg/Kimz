package com.catering.Saneth.service;
import com.catering.Saneth.model.*;
import com.catering.Saneth.repository.BookingPaymentRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** Existing entry points delegate to the shared transactional notification queue. */
@Service @RequiredArgsConstructor @Transactional
public class ReceiptEmailService {
    private final EmailService email;
    private final BookingPaymentRepo payments;
    private final NotificationQueue queue;
    public java.util.List<NotificationQueue.Status> status(Long bookingId) { return queue.bookingStatus(bookingId); }
    public void sendConfirmation(Booking booking) { email.sendBookingConfirmationEmail(booking); }
    public void sendPaymentReceipt(Booking booking, BookingPayment record) { email.sendPaymentReceipt(booking, record); }
    public void sendPaymentReceipt(Booking booking) {
        var verified = payments.findByBookingIdOrderByCreatedAtAsc(booking.getId()).stream()
                .filter(p -> "VERIFIED".equals(p.getVerificationStatus())).toList();
        if (!verified.isEmpty()) email.sendPaymentReceipt(booking, verified.get(verified.size() - 1));
    }
}
