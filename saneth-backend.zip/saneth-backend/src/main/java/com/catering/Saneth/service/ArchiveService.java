package com.catering.Saneth.service;

import com.catering.Saneth.dto.response.BookingResponse;
import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.repository.BookingRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@org.springframework.transaction.annotation.Transactional
@RequiredArgsConstructor
public class ArchiveService {

    private final BookingRepo bookingRepo;
    private final AdminBookingService adminBookingService;

    public BookingResponse archiveBooking(Long id, String reason) {
        Booking booking = bookingRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        if (booking.getBookingStatus() != BookingStatus.COMPLETED &&
                booking.getBookingStatus() != BookingStatus.CANCELLED) {
            throw new RuntimeException("Only completed or cancelled bookings can be archived");
        }

        booking.setBookingStatus(BookingStatus.ARCHIVED);
        booking.setArchiveReason(reason);

        Booking archivedBooking = bookingRepo.save(booking);

        return mapToResponse(archivedBooking);
    }

    public List<BookingResponse> getArchivedBookings() {
        return bookingRepo.findByBookingStatus(BookingStatus.ARCHIVED)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    private BookingResponse mapToResponse(Booking booking) {
        return adminBookingService.mapToResponse(booking);
    }
}
