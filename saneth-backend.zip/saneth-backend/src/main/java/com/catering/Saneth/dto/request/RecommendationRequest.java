package com.catering.Saneth.dto.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RecommendationRequest {

    @NotNull(message = "Number of pax is required")
    @Positive(message = "Number of pax must be greater than zero")
    private Integer numberOfPax;

    @NotNull(message = "Budget is required")
    @Positive(message = "Budget must be greater than zero")
    private Double budget;
}