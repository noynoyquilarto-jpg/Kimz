package com.catering.Saneth.controller;

import com.catering.Saneth.dto.response.AdminAuditLogResponse;
import com.catering.Saneth.service.AdminAuditLogService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/admin/audit-logs")
@RequiredArgsConstructor
public class AdminAuditLogController {

    private final AdminAuditLogService adminAuditLogService;

    @GetMapping
    public List<AdminAuditLogResponse> getRecentLogs() {
        return adminAuditLogService.getRecentLogs();
    }
}
