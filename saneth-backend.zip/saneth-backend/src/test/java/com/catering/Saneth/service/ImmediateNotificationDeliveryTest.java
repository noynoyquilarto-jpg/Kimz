package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.ConfirmBookingRequest;
import com.catering.Saneth.dto.request.PaymentRecordRequest;
import com.catering.Saneth.model.*;
import com.catering.Saneth.model.enums.*;
import com.catering.Saneth.repository.*;
import jakarta.mail.Session;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.MailAuthenticationException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import static org.assertj.core.api.Assertions.*;
import static org.awaitility.Awaitility.await;
import static org.mockito.Mockito.*;

@SpringBootTest(properties = {"saneth.mail.enabled=true", "saneth.mail.immediate=true",
        "spring.mail.username=rerazo@usa.edu.ph", "saneth.mail.from-name=Saneth Catering",
        "spring.datasource.url=jdbc:h2:mem:immediate-mail-tests;DB_CLOSE_DELAY=-1"})
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
class ImmediateNotificationDeliveryTest {
    @Autowired NotificationQueue queue;
    @Autowired EmailNotificationRepo notifications;
    @Autowired CustomerVerificationService verification;
    @Autowired CustomerRepo customers;
    @Autowired BookingRepo bookings;
    @Autowired AdminBookingService admin;
    @Autowired PaymentService payments;
    @Autowired PlatformTransactionManager manager;
    @MockitoBean JavaMailSender smtp;

    @BeforeEach void setup() {
        when(smtp.createMimeMessage()).thenAnswer(call -> new MimeMessage(Session.getInstance(new Properties())));
    }

    @Test void rollbackNeverStartsImmediateDelivery() {
        String key = "ROLLBACK-IMMEDIATE:" + UUID.randomUUID();
        new TransactionTemplate(manager).executeWithoutResult(tx -> {
            queue.enqueue(key, "CONFIRMATION", null, null, null, "customer@example.invalid", "Test", "Body", "<p>Body</p>");
            verifyNoInteractions(smtp);
            tx.setRollbackOnly();
        });
        assertThat(notifications.findByEventKey(key)).isEmpty();
        verifyNoInteractions(smtp);
    }

    @Test void registrationAutomaticallySendsOtpAfterCustomerIsCommitted() throws Exception {
        var customer = new Customer();
        customer.setFirstName("First"); customer.setLastName("Last");
        customer.setEmail(UUID.randomUUID() + "@example.invalid"); customer.setPassword("test-hash");
        doAnswer(call -> {
            assertThat(customers.findById(customer.getId())).isPresent();
            return null;
        }).when(smtp).send(any(MimeMessage.class));
        String id = verification.register(customer);
        accepted(id);
        var sent = org.mockito.ArgumentCaptor.forClass(MimeMessage.class);
        verify(smtp, times(1)).send(sent.capture());
        assertThat(sent.getValue().getSubject()).isEqualTo("Saneth Catering \u2013 Verify Your Email");
        String body = NotificationWorkflowTest.body(sent.getValue(), "text/plain");
        String code = java.util.regex.Pattern.compile("(?m)^[0-9]{6}$").matcher(body).results().findFirst().orElseThrow().group();
        assertThat(body).contains("Dear First,", "5 minutes", "rerazo@usa.edu.ph");
        assertThat(sent.getValue().getReplyTo()[0].toString()).isEqualTo("rerazo@usa.edu.ph");
        assertSender(sent.getValue());
        assertThat(sent.getValue().getAllRecipients()[0].toString()).isEqualTo(customer.getEmail());
        assertThat(verification.verify(customer.getEmail(), code)).isTrue();
        assertThat(verification.verify(customer.getEmail(), code)).isFalse();
    }

    @Test void adminConfirmationImmediatelySendsOneMessageWithCommittedAmounts() throws Exception {
        Booking booking = pending();
        doAnswer(call -> {
            var committed = bookings.findById(booking.getId()).orElseThrow();
            assertThat(committed.getBookingStatus()).isEqualTo(BookingStatus.CONFIRMED);
            assertThat(committed.getQuotedPrice()).isEqualByComparingTo("12345");
            return null;
        }).when(smtp).send(any(MimeMessage.class));
        admin.confirmBooking(booking.getId(), quote());
        String id = queue.bookingStatus(booking.getId()).getFirst().id();
        accepted(id);
        assertThatThrownBy(() -> admin.confirmBooking(booking.getId(), quote())).isInstanceOf(RuntimeException.class);
        queue.retry(id);
        assertThat(queue.bookingStatus(booking.getId())).hasSize(1);
        var sent = org.mockito.ArgumentCaptor.forClass(MimeMessage.class);
        verify(smtp, times(1)).send(sent.capture());
        assertSender(sent.getValue());
        assertThat(sent.getValue().getSubject()).isEqualTo("Saneth Catering - Booking Confirmation - " + booking.getBookingReference());
        assertThat(NotificationWorkflowTest.body(sent.getValue(), "text/plain"))
                .contains(booking.getBookingReference(), "Dear Test Customer,", "Required down payment: PHP 3703.50",
                        "Total price: PHP 12345.00", "Total payment received: PHP 0.00", "Remaining balance: PHP 12345.00", "CONFIRMED");
    }

    @Test void smtpFailureKeepsConfirmedBookingAndManualRetryUsesTheSameNotification() {
        doThrow(new MailAuthenticationException("never expose provider details")).when(smtp).send(any(MimeMessage.class));
        Booking booking = pending();
        admin.confirmBooking(booking.getId(), quote());
        String id = queue.bookingStatus(booking.getId()).getFirst().id();
        await().atMost(Duration.ofSeconds(10)).untilAsserted(() ->
                assertThat(notifications.findById(id).orElseThrow().getStatus()).isEqualTo("RETRY_PENDING"));
        assertThat(bookings.findById(booking.getId()).orElseThrow().getBookingStatus()).isEqualTo(BookingStatus.CONFIRMED);
        doNothing().when(smtp).send(any(MimeMessage.class));
        queue.retry(id);
        accepted(id);
        assertThat(queue.bookingStatus(booking.getId())).hasSize(1);
        assertThat(notifications.findById(id).orElseThrow().getAttempts()).isEqualTo(1);
        verify(smtp, times(2)).send(any(MimeMessage.class));
    }

    @Test void verifiedPaymentImmediatelySendsOneReceiptAfterCommit() throws Exception {
        Booking booking = pending();
        booking.setBookingStatus(BookingStatus.CONFIRMED);
        booking.setQuotedPrice(new BigDecimal("12345"));
        booking.setDownPayment(new BigDecimal("3703.50"));
        booking.setPaymentStatus(PaymentStatus.AWAITING_PAYMENT);
        bookings.saveAndFlush(booking);
        var request = new PaymentRecordRequest();
        request.setAmount(3703.50);
        request.setPaymentMethod(PaymentMethod.GCASH);
        request.setPaymentReferenceNumber("RECEIPT-" + UUID.randomUUID());
        request.setSubmissionKey(UUID.randomUUID().toString());
        var pending = payments.submitPayment(booking.getBookingReference(), booking.getEmail(), request);
        assertThat(queue.bookingStatus(booking.getId())).isEmpty();
        verifyNoInteractions(smtp);
        doAnswer(call -> {
            assertThat(payments.getPaymentByBookingId(booking.getId()).getTotalPaid()).isEqualTo(3703.50);
            return null;
        }).when(smtp).send(any(MimeMessage.class));
        payments.verifyPayment(booking.getId(), pending.getId());
        String id = queue.bookingStatus(booking.getId()).getFirst().id();
        accepted(id);
        payments.verifyPayment(booking.getId(), pending.getId());
        assertThat(queue.bookingStatus(booking.getId())).hasSize(1);
        var sent = org.mockito.ArgumentCaptor.forClass(MimeMessage.class);
        verify(smtp, times(1)).send(sent.capture());
        assertSender(sent.getValue());
        assertThat(sent.getValue().getAllRecipients()[0].toString()).isEqualTo(booking.getEmail());
        assertThat(sent.getValue().getSubject()).contains("Payment Receipt", booking.getBookingReference());
        assertThat(NotificationWorkflowTest.body(sent.getValue(), "text/plain"))
                .contains("3703.50", "8641.50", request.getPaymentReferenceNumber());
    }

    private void assertSender(MimeMessage message) throws Exception {
        var from = (jakarta.mail.internet.InternetAddress) message.getFrom()[0];
        assertThat(from.getAddress()).isEqualTo("rerazo@usa.edu.ph");
        assertThat(from.getPersonal()).isEqualTo("Saneth Catering");
        assertThat(message.getReplyTo()[0].toString()).isEqualTo("rerazo@usa.edu.ph");
    }

    private void accepted(String id) {
        await().atMost(Duration.ofSeconds(10)).untilAsserted(() ->
                assertThat(notifications.findById(id).orElseThrow().getStatus()).isEqualTo("SMTP_ACCEPTED"));
    }
    private ConfirmBookingRequest quote() {
        var request = new ConfirmBookingRequest();
        request.setQuotedPrice(new BigDecimal("12345")); request.setDownPayment(new BigDecimal("3703.50"));
        return request;
    }
    private Booking pending() {
        // Each fixture has a separate date, preserving the production capacity/conflict rules.
        long offset = bookings.count() + 1000;
        return bookings.saveAndFlush(Booking.builder().bookingReference("IMMEDIATE-" + UUID.randomUUID())
                .customerName("Test Customer").email("customer@example.invalid").phoneNumber("09123456789")
                .customerAddress("Iloilo").eventPlace("Function hall").eventType("Birthday")
                .eventDate(LocalDate.now().plusDays(offset)).eventTime(LocalTime.of(17, 0)).numberOfPax(50)
                .bookingType(BookingType.CUSTOM).bookingStatus(BookingStatus.PENDING)
                .paymentStatus(PaymentStatus.NOT_REQUIRED_YET).downPaymentAmount(0.0).build());
    }
}
