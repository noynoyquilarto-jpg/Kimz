package com.catering.Saneth.repository;

import com.catering.Saneth.model.MenuCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MenuCategoryRepo extends JpaRepository<MenuCategory, Long> {
}