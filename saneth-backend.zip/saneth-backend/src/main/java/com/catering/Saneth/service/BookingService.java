package com.catering.Saneth.service;


import com.catering.Saneth.dto.request.BookingRequest;
import com.catering.Saneth.dto.request.TrackBookingRequest;
import com.catering.Saneth.dto.response.BookingResponse;
import com.catering.Saneth.dto.response.MenuItemResponse;
import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.MenuPackage;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.model.enums.PaymentStatus;
import com.catering.Saneth.repository.BookingRepo;
import com.catering.Saneth.repository.MenuPackageRepo;
import com.catering.Saneth.model.BookingMenuItem;
import com.catering.Saneth.model.MenuItem;
import com.catering.Saneth.model.enums.BookingType;
import com.catering.Saneth.repository.BookingMenuItemRepo;
import com.catering.Saneth.repository.MenuRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@org.springframework.transaction.annotation.Transactional
@RequiredArgsConstructor
public class BookingService {


    public static final int DAILY_CAPACITY = 3;
    public static final List<BookingStatus> CAPACITY_STATUSES = List.of(BookingStatus.CONFIRMED, BookingStatus.COMPLETED);
    @org.springframework.transaction.annotation.Transactional(readOnly = true)
    public com.catering.Saneth.dto.response.DateAvailabilityResponse getDateAvailability(LocalDate date) {
        long booked = bookingRepo.countByEventDateAndBookingStatusIn(date, CAPACITY_STATUSES);
        return new com.catering.Saneth.dto.response.DateAvailabilityResponse(date, DAILY_CAPACITY, booked, Math.max(0, DAILY_CAPACITY - booked), booked < DAILY_CAPACITY);
    }

    private static final int MINIMUM_BOOKING_LEAD_DAYS = 3;
    private static final List<BookingStatus> ACTIVE_BOOKING_STATUSES = List.of(
            BookingStatus.PENDING,
            BookingStatus.CONFIRMED
    );

    private final BookingRepo bookingRepo;
    private final MenuPackageRepo menuPackageRepo;
    private final BookingMenuItemRepo bookingMenuItemRepo;
    private final MenuRepo menuRepo;
    private final BookingTrackingEmailService bookingTrackingEmailService;


    public BookingResponse createBooking(BookingRequest request){
        validateBookingRequestBasics(request);
        if (!getDateAvailability(request.getEventDate()).available()) {
            throw new RuntimeException("This date is fully booked. Please select another event date.");
        }
        request.setEmail(request.getEmail().trim());
        request.setPhoneNumber(request.getPhoneNumber().trim());

        MenuPackage menuPackage = null;

        if (request.getBookingType() == BookingType.PACKAGE) {

            menuPackage = menuPackageRepo.findById(request.getMenuPackageId())
                    .orElseThrow(() -> new RuntimeException("Menu package not found."));

            validateBookingRequest(request, menuPackage);

        } else {

            if (request.getMenuItemIds() == null || request.getMenuItemIds().isEmpty()) {
                throw new RuntimeException("Please select at least one menu item.");
            }

        }
        validateNoDuplicateActiveBooking(request);

        Booking booking = Booking.builder()
                .customerName(request.getCustomerName())
                .email(request.getEmail())
                .phoneNumber(request.getPhoneNumber())
                .customerAddress(request.getCustomerAddress())
                .eventPlace(request.getEventPlace())
                .eventDate(request.getEventDate())
                .eventTime(request.getEventTime())
                .eventType(request.getEventType())
                .numberOfPax(request.getNumberOfPax())

                .bookingType(request.getBookingType())
                .menuPackage(menuPackage)

                .projector(Boolean.TRUE.equals(request.getProjector()))
                .videoke(Boolean.TRUE.equals(request.getVideoke()))
                .lechon(Boolean.TRUE.equals(request.getLechon()))
                .cake(Boolean.TRUE.equals(request.getCake()))
                .specialRequest(request.getSpecialRequest())

                .paymentMethod(null)
                .downPaymentAmount(0.0)
                .paymentReferenceNumber(null)

                .quotedPrice(null)
                .downPayment(null)

                .bookingStatus(BookingStatus.PENDING)
                .paymentStatus(PaymentStatus.NOT_REQUIRED_YET)
                .build();

        Booking savedBooking = bookingRepo.save(booking);

        String reference = "saneth-" + savedBooking.getEventDate().getYear() + "-" + String.format("%04d", savedBooking.getId());
        savedBooking.setBookingReference(reference);

        Booking finalBooking = bookingRepo.save(savedBooking);
        // Keep the selected package membership with the booking when the package changes later.
        if (menuPackage != null) {
            for (MenuItem item : menuPackage.getItems()) {
                bookingMenuItemRepo.save(BookingMenuItem.builder()
                        .booking(finalBooking).menuItem(item).build());
            }
        }
        if (request.getBookingType() == BookingType.CUSTOM) {

            List<MenuItem> items = menuRepo.findAllById(request.getMenuItemIds());

            if (items.size() != request.getMenuItemIds().size()) {
                throw new RuntimeException("One or more menu items were not found.");
            }
            if (items.stream().anyMatch(item -> !Boolean.TRUE.equals(item.getAvailable()))) {
                throw new RuntimeException("One or more selected menu items are unavailable.");
            }

            for (MenuItem item : items) {

                bookingMenuItemRepo.save(
                        BookingMenuItem.builder()
                                .booking(finalBooking)
                                .menuItem(item)
                                .build()
                );

            }

        }

        BookingResponse response = mapToResponse(finalBooking);
        List<String> names = menuPackage != null
                ? menuPackage.getItems().stream().map(MenuItem::getName).toList()
                : response.getCustomMenuItems().stream().map(MenuItemResponse::getName).toList();
        bookingTrackingEmailService.sendAfterBookingSaved(finalBooking, names);
        return response;

    }

    public BookingResponse trackBooking(TrackBookingRequest request){
        Booking booking = bookingRepo
                .findByBookingReferenceAndEmail(request.getBookingReference(), request.getEmail())
                .orElseThrow(() -> new RuntimeException("Booking not exist!"));

        return mapToResponse(booking);
    }

    private BookingResponse mapToResponse(Booking booking) {

        List<MenuItemResponse> savedMenuItems = bookingMenuItemRepo.findByBooking(booking)
                .stream()
                .map(item -> MenuItemResponse.builder()
                        .id(item.getMenuItem().getId())
                        .name(item.getMenuItem().getName())
                        .categoryId(item.getMenuItem().getCategory().getId())

                        .categoryName(item.getMenuItem().getCategory().getName())

                        .subCategoryId(item.getMenuItem().getSubCategory() != null
                                ? item.getMenuItem().getSubCategory().getId()
                                : null)

                        .subCategoryName(item.getMenuItem().getSubCategory() != null
                                ? item.getMenuItem().getSubCategory().getName()
                                : null)
                        .description(item.getMenuItem().getDescription())
                        .imageUrl(item.getMenuItem().getImageUrl())
                        .available(item.getMenuItem().getAvailable())
                        .build())
                .toList();

        return BookingResponse.builder()
                .emailNotifications(bookingTrackingEmailService.status(booking.getId()))
                .id(booking.getId())
                .bookingReference(booking.getBookingReference())
                .customerName(booking.getCustomerName())
                .email(booking.getEmail())
                .phoneNumber(booking.getPhoneNumber())
                .customerAddress(booking.getCustomerAddress())
                .eventPlace(booking.getEventPlace())
                .eventDate(booking.getEventDate())
                .eventTime(booking.getEventTime())
                .eventType(booking.getEventType())
                .numberOfPax(booking.getNumberOfPax())

                .bookingType(booking.getBookingType())

                .menuPackageId(
                        booking.getMenuPackage() != null
                                ? booking.getMenuPackage().getId()
                                : null
                )

                .menuPackageName(
                        booking.getMenuPackage() != null
                                ? booking.getMenuPackage().getName()
                                : null
                )

                .packagePrice(
                        booking.getMenuPackage() != null
                                ? booking.getMenuPackage().getPackagePrice()
                                : null
                )

                .goodForPax(
                        booking.getMenuPackage() != null
                                ? booking.getMenuPackage().getGoodForPax()
                                : null
                )

                .packageMenuItems(
                        booking.getMenuPackage() != null
                                ? (!savedMenuItems.isEmpty() ? savedMenuItems : booking.getMenuPackage().getItems().stream()
                                        .map(this::mapMenuItem)
                                        .toList())
                                : List.of()
                )

                .customMenuItems(booking.getBookingType() == BookingType.CUSTOM ? savedMenuItems : List.of())

                .projector(booking.getProjector())
                .videoke(booking.getVideoke())
                .lechon(booking.getLechon())
                .cake(booking.getCake())
                .specialRequest(booking.getSpecialRequest())

                .quotedPrice(booking.getQuotedPrice())
                .requiredDownPayment(booking.getDownPayment())
                .balance(booking.getQuotedPrice() == null ? null : booking.getQuotedPrice()
                        .subtract(java.math.BigDecimal.valueOf(booking.getDownPaymentAmount() == null
                                ? 0 : booking.getDownPaymentAmount())).max(java.math.BigDecimal.ZERO))

                .paymentMethod(booking.getPaymentMethod())
                .downPaymentAmount(booking.getDownPaymentAmount())
                .paymentReferenceNumber(booking.getPaymentReferenceNumber())
                .paymentNote(booking.getPaymentNote())
                .bookingStatus(booking.getBookingStatus())
                .paymentStatus(booking.getPaymentStatus())
                .build();
    }

    private MenuItemResponse mapMenuItem(MenuItem item) {
        return MenuItemResponse.builder()
                .id(item.getId())
                .name(item.getName())
                .description(item.getDescription())
                .imageUrl(item.getImageUrl())
                .available(item.getAvailable())
                .categoryId(item.getCategory().getId())
                .categoryName(item.getCategory().getName())
                .subCategoryId(item.getSubCategory() != null ? item.getSubCategory().getId() : null)
                .subCategoryName(item.getSubCategory() != null ? item.getSubCategory().getName() : null)
                .build();
    }

    private void validateBookingRequestBasics(BookingRequest request) {
        if (request.getEventDate() == null) {
            throw new RuntimeException("Event date is required.");
        }

        if (request.getEventDate().isBefore(getEarliestAllowedEventDate())) {
            throw new RuntimeException(getLeadTimeValidationMessage());
        }

        if (request.getBookingType() == null) {
            throw new RuntimeException("Booking type is required.");
        }
        if (request.getNumberOfPax() == null || request.getNumberOfPax() < 1 || request.getNumberOfPax() > 500) {
            throw new RuntimeException("Number of pax must be between 1 and 500.");
        }

        if (request.getBookingType() == BookingType.PACKAGE &&
                request.getMenuPackageId() == null) {
            throw new RuntimeException("Menu package is required.");
        }

        if (request.getBookingType() == BookingType.CUSTOM &&
                (request.getMenuItemIds() == null || request.getMenuItemIds().isEmpty())) {
            throw new RuntimeException("Please select at least one menu item.");
        }
    }

    private void validateBookingRequest(BookingRequest request, MenuPackage menuPackage) {
        if (request.getEventDate() == null) {
            throw new RuntimeException("Event date is required.");
        }

        if (request.getEventDate().isBefore(getEarliestAllowedEventDate())) {
            throw new RuntimeException(getLeadTimeValidationMessage());
        }

        if (request.getEventTime() == null) {
            throw new RuntimeException("Event time is required.");
        }

        if (request.getNumberOfPax() == null || request.getNumberOfPax() <= 0) {
            throw new RuntimeException("Number of pax must be greater than 0.");
        }

        if (menuPackage.getGoodForPax() != null &&
                request.getNumberOfPax() < menuPackage.getGoodForPax()) {
            throw new RuntimeException(
                    "This package requires at least " + menuPackage.getGoodForPax() + " pax."
            );
        }

        if (!Boolean.TRUE.equals(menuPackage.getAvailable())) {
            throw new RuntimeException("Selected menu package is not available.");
        }

        int maximumPax = 500;

        if (request.getNumberOfPax() > maximumPax) {
            throw new RuntimeException("Number of pax cannot exceed " + maximumPax + ".");
        }
    }

    private void validateNoDuplicateActiveBooking(BookingRequest request) {
        boolean hasDuplicate = bookingRepo.existsByEventDateAndBookingStatusInAndEmailIgnoreCaseOrEventDateAndBookingStatusInAndPhoneNumber(
                request.getEventDate(),
                ACTIVE_BOOKING_STATUSES,
                request.getEmail(),
                request.getEventDate(),
                ACTIVE_BOOKING_STATUSES,
                request.getPhoneNumber()
        );

        if (hasDuplicate) {
            throw new RuntimeException("You already have an active booking request for this event date. Please track your existing booking instead.");
        }
    }

    private LocalDate getEarliestAllowedEventDate() {
        return LocalDate.now().plusDays(MINIMUM_BOOKING_LEAD_DAYS);
    }

    private String getLeadTimeValidationMessage() {
        return "Bookings must be made at least " + MINIMUM_BOOKING_LEAD_DAYS + " days before the event date.";
    }

}
