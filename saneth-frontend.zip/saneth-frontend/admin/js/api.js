import { API_ORIGIN } from '../../js/config.js';
export const API_BASE_URL = `${API_ORIGIN}/api`;

export async function getCategories() {
    return apiRequest('/api/admin/categories');
}

export async function getSubCategories() {
    return apiRequest('/api/admin/menu-subcategories');
}

export function getToken() {
  const token = localStorage.getItem('saneth_admin_token')?.trim();
  return token && token !== 'undefined' && token !== 'null' ? token : null;
}

export function setToken(token) {
  if (typeof token !== 'string' || !token.trim() || ['undefined', 'null'].includes(token.trim())) {
    clearToken();
    throw new Error('Login did not return a valid session. Please try again.');
  }
  localStorage.setItem('saneth_admin_token', token.trim());
}

export function clearToken() {
  localStorage.removeItem('saneth_admin_token');
  localStorage.removeItem('saneth_admin_role');
}

export function requireAuth() {
  const token = getToken();

  if (!token) {
    window.location.href = 'index.html';
    return;
  }
}

export async function apiRequest(path, options = {}) {
  const { redirectOnAuthFailure = true, ...requestOptions } = options;
  const isLogin = path === '/api/admin/auth/login';
  const isFormData = options.body instanceof FormData;
  const headers = {
    ...(isFormData ? {} : { 'Content-Type': 'application/json' }),
    ...(options.headers || {})
  };

  const token = getToken();
  if (token && !isLogin) headers.Authorization = `Bearer ${token}`;

  // Existing callers include /api; the base URL now includes it too.
  const endpoint = path.replace(/^\/api(?=\/|$)/, '');
  const response = await fetch(`${API_BASE_URL}${endpoint.startsWith('/') ? endpoint : '/' + endpoint}`, {
    ...requestOptions,
    headers
  });

  const text = await response.text();
  let data = null;

  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }

  const errorMessage = extractError(data);
  // Some backend error handlers return authentication failures with a non-401 status.
  const authenticationFailed = !response.ok &&
    /^authentication failed[.!]?$/i.test(errorMessage.trim());
  if (!isLogin && (response.status === 401 || authenticationFailed)) {
    clearToken();
    if (redirectOnAuthFailure) window.location.href = 'index.html';
    throw new Error('Your session is no longer valid. Please log in again and retry your action.');
  }

  if (isLogin && response.status === 401) {
    throw new Error('Invalid email or password. Please try again.');
  }

  if (response.status === 403) {
    throw new Error('You are logged in, but you are not allowed to access this page.');
  }

  if (!response.ok) {
    throw new Error(errorMessage || 'Request failed.');
  }

  return data;
}

export async function uploadImage(file) {
  const formData = new FormData();
  formData.append('file', file);

  return apiRequest('/api/admin/uploads/images', {
    method: 'POST',
    body: formData
  });
}

function extractError(data) {
  if (!data) return '';
  if (typeof data === 'string') return data;
  if (data.message) return data.message;
  if (data.error && typeof data.error === 'string') return data.error;
  if (data.messages && typeof data.messages === 'object') {
    return Object.values(data.messages).join(', ');
  }
  return '';
}

export function peso(value) {
  const num = Number(value || 0);
  return `PHP ${num.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function badge(value) {
  if (!value) return '<span class="badge badge-muted">N/A</span>';

  const text = value
    .toString()
    .toLowerCase()
    .replaceAll('_', ' ')
    .replace(/\b\w/g, char => char.toUpperCase());

  let className = 'badge-muted';

  if (
    value === 'CONFIRMED' ||
    value === 'DOWN_PAYMENT_CONFIRMED' ||
    value === 'COMPLETED' ||
    value === 'FULLY_PAID'
  ) {
    className = 'badge-success';
  }

  if (
    value === 'PENDING' ||
    value === 'AWAITING_PAYMENT' ||
    value === 'NOT_REQUIRED_YET'
  ) {
    className = 'badge-warning';
  }

  if (
    value === 'CANCELLED' ||
    value === 'REJECTED'
  ) {
    className = 'badge-danger';
  }

  return `<span class="badge ${className}">${safe(text)}</span>`;
}

export function safe(value) {
  return String(value ?? '').replace(/[&<>'"]/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
  }[char]));
}

export function assetUrl(url) {
  if (!url) return '';
  const path = String(url).trim().replace(/\\/g, '/');
  if (path.startsWith('blob:')) return path;
  // Uploaded images belong to this backend, even when an old URL names localhost.
  const upload = path.match(/(?:^|\/)uploads\/(.+)$/i);
  if (upload) return new URL('/uploads/' + upload[1], API_BASE_URL).href;
  if (/^https?:\/\//i.test(path)) return path;
  return new URL(path.startsWith('/') ? path : '/' + path, API_BASE_URL).href;
}
