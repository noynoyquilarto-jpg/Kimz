package com.catering.Saneth.security;

import java.security.KeyStore;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSenderImpl;

/** Uses the Windows certificate authorities for SMTP on local Windows installs. */
@Configuration
@ConditionalOnProperty(name = "saneth.mail.windows-trust", havingValue = "true")
public class WindowsMailTlsConfig {
    @Bean
    static BeanPostProcessor windowsMailTrust() {
        return new BeanPostProcessor() {
            @Override
            public Object postProcessAfterInitialization(Object bean, String beanName) {
                if (bean instanceof JavaMailSenderImpl sender) {
                    try {
                        KeyStore roots = KeyStore.getInstance("Windows-ROOT");
                        roots.load(null, null);
                        TrustManagerFactory trust = TrustManagerFactory.getInstance(
                                TrustManagerFactory.getDefaultAlgorithm());
                        trust.init(roots);
                        SSLContext tls = SSLContext.getInstance("TLS");
                        tls.init(null, trust.getTrustManagers(), null);
                        var properties = sender.getJavaMailProperties();
                        properties.put("mail.smtp.ssl.socketFactory", tls.getSocketFactory());
                        properties.setProperty("mail.smtp.ssl.checkserveridentity", "true");
                        properties.setProperty("mail.smtp.starttls.enable", "true");
                        properties.setProperty("mail.smtp.starttls.required", "true");
                    } catch (Exception error) {
                        throw new IllegalStateException("Cannot load Windows SMTP trusted certificates", error);
                    }
                }
                return bean;
            }
        };
    }
}
