package com.catering.Saneth.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailAuthenticationException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Map;

/** Admin-only SMTP readiness check. Does not send a message. */
@RestController
@RequestMapping("/api/admin/mail")
public class AdminMailController {
    private final JavaMailSender sender;
    private final boolean enabled;

    public AdminMailController(JavaMailSender sender, @Value("${saneth.mail.enabled:true}") boolean enabled) {
        this.sender = sender;
        this.enabled = enabled;
    }

    @PostMapping("/check")
    public Map<String, String> check() {
        if (!enabled) return Map.of("status", "DISABLED", "message", "Email delivery is disabled on this server.");
        if (!(sender instanceof JavaMailSenderImpl mail)) {
            return Map.of("status", "UNAVAILABLE", "message", "Email connection could not be checked.");
        }
        if (mail.getUsername() == null || mail.getUsername().isBlank()
                || mail.getPassword() == null || mail.getPassword().isBlank()) {
            return Map.of("status", "NOT_CONFIGURED", "message", "Configure the sender email and its Gmail App Password, then restart the backend.");
        }
        try {
            mail.testConnection();
            return Map.of("status", "READY", "message", "Email server login succeeded. Inbox delivery is not guaranteed.");
        } catch (MailAuthenticationException error) {
            return authenticationFailure();
        } catch (Exception error) {
            for (Throwable cause = error; cause != null; cause = cause.getCause()) {
                if (cause instanceof jakarta.mail.AuthenticationFailedException) return authenticationFailure();
            }
            return Map.of("status", "CONNECTION_FAILED", "message", "Cannot connect securely to the email server. Check the connection and server logs.");
        }
    }

    private Map<String, String> authenticationFailure() {
        return Map.of("status", "AUTHENTICATION_FAILED", "message", "Gmail rejected the sender login. Configure a valid App Password for the sender account, then restart the backend.");
    }
}
