# Saneth Catering backend

Java 21, Spring Boot 4.0.6, Spring Security, JPA, MySQL, Flyway, and Gmail SMTP. The original `com.catering.Saneth` package layout, entities, relationships, booking/payment rules, receipt templates, OTP verification, JWT roles, notification queue, analytics, archives, and audit logs are retained.

This backend builds independently. Customer/admin static pages now live in the separate `saneth-frontend` project on Vercel; they are no longer copied from sibling folders into the JAR.

## Build and automated tests

Install JDK 21. The Maven wrapper downloads Maven/dependencies when first used.

```powershell
.\mvnw.cmd -B -ntp clean verify
```

On macOS/Linux:

```sh
sh mvnw -B -ntp clean verify
```

Output: `target/Saneth-0.0.1-SNAPSHOT.jar`. Automated tests use an isolated H2 database and mocked SMTP; they do not connect to your MySQL records or send real email. Re-run the full build before each deployment.

## Isolated local demonstration

This mode uses an empty in-memory database and explicitly disables email. It does not read or modify your existing MySQL data. Choose an unused port.

```powershell
java -jar target/Saneth-0.0.1-SNAPSHOT.jar --spring.profiles.active=demo --server.port=18080 '--spring.datasource.url=jdbc:h2:mem:saneth-demo;DB_CLOSE_DELAY=-1' --saneth.mail.enabled=false
```

Set frontend `SANETH_API_BASE_URL=http://localhost:18080`, then run the frontend development server. Demo admin: `demo@saneth.local` / `DemoPassword123!`. These deliberately public demo credentials must never be used in production. The catalog starts empty; use Admin Menu Items and Menu Packages to enter test data. Demo data disappears when the Java process stops. OTP sign-in requires configured email for a manual test; automated tests capture the generated messages without sending them.

## Production configuration

Use `.env.example` as the list of variables to enter in your hosting service's Environment/Secrets panel. Spring Boot does **not** automatically load `.env`. Locally, export variables in the launching terminal or supply an ignored local properties file. `SANETH_LOCAL_CONFIG` can select that file explicitly; its default is `.saneth-local.properties` in the current working directory. No machine-specific absolute path or private configuration file is distributed.

| Variable | Purpose |
| --- | --- |
| `SPRING_PROFILES_ACTIVE=prod` | Require production domain/database/mail settings |
| `PORT` | Hosting service port; defaults to 8080 |
| `SANETH_DB_URL` | MySQL JDBC URL; use the provider's TLS configuration |
| `SANETH_DB_USERNAME`, `SANETH_DB_PASSWORD` | Database credentials |
| `SANETH_JWT_SECRET` | Stable, unique random secret of at least 32 characters |
| `SANETH_MAIL_QUEUE_SECRET` | Optional separate stable secret for queued emails; defaults to the JWT secret |
| `SANETH_ADMIN_EMAIL`, `SANETH_ADMIN_PASSWORD` | Seed a missing admin; existing accounts are not reset |
| `SANETH_ALLOWED_ORIGINS` | Exact frontend origins, comma-separated; no trailing slash or wildcard |
| `SANETH_TRACKING_URL` | Public HTTPS customer tracking page |
| `SANETH_MAIL_USERNAME`, `SANETH_MAIL_APP_PASSWORD` | Gmail SMTP account and its App Password |
| `SANETH_MAIL_ENABLED=true` | Enable actual delivery |
| `SANETH_MAIL_HOST`, `SANETH_MAIL_PORT` | Default `smtp.gmail.com`, 587, with required STARTTLS |
| `SANETH_MAIL_REPLY_TO` | Optional reply-to; defaults to the configured SMTP account |
| `SANETH_MAIL_TEST_CONNECTION` | Optional startup SMTP login check; default false |
| `SANETH_UPLOAD_DIR` | Writable persistent directory for menu/package images |
| `SANETH_GCASH_NAME`, `SANETH_GCASH_NUMBER`, `SANETH_MESSENGER_URL` | Existing business payment/contact settings |

The seeded admin password must contain letters and numbers and be at least 12 characters. Generate your own secrets; do not copy test/demo values. Keep the queue secret stable while notifications are waiting, and preserve the existing secret during cutover if you need to deliver already encrypted queued messages.

The production default is `SANETH_JPA_DDL_AUTO=validate` and `SANETH_FLYWAY_ENABLED=false`, with automatic baselining disabled and Flyway clean disabled. Startup checks schema compatibility instead of silently changing existing business tables. If validation fails, stop and review a restored database copy. Do not switch to `create`, `create-drop`, or unrestricted `update` on your existing database to silence an error. [Spring Boot documents the schema-generation modes and initialization mechanisms](https://docs.spring.io/spring-boot/how-to/data-initialization.html).

## Preserve and migrate the existing database

1. Export a private full backup of MySQL, including relationships, routines/triggers if used, and `flyway_schema_history` if present. Keep it outside Git and these archives.
2. Restore it into a separate staging MySQL database. Preserve the original database untouched until staging checks succeed.
3. Compare staging schema/history with the included original `db/migration/V1...V10` files. Their contents and checksums have been kept unchanged. Tests use H2 and do not certify these MySQL migrations.
4. Legacy V5 deletes packages named `Package A`, `Package B`, and `Package C` and detaches their booking/feedback references. `LegacyMigrationGuard` stops V5 if matching records exist. It does not delete, rename, or repair records. An existing database needing this migration requires a deliberate, data-preserving schema/history plan on the copy.
5. For an **empty, disposable** database only, enabling `SANETH_FLYWAY_ENABLED=true` lets the original migrations initialize it. Check the result before using real data. Existing databases with no matching Flyway history require a manual baseline review; automatic baselining is intentionally disabled.
6. With schema compatibility established, use `validate`, keep migrations disabled unless explicitly reviewed, and run the full workflow against staging. Changes are never applied to your existing MySQL database by the release preparation itself.
7. Copy your original backend's `uploads/images/` files into `SANETH_UPLOAD_DIR/images/` without changing filenames. They are excluded from source archives so deployment needs this separate private transfer.

## Gmail and notification workflow

Enable 2-Step Verification for the sending Gmail account and create an App Password where the account permits it. Store it as `SANETH_MAIL_APP_PASSWORD`; never use or commit the normal Google password. Work/school account restrictions may prevent App Passwords. See [Google's App Password instructions](https://support.google.com/mail/answer/185833?hl=en).

The visible sender remains **Saneth Catering** and the actual From address uses the authenticated SMTP account. Reply-to defaults to that account or your configured `SANETH_MAIL_REPLY_TO`.

Registration creates an unverified customer and queues a six-digit OTP with a five-minute lifetime. Successful verification permits a later sign-in; it does not silently sign in. Admin booking confirmation queues the confirmation and payment instructions. Admin verification of a saved payment queues a receipt with the verified amount, cumulative payment, and remaining balance.

The transactional queue retains deduplication, encryption, retry, and delivery-status handling. SMTP failures do not remove saved bookings or payments. `SMTP_ACCEPTED` means the mail server accepted the message; inbox delivery still needs checking. Five-minute OTP expiry also applies while SMTP is unavailable.

After deployment, sign in as admin and use `POST /api/admin/mail/check` with the Bearer token to check SMTP login without sending a message. Expect `READY`; inspect `NOT_CONFIGURED`, `AUTHENTICATION_FAILED`, or `CONNECTION_FAILED` before testing actual customer emails.

## Deploy

Use a Java 21 host with MySQL connectivity, outbound SMTP port 587, HTTPS, and persistent uploads. A `Dockerfile` is included for Docker-compatible hosts. It builds and tests the JAR, then runs it as a non-root user. Configure the volume so that user can write to `/var/saneth/uploads`; copy existing images there. Docker itself was not available for local verification.

```powershell
docker build -t saneth-backend .
docker run --env-file .env -p 8080:8080 -v saneth-uploads:/var/saneth/uploads saneth-backend
```

Here `.env` is a private, untracked file populated with actual values. `docker run --env-file` loads it; the Java command alone does not.

Without Docker, set the same environment variables, build, and start:

```powershell
java -jar target/Saneth-0.0.1-SNAPSHOT.jar --spring.profiles.active=prod
```

The public `/api/menu-packages` endpoint can be used as a database-backed hosting health check. Keep the original verified databases and uploads backed up before cutover. See the release `DEPLOYMENT.md` for exact GitHub, Vercel, and Render steps.
