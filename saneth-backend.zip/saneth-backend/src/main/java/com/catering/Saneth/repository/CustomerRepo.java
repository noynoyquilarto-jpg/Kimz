package com.catering.Saneth.repository;
import com.catering.Saneth.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
public interface CustomerRepo extends JpaRepository<Customer,Long> {
 @org.springframework.data.jpa.repository.Lock(jakarta.persistence.LockModeType.PESSIMISTIC_WRITE)
 @org.springframework.data.jpa.repository.Query("select c from Customer c where lower(c.email) = lower(:email)")
 Optional<Customer> lockByEmail(@org.springframework.data.repository.query.Param("email") String email);
 Optional<Customer> findByEmailIgnoreCase(String email);
 boolean existsByEmailIgnoreCase(String email);
}
