package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.PaymentConfirmRequest;
import com.catering.Saneth.dto.request.PaymentRecordRequest;
import com.catering.Saneth.dto.response.PaymentResponse;
import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.BookingPayment;
import com.catering.Saneth.model.MenuPackage;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.model.enums.PaymentMethod;
import com.catering.Saneth.model.enums.PaymentStatus;
import com.catering.Saneth.repository.BookingPaymentRepo;
import com.catering.Saneth.repository.BookingRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PaymentServiceTest {

    @Mock
    private BookingRepo bookingRepo;

    @Mock
    private BookingPaymentRepo bookingPaymentRepo;

    @Mock
    private ReceiptEmailService receiptEmailService;

    @InjectMocks
    private PaymentService paymentService;

    private Booking booking;
    private MenuPackage menuPackage;

    @BeforeEach
    void setUp() {
        ReflectionTestUtils.setField(paymentService, "downPaymentRate", 0.30);

        menuPackage = MenuPackage.builder()
                .id(1L)
                .name("Package A")
                .packagePrice(15000.0)
                .goodForPax(50)
                .available(true)
                .build();

        booking = Booking.builder()
                .id(1L)
                .bookingReference("CAT-2026-0001")
                .customerName("Juan Dela Cruz")
                .email("juan@gmail.com")
                .phoneNumber("09123456789")
                .menuPackage(menuPackage)
                .bookingStatus(BookingStatus.CONFIRMED)
                .paymentMethod(PaymentMethod.GCASH)
                .downPaymentAmount(5000.0)
                .paymentReferenceNumber("GCASH123456")
                .paymentStatus(PaymentStatus.AWAITING_PAYMENT)
                .build();
    }

    @Test
    void getAllPayments_shouldReturnPaymentList() {
        when(bookingRepo.findByBookingStatusNotOrderByCreatedAtDesc(BookingStatus.ARCHIVED)).thenReturn(List.of(booking));
        when(bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(1L)).thenReturn(List.of());

        List<PaymentResponse> response = paymentService.getAllPayments();

        assertThat(response).hasSize(1);
        assertThat(response.get(0).getBookingReference()).isEqualTo("CAT-2026-0001");
        assertThat(response.get(0).getPaymentStatus()).isEqualTo(PaymentStatus.DOWN_PAYMENT_CONFIRMED);

        verify(bookingRepo, times(1)).findByBookingStatusNotOrderByCreatedAtDesc(BookingStatus.ARCHIVED);
    }

    @Test
    void getPaymentByBookingId_shouldReturnPayment_whenBookingExists() {
        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(1L)).thenReturn(List.of(payment(5000.0)));

        PaymentResponse response = paymentService.getPaymentByBookingId(1L);

        assertThat(response).isNotNull();
        assertThat(response.getBookingId()).isEqualTo(1L);
        assertThat(response.getPaymentMethod()).isEqualTo(PaymentMethod.GCASH);

        verify(bookingRepo, times(1)).findForUpdateById(1L);
    }

    @Test
    void getPaymentByBookingId_shouldThrowException_whenBookingNotFound() {
        when(bookingRepo.findForUpdateById(99L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            paymentService.getPaymentByBookingId(99L);
        });

        assertThat(exception.getMessage()).isEqualTo("Booking not found!");

        verify(bookingRepo, times(1)).findForUpdateById(99L);
    }

    @Test
    void confirmPayment_shouldSetPaymentStatusToConfirmed() {
        booking.setDownPaymentAmount(0.0);
        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(1L))
                .thenReturn(List.of())
                .thenReturn(List.of(payment(5000.0)))
                .thenReturn(List.of(payment(5000.0)));
        when(bookingPaymentRepo.save(any(BookingPayment.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(bookingRepo.save(any(Booking.class))).thenAnswer(invocation -> invocation.getArgument(0));

        PaymentConfirmRequest request = new PaymentConfirmRequest();
        request.setPaymentMethod(PaymentMethod.GCASH);
        request.setDownPaymentAmount(5000.0);
        request.setPaymentReferenceNumber("GCASH123456");

        PaymentResponse response = paymentService.confirmPayment(1L, request);

        assertThat(response.getPaymentStatus()).isEqualTo(PaymentStatus.DOWN_PAYMENT_CONFIRMED);
        assertThat(response.getTotalPaid()).isEqualTo(5000.0);

        verify(bookingRepo, times(1)).findForUpdateById(1L);
        verify(bookingRepo, times(1)).save(any(Booking.class));
    }

    @Test
    void rejectPayment_shouldSetPaymentStatusToRejected() {
        Booking rejectedBooking = Booking.builder()
                .id(1L)
                .bookingReference("CAT-2026-0001")
                .customerName("Juan Dela Cruz")
                .email("juan@gmail.com")
                .phoneNumber("09123456789")
                .menuPackage(menuPackage)
                .bookingStatus(BookingStatus.CONFIRMED)
                .paymentMethod(PaymentMethod.GCASH)
                .downPaymentAmount(5000.0)
                .paymentReferenceNumber("GCASH123456")
                .paymentStatus(PaymentStatus.REJECTED)
                .paymentRejectionReason("Invalid reference number")
                .build();

        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingRepo.save(any(Booking.class))).thenReturn(rejectedBooking);
        when(bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(1L)).thenReturn(List.of(payment(5000.0)));

        PaymentResponse response = paymentService.rejectPayment(1L, "Invalid reference number");

        assertThat(response.getPaymentStatus()).isEqualTo(PaymentStatus.REJECTED);
        assertThat(response.getRejectionReason()).isEqualTo("Invalid reference number");

        verify(bookingRepo, times(1)).findForUpdateById(1L);
        verify(bookingRepo, times(1)).save(any(Booking.class));
    }

    @Test
    void addPayment_shouldSetPaymentStatusToFullyPaid_whenTotalPaidCoversPackagePrice() {
        booking.setPaymentStatus(PaymentStatus.DOWN_PAYMENT_CONFIRMED);

        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(1L))
                .thenReturn(List.of(payment(5000.0)))
                .thenReturn(List.of(payment(5000.0), payment(10000.0)))
                .thenReturn(List.of(payment(5000.0), payment(10000.0)));
        when(bookingPaymentRepo.save(any(BookingPayment.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(bookingRepo.save(any(Booking.class))).thenAnswer(invocation -> invocation.getArgument(0));

        PaymentRecordRequest request = new PaymentRecordRequest();
        request.setPaymentMethod(PaymentMethod.CASH);
        request.setAmount(10000.0);
        request.setNote("Final cash payment");

        PaymentResponse response = paymentService.addPayment(1L, request);

        assertThat(response.getPaymentStatus()).isEqualTo(PaymentStatus.FULLY_PAID);
        assertThat(response.getRemainingBalance()).isZero();

        verify(bookingRepo, times(1)).findForUpdateById(1L);
        verify(bookingRepo, times(1)).save(any(Booking.class));
    }

    @Test
    void addPayment_preservesLegacyPaidAmount() {
        booking.setQuotedPrice(new java.math.BigDecimal("20000"));
        booking.setDownPaymentAmount(15000.0);
        booking.setPaymentStatus(PaymentStatus.DOWN_PAYMENT_CONFIRMED);
        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(1L))
                .thenReturn(List.of())
                .thenReturn(List.of(payment(15000.0), payment(5000.0)));
        when(bookingRepo.save(any(Booking.class))).thenAnswer(call -> call.getArgument(0));
        PaymentRecordRequest request = new PaymentRecordRequest();
        request.setPaymentMethod(PaymentMethod.CASH);
        request.setAmount(5000.0);

        PaymentResponse response = paymentService.addPayment(1L, request);

        assertThat(response.getTotalPaid()).isEqualTo(20000.0);
        assertThat(response.getRemainingBalance()).isZero();
        assertThat(response.getPaymentStatus()).isEqualTo(PaymentStatus.FULLY_PAID);
        verify(bookingPaymentRepo, times(2)).save(any(BookingPayment.class));
    }

    @Test
    void addPayment_rejectsOverpaymentWithLegacyPaidAmount() {
        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(1L)).thenReturn(List.of());
        PaymentRecordRequest request = new PaymentRecordRequest();
        request.setPaymentMethod(PaymentMethod.CASH);
        request.setAmount(10000.01);
        assertThat(assertThrows(RuntimeException.class, () -> paymentService.addPayment(1L, request)))
                .hasMessage("Payment amount cannot exceed the remaining balance.");
        verify(bookingPaymentRepo, never()).save(any(BookingPayment.class));
    }

    @Test
    void addPayment_requiresElectronicTransactionReference() {
        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(1L)).thenReturn(List.of());
        PaymentRecordRequest request = new PaymentRecordRequest();
        request.setPaymentMethod(PaymentMethod.GCASH);
        request.setAmount(5000.0);
        assertThat(assertThrows(RuntimeException.class, () -> paymentService.addPayment(1L, request)))
                .hasMessage("Transaction reference is required for GCash and bank transfer.");
        verify(bookingPaymentRepo, never()).save(any(BookingPayment.class));
    }

    @Test
    void addPayment_rejectsFractionalCent() {
        when(bookingRepo.findForUpdateById(1L)).thenReturn(Optional.of(booking));
        when(bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(1L)).thenReturn(List.of());
        PaymentRecordRequest request = new PaymentRecordRequest();
        request.setPaymentMethod(PaymentMethod.CASH);
        request.setAmount(5000.001);
        assertThat(assertThrows(RuntimeException.class, () -> paymentService.addPayment(1L, request)))
                .hasMessage("Payment amount must have at most two decimal places.");
        verify(bookingPaymentRepo, never()).save(any(BookingPayment.class));
    }

    private BookingPayment payment(Double amount) {
        return BookingPayment.builder()
                .id(1L)
                .booking(booking)
                .amount(amount)
                .paymentMethod(PaymentMethod.GCASH)
                .paymentReferenceNumber("GCASH123456")
                .note("Proof checked")
                .build();
    }
}
