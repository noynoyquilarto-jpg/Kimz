ALTER TABLE bookings
    MODIFY payment_status ENUM('NOT_REQUIRED_YET','AWAITING_PAYMENT','DOWN_PAYMENT_CONFIRMED','PARTIALLY_PAID','REJECTED','FULLY_PAID');

CREATE TABLE IF NOT EXISTS booking_payments (
    id BIGINT NOT NULL AUTO_INCREMENT,
    booking_id BIGINT NOT NULL,
    amount DOUBLE NOT NULL,
    payment_method ENUM('CASH','GCASH','BANK_TRANSFER') NOT NULL,
    payment_reference_number VARCHAR(255),
    note VARCHAR(255),
    created_at DATETIME(6),
    PRIMARY KEY (id),
    KEY idx_booking_payments_booking (booking_id),
    CONSTRAINT fk_booking_payments_booking FOREIGN KEY (booking_id) REFERENCES bookings (id)
);

INSERT INTO booking_payments (booking_id, amount, payment_method, payment_reference_number, note, created_at)
SELECT id,
       down_payment_amount,
       COALESCE(payment_method, 'GCASH'),
       payment_reference_number,
       payment_note,
       COALESCE(updated_at, created_at)
FROM bookings
WHERE down_payment_amount IS NOT NULL
  AND down_payment_amount > 0
  AND NOT EXISTS (
      SELECT 1
      FROM booking_payments bp
      WHERE bp.booking_id = bookings.id
  );
