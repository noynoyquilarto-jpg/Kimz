import { apiRequest, requireAuth, peso, safe } from './api.js';
import { initLayout } from './layout.js';
import { createPackageRankingLoader } from './most-bought-packages.js';

requireAuth();
initLayout();

const totalSales = document.getElementById('totalSales');
const totalBookings = document.getElementById('totalBookings');
const completedBookings = document.getElementById('completedBookings');
const pendingBookings = document.getElementById('pendingBookings');

const icon = paths => `<svg viewBox="0 0 28 28" aria-hidden="true" class="analytics-icon" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;
const coins = '<ellipse cx="9" cy="12" rx="6" ry="3"/><path d="M3 12v8c0 4 12 4 12 0v-8M3 16c0 4 12 4 12 0"/><ellipse cx="18" cy="5" rx="6" ry="3"/><path d="M24 5v12c0 2-3 3-6 3M24 10c0 2-3 3-6 3"/>';
const statIcons = [coins,
  '<rect x="3" y="5" width="21" height="19" rx="2"/><path d="M8 2v6m11-6v6M3 11h21m-15 6 3 3 6-6"/>',
  '<circle cx="14" cy="14" r="11"/><path d="m8 14 4 4 8-8"/>',
  '<path d="M12 23H4V5h20v7M8 2v6m11-6v6M4 10h20M8 14h2m4 0h2m-8 4h2"/><circle cx="21" cy="21" r="6"/><path d="M21 17v4l3 2"/>'
];
document.querySelectorAll('.compact-stats .stat-card').forEach((card, index) => card.insertAdjacentHTML('afterbegin', icon(statIcons[index])));
document.querySelector('.analytics-grid h2').insertAdjacentHTML('afterbegin', icon('<path d="M2 25V16h4v9zm7 0V10h4v15zm7 0V3h4v22zm7 0V7h3v18z"/>'));
document.querySelector('.analytics-grid .panel:last-child h2').insertAdjacentHTML('afterbegin', icon('<circle cx="14" cy="11" r="8"/><path d="m9 18-3 9 8-4 8 4-3-9m-5-12 1.5 3 3.5.5-2.5 2.5.5 3.5-3-1.5-3 1.5.5-3.5L9 9.5l3.5-.5z"/>'));
document.getElementById('refreshPackagesBtn').insertAdjacentHTML('afterbegin', icon('<path d="M24 10A10 10 0 0 0 7 5L3 9m0-7v7h7M4 18a10 10 0 0 0 17 5l4-4m0 7v-7h-7"/>'));

const salesChart = document.getElementById('salesChart');
const mostBoughtTable = document.getElementById('mostBoughtTable');
const loadMostBoughtPackages = createPackageRankingLoader(
  mostBoughtTable, document.getElementById('refreshPackagesBtn'), true
);

loadAnalytics();

async function loadAnalytics() {
  await Promise.all([
    loadSummary(),
    loadSalesChart(),
    loadMostBoughtPackages()
  ]);
}

async function loadSummary() {
  try {
  const data = await apiRequest('/api/admin/analytics/dashboard');

  totalSales.textContent = peso(data.totalSales || 0);
  totalBookings.textContent = data.totalBookings || 0;
  completedBookings.textContent = data.completedBookings || 0;
  pendingBookings.textContent = data.pendingBookings || 0;
  } catch (error) {
    [totalSales, totalBookings, completedBookings, pendingBookings].forEach(element => {
      element.textContent = 'Unavailable';
      element.title = error.message;
    });
  }
}

async function loadSalesChart() {
  salesChart.innerHTML = '<p class="muted">Loading chart...</p>';

  try {
    const data = await apiRequest('/api/admin/analytics/monthly-sales');

    if (!data || !data.length) {
      salesChart.innerHTML = '<p class="muted">No sales data yet.</p>';
      return;
    }

    data.sort((a, b) => Date.parse('1 ' + b.month) - Date.parse('1 ' + a.month));
    const values = data.map(item => Math.max(0, Number(item.totalCollected) || 0));
    const maxValue = Math.max(...values, 1);
    const magnitude = 10 ** Math.floor(Math.log10(maxValue / 6));
    const step = Math.ceil(maxValue / 6 / magnitude) * magnitude;
    const ceiling = Math.ceil(maxValue / step) * step;
    const ticks = Array.from({ length: Math.round(ceiling / step) + 1 }, (_, i) => ceiling - i * step);

    const bars = data.map((item, index) => {
      const value = values[index];
      const height = value / ceiling * 100;

      return `
        <div class="bar-item">
          <div class="bar-fill" style="height: ${height}%">
            <div class="bar-value">${peso(value)}</div>
          </div>
          <div class="bar-label">${safe(item.month)}</div>
        </div>
      `;
    }).join('');
    salesChart.innerHTML = `<div class="sales-axis-title">Sales (PHP)</div>
      <div class="sales-chart-scroll"><div class="sales-chart-canvas" style="min-width:${Math.max(360, data.length * 140)}px">
        <div class="sales-ticks">${ticks.map(value => `<span>${value.toLocaleString('en-PH')}</span>`).join('')}</div>
        <div class="sales-plot"><div class="sales-gridlines">${ticks.map(() => '<span></span>').join('')}</div>
          <div class="sales-bars">${bars}</div>
        </div>
      </div></div>`;

  } catch (error) {
    salesChart.innerHTML = `<p class="muted">${safe(error.message)}</p>`;
  }
}
