package com.catering.Saneth.service;


import com.catering.Saneth.dto.request.PaymentConfirmRequest;
import com.catering.Saneth.dto.request.PaymentRecordRequest;
import com.catering.Saneth.dto.response.PaymentRecordResponse;
import com.catering.Saneth.dto.response.PaymentResponse;
import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.BookingPayment;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.model.enums.PaymentStatus;
import com.catering.Saneth.repository.BookingPaymentRepo;
import com.catering.Saneth.repository.BookingRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@org.springframework.transaction.annotation.Transactional
@RequiredArgsConstructor
public class PaymentService {
    private final BookingRepo bookingRepo;
    private final BookingPaymentRepo bookingPaymentRepo;
    private final ReceiptEmailService receiptEmailService;

    @Value("${saneth.downpayment.rate:0.30}")
    private Double downPaymentRate;

    public List<PaymentResponse> getAllPayments(){
        return bookingRepo.findByBookingStatusNotOrderByCreatedAtDesc(BookingStatus.ARCHIVED)
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public PaymentResponse getPaymentByBookingId(Long bookingId){
        Booking booking = bookingRepo.findForUpdateById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found!"));

        return mapToResponse(booking);
    }

    public PaymentResponse confirmPayment(Long bookingId, PaymentConfirmRequest request) {
        PaymentRecordRequest paymentRequest = new PaymentRecordRequest();
        paymentRequest.setPaymentMethod(request.getPaymentMethod());
        paymentRequest.setAmount(request.getDownPaymentAmount());
        paymentRequest.setPaymentReferenceNumber(request.getPaymentReferenceNumber());
        paymentRequest.setNote(request.getPaymentNote());

        return addPayment(bookingId, paymentRequest);
    }

    public PaymentResponse addPayment(Long bookingId, PaymentRecordRequest request) {
        Booking booking = bookingRepo.findForUpdateById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        List<BookingPayment> currentPayments = bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(bookingId);

        BookingPayment duplicate = duplicate(currentPayments, request);
        if (duplicate != null) {
            ensureSamePayment(duplicate, request);
            return "PENDING_VERIFICATION".equals(duplicate.getVerificationStatus())
                    ? verifyPayment(bookingId, duplicate.getId()) : mapToResponse(booking);
        }

        validatePaymentRecord(booking, request, currentPayments);

        // Preserve payments recorded before the transaction history was introduced.
        if (currentPayments.stream().noneMatch(p -> "VERIFIED".equals(p.getVerificationStatus())) && booking.getDownPaymentAmount() != null
                && booking.getDownPaymentAmount() > 0) {
            bookingPaymentRepo.save(BookingPayment.builder()
                    .booking(booking)
                    .amount(booking.getDownPaymentAmount())
                    .paymentMethod(booking.getPaymentMethod())
                    .paymentReferenceNumber(booking.getPaymentReferenceNumber())
                    .note("Previously recorded payment")
                    .build());
        }

        BookingPayment payment = BookingPayment.builder()
                .booking(booking)
                .amount(request.getAmount())
                .paymentMethod(request.getPaymentMethod())
                .paymentReferenceNumber(trimToNull(request.getPaymentReferenceNumber()))
                .note(trimToNull(request.getNote()))
                .submissionKey(request.getSubmissionKey())
                .verifiedAt(java.time.LocalDateTime.now())
                .build();

        BookingPayment savedPayment = bookingPaymentRepo.save(payment);

        booking.setPaymentMethod(request.getPaymentMethod());
        booking.setPaymentReferenceNumber(trimToNull(request.getPaymentReferenceNumber()));
        booking.setPaymentNote(trimToNull(request.getNote()));
        List<BookingPayment> updatedPayments = bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(bookingId);
        booking.setDownPaymentAmount(getTotalPaid(updatedPayments));
        booking.setPaymentStatus(calculatePaymentStatus(booking, updatedPayments));
        booking.setPaymentRejectionReason(null);

        Booking savedBooking = bookingRepo.save(booking);
        receiptEmailService.sendPaymentReceipt(savedBooking, savedPayment);

        return mapToResponse(savedBooking);
    }

    public PaymentResponse rejectPayment(Long bookingId, String reason){
        Booking booking = bookingRepo.findForUpdateById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found!"));

        if (booking.getPaymentStatus() != PaymentStatus.AWAITING_PAYMENT &&
                booking.getPaymentStatus() != PaymentStatus.DOWN_PAYMENT_CONFIRMED &&
                booking.getPaymentStatus() != PaymentStatus.PARTIALLY_PAID) {
            throw new RuntimeException("Only unpaid or partially paid bookings can be rejected.");
        }

        if (reason == null || reason.isBlank()) {
            throw new RuntimeException("Rejection reason is required.");
        }

        booking.setPaymentStatus(PaymentStatus.REJECTED);
        booking.setPaymentRejectionReason(reason.trim());

        Booking updatedBooking = bookingRepo.save(booking);
        return mapToResponse(updatedBooking);
    }

    public PaymentResponse updatePaymentStatus(Long bookingId, PaymentStatus status, String reason){
        Booking booking = bookingRepo.findForUpdateById(bookingId)
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        validatePaymentStatusTransition(booking, status, reason);

        if (status == PaymentStatus.REJECTED && (reason == null || reason.isBlank())) {
            throw new RuntimeException("Rejection reason is required.");
        }

        booking.setPaymentStatus(status);

        if(status == PaymentStatus.REJECTED){
            booking.setPaymentRejectionReason(reason.trim());
        }else{
            booking.setPaymentRejectionReason(null);
        }

        Booking updatedBooking = bookingRepo.save(booking);

        return mapToResponse(updatedBooking);
    }

    private void validatePaymentRecord(Booking booking, PaymentRecordRequest request, List<BookingPayment> currentPayments) {
        if (request.getPaymentMethod() == null) {
            throw new RuntimeException("Select a payment method (Cash, GCash, or bank transfer) before saving the payment.");
        }
        if (booking.getBookingStatus() != BookingStatus.CONFIRMED) {
            throw new RuntimeException("Only confirmed bookings can receive payments.");
        }

        if (booking.getPaymentStatus() == PaymentStatus.FULLY_PAID) {
            throw new RuntimeException("This booking is already fully paid.");
        }

        if (request.getAmount() == null || !Double.isFinite(request.getAmount()) || request.getAmount() <= 0) {
            throw new RuntimeException("Payment amount must be greater than 0.");
        }

        if (java.math.BigDecimal.valueOf(request.getAmount()).stripTrailingZeros().scale() > 2) {
            throw new RuntimeException("Payment amount must have at most two decimal places.");
        }
        if (request.getPaymentMethod() != com.catering.Saneth.model.enums.PaymentMethod.CASH
                && trimToNull(request.getPaymentReferenceNumber()) == null) {
            throw new RuntimeException("Transaction reference is required for GCash and bank transfer.");
        }
        Double packagePrice = booking.getQuotedPrice() != null ? booking.getQuotedPrice().doubleValue() : (booking.getMenuPackage() != null ? booking.getMenuPackage().getPackagePrice() : null);
        double totalPaid = currentPayments.stream().noneMatch(p -> "VERIFIED".equals(p.getVerificationStatus()))
                ? (booking.getDownPaymentAmount() != null ? booking.getDownPaymentAmount() : 0.0)
                : getTotalPaid(currentPayments);
        double remainingBalance = packagePrice != null ? java.math.BigDecimal.valueOf(packagePrice)
                .subtract(java.math.BigDecimal.valueOf(totalPaid)).doubleValue() : 0.0;

        if (packagePrice != null && request.getAmount() > remainingBalance) {
            throw new RuntimeException("Payment amount cannot exceed the remaining balance.");
        }

        if (packagePrice == null || packagePrice <= 0) {
            throw new RuntimeException("Confirm the booking with an approved quote before recording payments.");
        }
        double requiredDownPayment = booking.getDownPayment() != null
                ? booking.getDownPayment().doubleValue() : packagePrice * downPaymentRate;
        if (totalPaid == 0 && request.getAmount() < requiredDownPayment) {
            throw new RuntimeException("First payment must cover the required down payment.");
        }
    }

    private void validatePaymentStatusTransition(Booking booking, PaymentStatus nextStatus, String reason) {
        PaymentStatus currentStatus = booking.getPaymentStatus();

        if (currentStatus == nextStatus) {
            return;
        }

        boolean allowed = switch (currentStatus) {
            case AWAITING_PAYMENT -> nextStatus == PaymentStatus.REJECTED;
            case DOWN_PAYMENT_CONFIRMED, PARTIALLY_PAID -> nextStatus == PaymentStatus.REJECTED;
            case REJECTED -> nextStatus == PaymentStatus.AWAITING_PAYMENT;
            case NOT_REQUIRED_YET, FULLY_PAID -> false;
        };

        if (!allowed) {
            throw new RuntimeException("Invalid payment status transition from " + currentStatus + " to " + nextStatus + ".");
        }

        if (nextStatus == PaymentStatus.REJECTED && (reason == null || reason.isBlank())) {
            throw new RuntimeException("Rejection reason is required.");
        }
    }

    private PaymentStatus calculatePaymentStatus(Booking booking, List<BookingPayment> payments) {
        Double packagePrice = booking.getQuotedPrice() != null ? booking.getQuotedPrice().doubleValue() : (booking.getMenuPackage() != null ? booking.getMenuPackage().getPackagePrice() : null);
        return calculatePaymentStatus(booking, getTotalPaid(payments), (int)payments.stream().filter(p -> "VERIFIED".equals(p.getVerificationStatus())).count());
    }

    private PaymentStatus calculatePaymentStatus(Booking booking, double totalPaid, int paymentCount) {
        Double packagePrice = booking.getQuotedPrice() != null ? booking.getQuotedPrice().doubleValue() : (booking.getMenuPackage() != null ? booking.getMenuPackage().getPackagePrice() : null);
        if (packagePrice != null && totalPaid >= packagePrice) {
            return PaymentStatus.FULLY_PAID;
        }

        if (paymentCount == 1) {
            return PaymentStatus.DOWN_PAYMENT_CONFIRMED;
        }

        return PaymentStatus.PARTIALLY_PAID;
    }

    private PaymentResponse mapToResponse(Booking booking){
        List<BookingPayment> payments = bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(booking.getId());
        Double packagePrice = booking.getQuotedPrice() != null ? booking.getQuotedPrice().doubleValue() : (booking.getMenuPackage() != null ? booking.getMenuPackage().getPackagePrice() : null);
        double recordedTotalPaid = getTotalPaid(payments);
        double legacyDownPayment = booking.getDownPaymentAmount() != null ? booking.getDownPaymentAmount() : 0.0;
        Double totalPaid = recordedTotalPaid > 0 ? recordedTotalPaid : legacyDownPayment;
        var verified = payments.stream().filter(p -> "VERIFIED".equals(p.getVerificationStatus())).toList();
        int paymentCount = verified.isEmpty() && legacyDownPayment > 0 ? 1 : verified.size();
        Double downPayment = verified.isEmpty() ? legacyDownPayment : verified.get(0).getAmount();
        Double remainingBalance = packagePrice != null ? Math.max(packagePrice - totalPaid, 0.0) : 0.0;
        PaymentStatus paymentStatus = booking.getPaymentStatus();

        if (booking.getBookingStatus() == BookingStatus.CONFIRMED &&
                paymentStatus != PaymentStatus.REJECTED &&
                totalPaid > 0) {
            PaymentStatus calculatedStatus = calculatePaymentStatus(booking, totalPaid, paymentCount);
            paymentStatus = calculatedStatus;
        }

        return PaymentResponse.builder()
                .emailNotifications(receiptEmailService.status(booking.getId()))
                .bookingId(booking.getId())
                .bookingReference(booking.getBookingReference())
                .customerName(booking.getCustomerName())
                .email(booking.getEmail())
                .phoneNumber(booking.getPhoneNumber())

                .packagePrice(packagePrice)
                .downPaymentAmount(downPayment)
                .totalPaid(totalPaid)
                .remainingBalance(remainingBalance)

                .paymentMethod(booking.getPaymentMethod())
                .paymentReferenceNumber(booking.getPaymentReferenceNumber())
                .paymentNote(booking.getPaymentNote())
                .paymentStatus(paymentStatus)
                .rejectionReason(booking.getPaymentRejectionReason())
                .payments(payments.stream().map(this::mapPaymentRecord).toList())
                .build();
    }

    private PaymentRecordResponse mapPaymentRecord(BookingPayment payment) {
        return PaymentRecordResponse.builder()
                .id(payment.getId())
                .amount(payment.getAmount())
                .paymentMethod(payment.getPaymentMethod())
                .paymentReferenceNumber(payment.getPaymentReferenceNumber())
                .note(payment.getNote())
                .createdAt(payment.getCreatedAt())
                .verificationStatus(payment.getVerificationStatus())
                .verifiedAt(payment.getVerifiedAt())
                .build();
    }

    private double getTotalPaid(List<BookingPayment> payments) {
        return payments.stream()
                .filter(p -> "VERIFIED".equals(p.getVerificationStatus()))
                .map(BookingPayment::getAmount)
                .filter(amount -> amount != null)
                .map(java.math.BigDecimal::valueOf)
                .reduce(java.math.BigDecimal.ZERO, java.math.BigDecimal::add).doubleValue();
    }

    private String trimToNull(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }

        return value.trim();
    }

    public PaymentRecordResponse submitPayment(String reference, String customerEmail, PaymentRecordRequest request) {
        Booking found = bookingRepo.findByBookingReferenceAndEmail(reference, customerEmail)
                .orElseThrow(() -> new RuntimeException("Booking not found for this customer."));
        Booking booking = bookingRepo.findForUpdateById(found.getId()).orElseThrow();
        var records = bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(booking.getId());
        BookingPayment duplicate = duplicate(records, request);
        if (duplicate != null) { ensureSamePayment(duplicate, request); return mapPaymentRecord(duplicate); }
        if (request.getSubmissionKey() == null) throw new RuntimeException("A submission key is required.");
        validatePaymentRecord(booking, request, records);
        if (records.stream().anyMatch(p -> "PENDING_VERIFICATION".equals(p.getVerificationStatus())))
            throw new RuntimeException("A payment is already awaiting admin verification. Please wait for review.");
        // No aggregate amounts, booking status or receipts change until an admin verifies this record.
        BookingPayment record = bookingPaymentRepo.save(BookingPayment.builder().booking(booking)
                .amount(request.getAmount()).paymentMethod(request.getPaymentMethod())
                .paymentReferenceNumber(trimToNull(request.getPaymentReferenceNumber())).note(trimToNull(request.getNote()))
                .submissionKey(request.getSubmissionKey()).verificationStatus("PENDING_VERIFICATION").build());
        return mapPaymentRecord(record);
    }

    public PaymentResponse verifyPayment(Long bookingId, Long paymentId) {
        Booking booking = bookingRepo.findForUpdateById(bookingId).orElseThrow(() -> new RuntimeException("Booking not found"));
        var records = bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(bookingId);
        BookingPayment payment = records.stream().filter(p -> p.getId().equals(paymentId)).findFirst()
                .orElseThrow(() -> new RuntimeException("Payment not found for this booking."));
        if ("VERIFIED".equals(payment.getVerificationStatus())) return mapToResponse(booking);
        if (!"PENDING_VERIFICATION".equals(payment.getVerificationStatus())) throw new RuntimeException("This payment cannot be verified.");
        PaymentRecordRequest check = new PaymentRecordRequest(); check.setAmount(payment.getAmount());
        check.setPaymentMethod(payment.getPaymentMethod()); check.setPaymentReferenceNumber(payment.getPaymentReferenceNumber());
        validatePaymentRecord(booking, check, records);
        if (records.stream().noneMatch(p -> "VERIFIED".equals(p.getVerificationStatus()))
                && booking.getDownPaymentAmount() != null && booking.getDownPaymentAmount() > 0) {
            bookingPaymentRepo.save(BookingPayment.builder().booking(booking).amount(booking.getDownPaymentAmount())
                    .paymentMethod(booking.getPaymentMethod()).note("Previously recorded payment").build());
        }
        payment.setVerificationStatus("VERIFIED"); payment.setVerifiedAt(java.time.LocalDateTime.now());
        bookingPaymentRepo.saveAndFlush(payment);
        var updated = bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(bookingId);
        booking.setDownPaymentAmount(getTotalPaid(updated)); booking.setPaymentStatus(calculatePaymentStatus(booking, updated));
        booking.setPaymentMethod(payment.getPaymentMethod()); booking.setPaymentReferenceNumber(payment.getPaymentReferenceNumber());
        booking.setPaymentNote(payment.getNote()); booking.setPaymentRejectionReason(null);
        bookingRepo.save(booking);
        receiptEmailService.sendPaymentReceipt(booking, payment);
        return mapToResponse(booking);
    }

    public PaymentResponse rejectSubmittedPayment(Long bookingId, Long paymentId, String reason) {
        Booking booking = bookingRepo.findForUpdateById(bookingId).orElseThrow(() -> new RuntimeException("Booking not found"));
        if (reason == null || reason.isBlank()) throw new RuntimeException("Rejection reason is required.");
        var record = bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(bookingId).stream().filter(p -> p.getId().equals(paymentId)).findFirst().orElseThrow();
        if (!"PENDING_VERIFICATION".equals(record.getVerificationStatus())) throw new RuntimeException("Only pending payments can be rejected.");
        record.setVerificationStatus("REJECTED"); record.setNote(reason.trim());
        return mapToResponse(booking);
    }

    private BookingPayment duplicate(List<BookingPayment> records, PaymentRecordRequest request) {
        String ref = trimToNull(request.getPaymentReferenceNumber());
        return records.stream().filter(p -> (request.getSubmissionKey() != null && request.getSubmissionKey().equals(p.getSubmissionKey()))
                || (ref != null && ref.equalsIgnoreCase(p.getPaymentReferenceNumber()))).findFirst().orElse(null);
    }
    private void ensureSamePayment(BookingPayment record, PaymentRecordRequest request) {
        if ("REJECTED".equals(record.getVerificationStatus())) throw new RuntimeException("This transaction was rejected. Submit a new transaction reference after resolving the payment.");
        if (!java.util.Objects.equals(record.getPaymentMethod(), request.getPaymentMethod())
                || !java.util.Objects.equals(record.getAmount(), request.getAmount())
                || !java.util.Objects.equals(trimToNull(record.getPaymentReferenceNumber()), trimToNull(request.getPaymentReferenceNumber())))
            throw new RuntimeException("That submission or transaction reference already belongs to a different payment.");
    }
}
