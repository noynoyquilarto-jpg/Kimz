package com.catering.Saneth.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class AdminLoginResponse {

    private String message;
    private String token;
    private String role;
}