package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.MenuItemRequest;
import com.catering.Saneth.dto.response.MenuItemResponse;
import com.catering.Saneth.model.MenuCategory;
import com.catering.Saneth.model.MenuItem;
import com.catering.Saneth.model.MenuSubCategory;
import com.catering.Saneth.repository.MenuCategoryRepo;
import com.catering.Saneth.repository.MenuRepo;
import com.catering.Saneth.repository.MenuSubCategoryRepo;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@org.springframework.transaction.annotation.Transactional
@RequiredArgsConstructor
public class MenuItemService {

    private final MenuRepo menuRepo;
    private final MenuSubCategoryRepo menuSubCategoryRepo;
    private final MenuCategoryRepo menuCategoryRepo;

    public MenuItemResponse createMenuItem(MenuItemRequest request) {
        validateImageUrl(request.getImageUrl());

        MenuCategory category = menuCategoryRepo.findById(request.getCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found."));

        MenuSubCategory subCategory = resolveSubCategory(request.getSubCategoryId(), category);

        MenuItem menuItem = MenuItem.builder()
                .name(request.getName())
                .category(category)
                .subCategory(subCategory)
                .description(request.getDescription())
                .imageUrl(request.getImageUrl().trim())
                .available(request.getAvailable() != null ? request.getAvailable() : true)
                .build();

        MenuItem savedMenu = menuRepo.save(menuItem);

        return mapToResponse(savedMenu);
    }

    public List<MenuItemResponse> getAllMenu() {
        return menuRepo.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public MenuItemResponse getMenuById(Long id) {
        MenuItem menuItem = menuRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Menu item not found."));

        return mapToResponse(menuItem);
    }

    public MenuItemResponse updateMenu(Long id, MenuItemRequest request) {

        MenuItem menuItem = menuRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Menu item not found."));

        validateImageUrl(request.getImageUrl());

        MenuCategory category = menuCategoryRepo.findById(request.getCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found."));

        MenuSubCategory subCategory = resolveSubCategory(request.getSubCategoryId(), category);

        menuItem.setName(request.getName());
        menuItem.setCategory(category);
        menuItem.setSubCategory(subCategory);
        menuItem.setDescription(request.getDescription());
        menuItem.setImageUrl(request.getImageUrl().trim());
        menuItem.setAvailable(
                request.getAvailable() != null
                        ? request.getAvailable()
                        : menuItem.getAvailable()
        );

        MenuItem updatedMenuItem = menuRepo.save(menuItem);

        return mapToResponse(updatedMenuItem);
    }

    public void deleteMenuItem(Long id) {

        MenuItem menuItem = menuRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Menu item not found."));

        menuRepo.delete(menuItem);
    }

    /**
     * Subcategory is optional. Categories like "Soup" don't need one, while
     * categories like "Main Course" typically do. If a subCategoryId is
     * provided, it must actually belong to the chosen category.
     */
    private MenuSubCategory resolveSubCategory(Long subCategoryId, MenuCategory category) {
        if (subCategoryId == null) {
            return null;
        }

        MenuSubCategory subCategory = menuSubCategoryRepo.findById(subCategoryId)
                .orElseThrow(() -> new RuntimeException("Subcategory not found."));

        if (!subCategory.getCategory().getId().equals(category.getId())) {
            throw new RuntimeException("Subcategory does not belong to the selected category.");
        }

        return subCategory;
    }

    private MenuItemResponse mapToResponse(MenuItem menuItem) {

        return MenuItemResponse.builder()
                .id(menuItem.getId())
                .name(menuItem.getName())
                .description(menuItem.getDescription())
                .imageUrl(menuItem.getImageUrl())
                .available(menuItem.getAvailable())

                .categoryId(menuItem.getCategory().getId())
                .categoryName(menuItem.getCategory().getName())

                .subCategoryId(
                        menuItem.getSubCategory() != null
                                ? menuItem.getSubCategory().getId()
                                : null
                )
                .subCategoryName(
                        menuItem.getSubCategory() != null
                                ? menuItem.getSubCategory().getName()
                                : null
                )

                .build();
    }

    private void validateImageUrl(String imageUrl) {
        if (imageUrl == null || imageUrl.isBlank()) {
            throw new RuntimeException("Menu item image is required.");
        }
    }
}
