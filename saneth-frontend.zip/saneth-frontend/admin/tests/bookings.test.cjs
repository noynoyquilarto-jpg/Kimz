// Run with: node saneth-admin-frontend/tests/bookings.test.cjs
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../js/bookings.js'), 'utf8')
  .replace(/import\s*\{[\s\S]*?\}\s*from\s*'[^']+';/g, '')
  .replace(/^loadBookings\(true, true\);$/m, '');
const elements = new Map();
function element(id) {
  if (!elements.has(id)) elements.set(id, {
    value: '', innerHTML: '', textContent: '', disabled: false, hidden: false,
    classList: { contains: () => true, add() {}, remove() {}, toggle() {} },
    dataset: {}, handlers: {}, elements: {},
    addEventListener(type, handler) { this.handlers[type] = handler; }, querySelector: () => null, querySelectorAll: () => [], reset() {}, focus() {},
    showModal() { this.open = true; },
    close() { this.open = false; this.handlers.close?.(); },
    reportValidity: () => true
  });
  return elements.get(id);
}
const alerts = [];
const calls = [];
let records = [];
let failMutation = false;
let failRefresh = false;
let confirmResult = true;
let reason = 'Customer requested cancellation';
const context = vm.createContext({
  document: { hidden: false, getElementById: element, querySelectorAll: () => [] },
  requireAuth() {}, initLayout() {}, setInterval() {}, watchEmail() {},
  peso: value => `PHP ${Number(value).toFixed(2)}`, safe: value => String(value ?? ''),
  badge: value => String(value ?? ''), alert: value => alerts.push(value),
  confirm: () => confirmResult, prompt: () => reason,
  apiRequest: async (url, options) => {
    calls.push({ url, options });
    if (!options) {
      if (failRefresh) throw new Error('Refresh unavailable');
      return records.map(record => ({ ...record }));
    }
    if (failMutation) throw new Error('Save rejected');
    const record = records[0];
    const body = options.body ? JSON.parse(options.body) : {};
    if (url.endsWith('/payment')) {
      record.downPaymentAmount = body.downPaymentAmount;
      record.paymentStatus = record.downPaymentAmount === record.quotedPrice ? 'FULLY_PAID' : 'AWAITING_PAYMENT';
    } else if (url.endsWith('/confirm')) {
      Object.assign(record, { quotedPrice: body.quotedPrice, requiredDownPayment: body.downPayment,
        downPaymentAmount: 0, bookingStatus: 'CONFIRMED' });
    } else if (url.endsWith('/complete')) record.bookingStatus = 'COMPLETED';
    else if (url.endsWith('/cancel')) record.bookingStatus = 'CANCELLED';
    else if (url.includes('/archives/')) record.bookingStatus = 'ARCHIVED';
    else Object.assign(record, body);
    return { ...record };
  }
});
vm.runInContext(source, context);
// Exercise the current payment form handler; the former updatePayment helper was removed.
context.updatePayment = async (id, amount) => {
  const form = element('editPaymentForm');
  form.dataset.id = id;
  form.elements.totalPaid = { value: amount };
  form.elements.paymentMethod = { value: 'CASH' };
  form.reportValidity = () => Number(amount) >= 0 && Number(amount) <= Number(records[0].quotedPrice);
  return form.handlers.submit({ preventDefault() {}, currentTarget: form });
};
const evaluate = code => vm.runInContext(code, context);
async function reset(status = 'CONFIRMED', paid = 30000) {
  failMutation = false; failRefresh = false; confirmResult = true;
  records = [{ id: 1, bookingReference: 'TEST-1', bookingStatus: status,
    quotedPrice: 50000, downPaymentAmount: paid, paymentStatus: 'AWAITING_PAYMENT' }];
  await context.loadBookings(false, true);
  calls.length = 0; alerts.length = 0;
}

async function run() {
  await reset();
  assert.equal(context.canCompleteBooking(records[0]), false);
  assert.match(context.renderActions(records[0]), /data-complete="1"\s+disabled/);
  await context.updateBooking({ disabled: false }, 1, 'complete');
  assert.equal(calls.length, 0, 'Partial payment must not complete');
  await context.updatePayment(1, 50001);
  assert.equal(calls.length, 0, 'Overpayment must not be saved');
  await context.updatePayment(1, 50000);
  assert.equal(calls[0].url, '/api/admin/bookings/1/payment');
  assert.deepEqual(JSON.parse(calls[0].options.body), { downPaymentAmount: 50000, paymentMethod: 'CASH' });
  assert.equal(element('countConfirmed').textContent, 1);
  assert.equal(context.canCompleteBooking(records[0]), true);
  calls.length = 0;
  await context.updateBooking({ disabled: false }, 1, 'complete');
  assert.equal(calls.length, 0, 'Opening the dialog must not complete the booking');
  assert.equal(element('completeBookingDialog').open, true);
  await element('submitCompleteBooking').handlers.click();
  assert.equal(element('countCompleted').textContent, 1);
  assert.equal(element('completeBookingDialog').open, false);
  assert.equal(element('countConfirmed').textContent, 0);
  evaluate("activeBookingFilter = 'CONFIRMED'");
  assert.equal(context.getFilteredBookings().length, 0);
  evaluate("activeBookingFilter = 'ALL'");

  await reset('CONFIRMED', 50000);
  confirmResult = false;
  await context.updateBooking({ disabled: false }, 1, 'complete');
  element('cancelCompleteBooking').handlers.click();
  assert.equal(calls.length, 0, 'Declined confirmation must not send a request');
  confirmResult = true; failMutation = true;
  await context.updateBooking({ disabled: false }, 1, 'complete');
  await element('submitCompleteBooking').handlers.click();
  assert.equal(evaluate('bookingsCache[0].bookingStatus'), 'CONFIRMED');
  assert.equal(evaluate('isUpdating'), false);
  assert.equal(alerts.at(-1), 'Save rejected');
  assert.equal(element('completeBookingDialog').open, true, 'Failed completion stays open for retry');
  assert.equal(element('submitCompleteBooking').disabled, false);
  element('cancelCompleteBooking').handlers.click();

  await reset('CONFIRMED', 50000);
  await context.updateBooking({ disabled: false }, 1, 'complete');
  evaluate('bookingsCache[0].downPaymentAmount = 30000');
  await element('submitCompleteBooking').handlers.click();
  assert.equal(calls.length, 0, 'Payment must be checked again when confirming');

  await reset('PENDING', 0);
  element('confirmBookingId').value = '1';
  element('confirmQuotedPrice').value = '50000';
  element('confirmDownPayment').value = '30000';
  await context.confirmBooking({ preventDefault() {} });
  assert.deepEqual(JSON.parse(calls[0].options.body), { quotedPrice: 50000, downPayment: 30000 });
  assert.equal(records[0].downPaymentAmount, 0);

  await reset();
  for (const [id, value] of Object.entries({ editBookingId: '1', editEventType: 'Birthday',
    editEventDate: '2026-12-31', editEventTime: '12:00', editEventPlace: 'Venue',
    editNumberOfPax: '150', editAdminNote: '' })) element(id).value = value;
  await context.updateEditedBooking({ preventDefault() {} });
  const editBody = JSON.parse(calls[0].options.body);
  assert.equal(editBody.numberOfPax, 150);
  assert.equal('quotedPrice' in editBody, false);
  assert.equal('downPaymentAmount' in editBody, false);

  await reset();
  reason = '   ';
  await context.cancelBooking({ disabled: false }, 1);
  assert.equal(calls.length, 0);
  reason = ' Customer request ';
  await context.cancelBooking({ disabled: false }, 1);
  assert.equal(JSON.parse(calls[0].options.body).reason, 'Customer request');
  assert.equal(element('countCancelled').textContent, 1);
  calls.length = 0;
  await context.archiveBooking({ disabled: false }, 1);
  assert.equal(element('archiveBookingDialog').open, true);
  assert.equal(element('submitArchiveBooking').disabled, true);
  assert.equal(calls.length, 0, 'Opening archive confirmation must not save');
  element('archiveBookingReason').value = '   ';
  element('archiveBookingReason').handlers.input();
  await element('archiveBookingForm').handlers.submit({ preventDefault() {} });
  assert.equal(calls.length, 0, 'Whitespace reason must not archive');
  element('cancelArchiveBooking').handlers.click();
  assert.equal(element('archiveBookingDialog').open, false);
  await context.archiveBooking({ disabled: false }, 1);
  element('archiveBookingReason').value = '  Event finished  ';
  element('archiveBookingReason').handlers.input();
  assert.equal(element('submitArchiveBooking').disabled, false);
  failMutation = true;
  await element('archiveBookingForm').handlers.submit({ preventDefault() {} });
  assert.equal(element('archiveBookingDialog').open, true, 'Failed archive stays open');
  assert.equal(element('archiveBookingReason').value, '  Event finished  ', 'Keep reason for retry');
  assert.equal(element('submitArchiveBooking').disabled, false);
  failMutation = false;
  calls.length = 0;
  await element('archiveBookingForm').handlers.submit({ preventDefault() {} });
  assert.equal(calls[0].url, '/api/admin/archives/bookings/1');
  assert.equal(JSON.parse(calls[0].options.body).reason, 'Event finished');
  assert.equal(element('archiveBookingDialog').open, false);
  assert.equal(element('countAll').textContent, 0);

  await reset();
  failRefresh = true;
  await context.updatePayment(1, 50000);
  assert.equal(evaluate('bookingsCache[0].downPaymentAmount'), 50000);
  assert.match(element('bookingMessage').textContent, /Payment updated.*Could not refresh/);

  await reset();
  const originalApi = context.apiRequest;
  let resolveOld;
  context.apiRequest = () => new Promise(resolve => { resolveOld = resolve; });
  const oldLoad = context.loadBookings(false, true);
  context.apiRequest = originalApi;
  await context.updatePayment(1, 50000);
  resolveOld([{ ...records[0], downPaymentAmount: 30000 }]);
  await oldLoad;
  assert.equal(evaluate('bookingsCache[0].downPaymentAmount'), 50000, 'Stale polling response must be ignored');

  await reset();
  let resolveSave;
  let saveRequests = 0;
  context.apiRequest = () => {
    saveRequests += 1;
    return new Promise(resolve => { resolveSave = resolve; });
  };
  const saving = context.updatePayment(1, 50000);
  assert.equal(evaluate('isUpdating'), true);
  await context.updatePayment(1, 45000);
  assert.equal(saveRequests, 1, 'Duplicate payment must not send a second request');
  context.apiRequest = originalApi;
  resolveSave({ ...records[0], downPaymentAmount: 50000 });
  await saving;
  assert.equal(evaluate('isUpdating'), false);
  console.log('PASS: booking actions, payment validation, filters/counts, failures, duplicate prevention, and stale refresh protection.');
}

module.exports = run();
