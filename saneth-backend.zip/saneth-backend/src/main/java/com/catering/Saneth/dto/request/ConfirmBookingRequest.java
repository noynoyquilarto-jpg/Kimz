package com.catering.Saneth.dto.request;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class ConfirmBookingRequest {

    @NotNull(message = "Quoted price is required.")
    @DecimalMin(value = "0.01", message = "Quoted price must be greater than 0.")
    @jakarta.validation.constraints.Digits(integer = 10, fraction = 2)
    private BigDecimal quotedPrice;

    @NotNull(message = "Required downpayment is required.")
    @DecimalMin(value = "0.00", message = "Required downpayment cannot be negative.")
    @jakarta.validation.constraints.Digits(integer = 10, fraction = 2)
    private BigDecimal downPayment;
}
