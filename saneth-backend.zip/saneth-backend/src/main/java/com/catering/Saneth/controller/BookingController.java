package com.catering.Saneth.controller;

import com.catering.Saneth.dto.request.BookingRequest;
import com.catering.Saneth.dto.request.TrackBookingRequest;
import com.catering.Saneth.dto.response.BookingResponse;
import com.catering.Saneth.service.BookingService;
import com.catering.Saneth.service.RateLimitService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
public class BookingController {

    private final BookingService bookingService;
    private final RateLimitService rateLimitService;
    private final com.catering.Saneth.service.AdminAuditLogService auditLogService;

    @Value("${saneth.rate-limit.booking.ip:20}")
    private int bookingIpLimit = 20;
    @Value("${saneth.rate-limit.booking.customer:10}")
    private int bookingCustomerLimit = 10;
    @Value("${saneth.rate-limit.tracking.ip:120}")
    private int trackingIpLimit = 120;
    @Value("${saneth.rate-limit.tracking.booking:60}")
    private int trackingBookingLimit = 60;

    @GetMapping("/availability")
    public com.catering.Saneth.dto.response.DateAvailabilityResponse availability(
            @RequestParam("date") @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE) java.time.LocalDate date) {
        return bookingService.getDateAvailability(date);
    }

    @org.springframework.transaction.annotation.Transactional
    @PostMapping
    public BookingResponse createBooking(@Valid @RequestBody BookingRequest request, HttpServletRequest httpRequest) {
        rateLimitService.check(httpRequest, "create-booking", bookingIpLimit, java.time.Duration.ofMinutes(10));
        rateLimitService.checkKey("create-booking:email:" + request.getEmail().trim(), bookingCustomerLimit, java.time.Duration.ofHours(1));
        rateLimitService.checkKey("create-booking:phone:" + request.getPhoneNumber().trim(), bookingCustomerLimit, java.time.Duration.ofHours(1));
        BookingResponse response = bookingService.createBooking(request);
        auditLogService.recordForActor(response.getEmail(), "CUSTOMER_BOOKING_CREATED", "BOOKING", response.getId(),
                "Customer " + response.getCustomerName() + " submitted " + response.getBookingReference()
                        + "; event date: " + response.getEventDate() + "; payment method: " + response.getPaymentMethod());
        return response;
    }

    @PostMapping("/track")
    public BookingResponse trackBooking(@Valid @RequestBody TrackBookingRequest request, HttpServletRequest httpRequest) {
        rateLimitService.check(httpRequest, "track-booking", trackingIpLimit, java.time.Duration.ofMinutes(10));
        rateLimitService.checkKey("track-booking:booking:" + request.getBookingReference().trim() + ":" + request.getEmail().trim(), trackingBookingLimit, java.time.Duration.ofHours(1));
        return bookingService.trackBooking(request);
    }
}
