import { apiRequest, peso, safe, assetUrl } from './customer-api.js';
import { initCustomerLayout } from './customer-layout.js';

initCustomerLayout();

const packageGrid = document.getElementById('packageGrid');
const recommendForm = document.getElementById('recommendForm');
const recommendationResult = document.getElementById('recommendationResult');

loadPackages();
recommendForm?.addEventListener('submit', generateRecommendations);

async function loadPackages() {
  packageGrid.innerHTML = '<div class="skeleton">Loading packages...</div>';

  try {
    const data = await apiRequest('/api/menu-packages');
    if (!Array.isArray(data)) throw new Error('Invalid packages response. Please refresh.');
    const packages = await loadPackageItems(data.filter(pkg => pkg.available !== false));

    if (!packages.length) {
      packageGrid.innerHTML = '<div class="skeleton">No available packages yet.</div>';
      return;
    }

    packageGrid.innerHTML = packages.map(renderPackageCard).join('');
  } catch (error) {
    packageGrid.innerHTML = `<div class="skeleton">${safe(error.message)}</div>`;
  }
}

async function loadPackageItems(packages) {
  return Promise.all(packages.map(async pkg => {
    if (!pkg.items?.length && Array.isArray(pkg.menuItems)) pkg = { ...pkg, items: pkg.menuItems };
    if (Array.isArray(pkg.items) && pkg.items.length) return pkg;

    try {
      const details = await apiRequest(`/api/menu-packages/${encodeURIComponent(pkg.id)}`);
      if (details && !details.items?.length && Array.isArray(details.menuItems)) details.items = details.menuItems;
      if (!details || String(details.id) !== String(pkg.id) || !Array.isArray(details.items)) {
        throw new Error('Package menu items were not returned.');
      }
      return { ...pkg, ...details };
    } catch (error) {
      return { ...pkg, itemDetailsError: error.message || 'Could not load package menu items.' };
    }
  }));
}

async function generateRecommendations(event) {
  event.preventDefault();
  recommendationResult.className = 'result-box show';
  recommendationResult.innerHTML = 'Finding packages...';

  const form = new FormData(recommendForm);
  const body = {
    numberOfPax: Number(form.get('numberOfPax')),
    budget: Number(form.get('budget'))
  };

  try {
    const data = await apiRequest('/api/recommendations/generate', {
      method: 'POST',
      body: JSON.stringify(body)
    });

    if (!data || !data.length) {
      recommendationResult.innerHTML = '<strong>No exact match found.</strong><br>Try increasing the budget or reducing the pax.';
      return;
    }

    recommendationResult.innerHTML = `
      <strong>Recommended for you</strong>
      <div class="status-list">
        ${data.map(item => `
          <div class="status-row">
            <span>${safe(item.packageName)}</span>
            <strong>${peso(item.packagePrice)}</strong>
          </div>
          <p class="package-desc">${safe(item.reason)}</p>
        `).join('')}
      </div>
    `;
  } catch (error) {
    recommendationResult.className = 'result-box show error';
    recommendationResult.innerHTML = safe(error.message);
  }
}

function renderPackageCard(pkg) {
  const image = pkg.imageUrl
    ? `<img src="${safe(assetUrl(pkg.imageUrl))}" alt="${safe(pkg.name)}">`
    : `<div class="placeholder">${safe((pkg.name || 'S').charAt(0))}</div>`;

  const items = (pkg.items || []).map(item => `<span class="chip">${safe(item.name)}</span>`).join('');
  const includedMenu = /^package\s+a$/i.test(String(pkg.name || '').trim())
    ? '<p class="package-desc">Good for birthday</p>'
    : /^package\s+b$/i.test(String(pkg.name || '').trim())
    ? '<p class="package-desc">Good for Reunion</p>'
    : /^package\s+c$/i.test(String(pkg.name || '').trim())
    ? '<p class="package-desc">Good for Christmas parties</p>'
    : items
    ? `<div class="package-included-menu"><strong>Included menu</strong><div class="chip-row">${items}</div></div>`
    : `<p class="package-desc">${/^package\s+c$/i.test(String(pkg.name || '').trim()) ? 'Good for Christmas parties.' : /^package\s+b$/i.test(String(pkg.name || '').trim()) ? 'Good for reunions.' : 'Good for birthdays.'}</p>`;

  return `
    <article class="package-card">
      <div class="package-image">${image}</div>
      <div class="package-body">
        <div class="package-title-row">
          <h3>${safe(pkg.name)}</h3>
          <span class="price">${peso(pkg.packagePrice)}</span>
        </div>
        ${renderPackageDescription(pkg)}
        <div class="chip-row">
          <span class="chip">Good for ${safe(pkg.goodForPax)} pax</span>
        </div>
        ${includedMenu}
        <div class="package-actions">
          <a class="btn btn-dark" href="customer-booking.html?packageId=${pkg.id}">Book package</a>
        </div>
      </div>
    </article>
  `;
}

function renderPackageDescription(pkg) {
  const description = String(pkg.description || '').trim();
  if (!/^package\s+[abc]$/i.test(String(pkg.name || '').trim()) || !description) {
    return `<p class="package-desc">${safe(description || 'A complete catering package for your event.')}</p>`;
  }
  const inclusions = description.replace(/^inclusions?\s*:?\s*/i, '')
    .split(/[;\r\n]+|,\s*:/)
    .map(item => item.replace(/^[\s:•-]+|[\s,;]+$/g, '').trim())
    .filter(Boolean);
  return `<div class="package-desc package-inclusions"><strong>Inclusions</strong><ul>${inclusions.map(item => `<li>${safe(item)}</li>`).join('')}</ul></div>`;
}