package com.catering.Saneth.model.enums;

public enum PaymentStatus {
//    PENDING,
//    CONFIRMED,
//    REJECTED,
//    PARTIAL,
//    FULLY_PAID

    NOT_REQUIRED_YET,
    AWAITING_PAYMENT,
    DOWN_PAYMENT_CONFIRMED,
    PARTIALLY_PAID,
    REJECTED,
    FULLY_PAID
}
