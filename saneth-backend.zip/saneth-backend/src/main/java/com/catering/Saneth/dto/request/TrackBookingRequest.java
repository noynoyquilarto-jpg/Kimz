package com.catering.Saneth.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TrackBookingRequest {

    @NotBlank(message = "Booking reference is required")
    private String bookingReference;

    @Email(message = "Email must be valid")
    @NotBlank(message = "Email is required")
    private String email;
}