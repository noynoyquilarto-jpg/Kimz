import { apiRequest, requireAuth, safe } from './api.js';
import { initLayout } from './layout.js';

requireAuth();
initLayout();

const calendarTitle = document.getElementById('calendarTitle');
const calendarMeta = document.getElementById('calendarMeta');
const calendarGrid = document.getElementById('calendarGrid');
const prevMonthBtn = document.getElementById('prevMonthBtn');
const nextMonthBtn = document.getElementById('nextMonthBtn');
const filterTabs = document.querySelectorAll('[data-calendar-filter]');
const calendarCountAll = document.getElementById('calendarCountAll');
const calendarCountPending = document.getElementById('calendarCountPending');
const calendarCountConfirmed = document.getElementById('calendarCountConfirmed');
const calendarCountCompleted = document.getElementById('calendarCountCompleted');
const calendarCountCancelled = document.getElementById('calendarCountCancelled');

let currentDate = new Date();
let bookingsCache = [];
let activeCalendarFilter = 'CONFIRMED';

prevMonthBtn.addEventListener('click', () => {
  currentDate.setMonth(currentDate.getMonth() - 1);
  renderCalendar();
});

nextMonthBtn.addEventListener('click', () => {
  currentDate.setMonth(currentDate.getMonth() + 1);
  renderCalendar();
});

filterTabs.forEach(tab => {
  tab.addEventListener('click', () => {
    activeCalendarFilter = tab.dataset.calendarFilter;
    updateFilterTabs();
    renderCalendar();
  });
});

loadCalendarBookings();

setInterval(loadCalendarBookings, 5000);

async function loadCalendarBookings() {
  try {
    const bookings = await apiRequest('/api/admin/bookings');
    bookingsCache = bookings || [];
    updateCalendarCounts();
    renderCalendar();
  } catch (error) {
    calendarGrid.innerHTML = `<div class="calendar-error">${safe(error.message)}</div>`;
  }
}

function renderCalendar() {
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const monthName = currentDate.toLocaleString('default', {
    month: 'long',
    year: 'numeric'
  });

  calendarTitle.textContent = monthName;

  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);

  const startDay = firstDay.getDay();
  const totalDays = lastDay.getDate();

  let html = '';

  for (let i = 0; i < startDay; i++) {
    html += `<div class="calendar-day empty"></div>`;
  }

  for (let day = 1; day <= totalDays; day++) {
    const dateKey = formatDateKey(year, month, day);
    const dayBookings = getFilteredBookings().filter(booking => booking.eventDate === dateKey);

    html += `
      <div class="calendar-day">
        <div class="calendar-date">${day}</div>

        <div class="calendar-events">
          ${
            dayBookings.length
              ? dayBookings.map(booking => `
                  <div class="calendar-event calendar-event-${statusClass(booking.bookingStatus)}" title="${safe(booking.customerName)}">
                    <strong>${safe(booking.eventTime || '')}</strong>
                    <span>${safe(booking.customerName)}</span>
                    <small>${safe(booking.bookingStatus)} - ${safe(booking.menuPackageName || booking.eventType || '')}</small>
                  </div>
                `).join('')
              : ''
          }
        </div>
      </div>
    `;
  }

  calendarGrid.innerHTML = html;
}

function getFilteredBookings() {
  if (activeCalendarFilter === 'ALL') {
    return bookingsCache;
  }

  return bookingsCache.filter(booking => booking.bookingStatus === activeCalendarFilter);
}

function updateFilterTabs() {
  filterTabs.forEach(tab => {
    tab.classList.toggle('active', tab.dataset.calendarFilter === activeCalendarFilter);
  });

  const label = getFilterLabel(activeCalendarFilter);
  calendarMeta.textContent = activeCalendarFilter === 'ALL'
    ? 'Showing every active booking.'
    : `Showing ${label.toLowerCase()} bookings.`;
}

function updateCalendarCounts() {
  const counts = countBookingsByStatus(bookingsCache);

  calendarCountAll.textContent = counts.ALL;
  calendarCountPending.textContent = counts.PENDING;
  calendarCountConfirmed.textContent = counts.CONFIRMED;
  calendarCountCompleted.textContent = counts.COMPLETED;
  calendarCountCancelled.textContent = counts.CANCELLED;
}

function countBookingsByStatus(bookings) {
  return bookings.reduce((counts, booking) => {
    counts.ALL += 1;
    if (counts[booking.bookingStatus] !== undefined) {
      counts[booking.bookingStatus] += 1;
    }
    return counts;
  }, {
    ALL: 0,
    PENDING: 0,
    CONFIRMED: 0,
    COMPLETED: 0,
    CANCELLED: 0
  });
}

function getFilterLabel(status) {
  return {
    ALL: 'All',
    PENDING: 'Pending',
    CONFIRMED: 'Confirmed',
    COMPLETED: 'Completed',
    CANCELLED: 'Cancelled'
  }[status] || 'Confirmed';
}

function statusClass(status) {
  return String(status || 'muted').toLowerCase().replaceAll('_', '-');
}

function formatDateKey(year, month, day) {
  const mm = String(month + 1).padStart(2, '0');
  const dd = String(day).padStart(2, '0');

  return `${year}-${mm}-${dd}`;
}
