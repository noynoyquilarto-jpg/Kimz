CREATE TABLE IF NOT EXISTS booking_capacity_lock (id INTEGER PRIMARY KEY);
MERGE INTO booking_capacity_lock KEY(id) VALUES (1);
