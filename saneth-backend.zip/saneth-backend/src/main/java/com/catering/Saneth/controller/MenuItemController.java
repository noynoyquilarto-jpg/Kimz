package com.catering.Saneth.controller;


import com.catering.Saneth.dto.request.MenuItemRequest;
import com.catering.Saneth.dto.response.MenuItemResponse;
import com.catering.Saneth.service.AdminAuditLogService;
import com.catering.Saneth.service.MenuItemService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@org.springframework.transaction.annotation.Transactional
@RestController
@RequestMapping("/api/admin/menu-items")
@RequiredArgsConstructor
public class MenuItemController {

    private final MenuItemService service;
    private final AdminAuditLogService adminAuditLogService;

    @PostMapping
    public MenuItemResponse createMenuItem(@Valid @RequestBody MenuItemRequest request){
        MenuItemResponse response = service.createMenuItem(request);
        adminAuditLogService.record("MENU_ITEM_CREATED", "MENU_ITEM", response.getId(), response.getName());
        return response;
    }

    @GetMapping
    public List<MenuItemResponse> getAllMenu(){
        return service.getAllMenu();
    }

    @GetMapping("/{id}")
    public MenuItemResponse getMenuById(@PathVariable Long id){
        return service.getMenuById(id);
    }


    @PutMapping("/{id}")
    public MenuItemResponse updateMenu(@PathVariable Long id,@Valid @RequestBody MenuItemRequest request){
        MenuItemResponse response = service.updateMenu(id, request);
        adminAuditLogService.record("MENU_ITEM_UPDATED", "MENU_ITEM", id, response.getName());
        return response;
    }

    @DeleteMapping("/{id}")
    public String deleteMenuItem(@PathVariable Long id){
        service.deleteMenuItem(id);
        adminAuditLogService.record("MENU_ITEM_DELETED", "MENU_ITEM", id, "Menu item deleted");
        return "Menu Item has been deleted!";
    }
}
