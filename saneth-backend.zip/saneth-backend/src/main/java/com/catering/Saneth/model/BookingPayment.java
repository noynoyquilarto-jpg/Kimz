package com.catering.Saneth.model;

import com.catering.Saneth.model.enums.PaymentMethod;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "booking_payments", uniqueConstraints = @UniqueConstraint(name = "uq_payment_submission", columnNames = {"booking_id", "submission_key"}))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BookingPayment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "booking_id", nullable = false)
    private Booking booking;

    @Column(nullable = false)
    private Double amount;

    @Enumerated(EnumType.STRING)
    // Older aggregate payments may not have a recorded method.
    @Column
    private PaymentMethod paymentMethod;

    private String paymentReferenceNumber;

    private String note;

    private LocalDateTime createdAt;

    @Builder.Default
    @Column(nullable = false, length = 30)
    private String verificationStatus = "VERIFIED";
    private LocalDateTime verifiedAt;
    @Column(length = 36)
    private String submissionKey;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        if ("VERIFIED".equals(verificationStatus) && verifiedAt == null) verifiedAt = LocalDateTime.now();
    }
}
