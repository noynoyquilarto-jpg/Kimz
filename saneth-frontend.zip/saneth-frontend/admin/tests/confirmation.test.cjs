const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const source = fs.readFileSync(require('node:path').join(__dirname, '../js/bookings.js'), 'utf8');
const mutation = source.slice(source.indexOf('async function mutateBooking('), source.indexOf('// ============================================================\n// EVENTS'));
module.exports = (async () => {
  for (const status of ['CONFIRMED', 'PENDING', 'unreachable']) {
    let closed = false;
    let message;
    let writes = 0;
    const context = vm.createContext({
      isUpdating: false, loadVersion: 0, isLoading: false,
      bookingsCache: [{ id: 1, bookingStatus: 'PENDING' }],
      document: { querySelectorAll: () => [] },
      updateBookingCounts() {}, renderBookings() {}, getFilteredBookings: () => [],
      showMessage: text => { message = text; }, alert() {},
      apiRequest: async (url, options) => {
        if (options) { writes++; throw new Error('Mail server connection failed: PKIX path building failed'); }
        if (status === 'unreachable') throw new Error('Unavailable');
        return { id: 1, bookingStatus: status, quotedPrice: 50000, requiredDownPayment: 25000 };
      }
    });
    vm.runInContext(mutation, context);
    const result = await context.mutateBooking(1, '/api/admin/bookings/1/confirm',
      { quotedPrice: 50000, downPayment: 25000 }, 'Confirmed', () => { closed = true; });
    assert.equal(result, status === 'CONFIRMED');
    assert.equal(closed, status === 'CONFIRMED');
    assert.equal(writes, 1, 'Never automatically repeat a confirmation');
    assert.equal(context.isUpdating, false);
    assert.match(message, status === 'CONFIRMED' ? /confirmed.*email could not be sent/ : /Could not verify/);
  }
  console.log('PASS: saved confirmation recovery, rollback, failed state check, and no duplicate confirmation.');
})();
