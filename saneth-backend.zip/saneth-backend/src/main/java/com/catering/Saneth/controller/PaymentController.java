package com.catering.Saneth.controller;


import com.catering.Saneth.dto.request.PaymentConfirmRequest;
import com.catering.Saneth.dto.request.PaymentRecordRequest;
import com.catering.Saneth.dto.request.UpdatePaymentStatusRequest;
import com.catering.Saneth.dto.response.PaymentResponse;
import com.catering.Saneth.service.AdminAuditLogService;
import com.catering.Saneth.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@org.springframework.transaction.annotation.Transactional
@RestController
@RequestMapping("/api/admin/payments")
@RequiredArgsConstructor
public class PaymentController {
    private final PaymentService service;
    private final AdminAuditLogService adminAuditLogService;

    @GetMapping
    public List<PaymentResponse> getAllPayments(){
        return service.getAllPayments();
    }

    @GetMapping("/booking/{bookingId}")
    public PaymentResponse getPaymentByBookingId(@PathVariable Long bookingId) {
        return service.getPaymentByBookingId(bookingId);
    }

    @PutMapping("/booking/{bookingId}/confirm")
    public PaymentResponse confirmPayment(
            @PathVariable Long bookingId,
            @Valid @RequestBody PaymentConfirmRequest request
    ){
        PaymentResponse response = service.confirmPayment(bookingId, request);
        adminAuditLogService.record("PAYMENT_CONFIRMED", "BOOKING", bookingId, "Down payment confirmed");
        return response;
    }

    @PostMapping("/booking/{bookingId}/payments")
    public PaymentResponse addPayment(
            @PathVariable Long bookingId,
            @Valid @RequestBody PaymentRecordRequest request
    ){
        PaymentResponse response = service.addPayment(bookingId, request);
        adminAuditLogService.record("PAYMENT_ADDED", "BOOKING", bookingId, "Payment added: " + request.getAmount());
        return response;
    }

    @PutMapping("/booking/{bookingId}/payments/{paymentId}/verify")
    public PaymentResponse verifySubmitted(@PathVariable Long bookingId, @PathVariable Long paymentId) {
        var response = service.verifyPayment(bookingId, paymentId);
        adminAuditLogService.record("PAYMENT_VERIFIED", "PAYMENT", paymentId, "Customer payment verified");
        return response;
    }
    @PutMapping("/booking/{bookingId}/payments/{paymentId}/reject")
    public PaymentResponse rejectSubmitted(@PathVariable Long bookingId, @PathVariable Long paymentId, @Valid @RequestBody UpdatePaymentStatusRequest request) {
        var response = service.rejectSubmittedPayment(bookingId, paymentId, request.getReason());
        adminAuditLogService.record("PAYMENT_REJECTED", "PAYMENT", paymentId, request.getReason());
        return response;
    }

    @PutMapping("/booking/{bookingId}/reject")
    public PaymentResponse rejectPayment(@PathVariable Long bookingId, @Valid @RequestBody UpdatePaymentStatusRequest request){
        PaymentResponse response = service.rejectPayment(bookingId, request.getReason());
        adminAuditLogService.record("PAYMENT_REJECTED", "BOOKING", bookingId, request.getReason());
        return response;
    }

    @PutMapping("/booking/{bookingId}/status")
    public PaymentResponse updatePayment(
            @PathVariable Long bookingId, @Valid @RequestBody UpdatePaymentStatusRequest request
    ){
        PaymentResponse response = service.updatePaymentStatus(bookingId, request.getStatus(), request.getReason());
        adminAuditLogService.record("PAYMENT_STATUS_UPDATED", "BOOKING", bookingId, "Status set to " + request.getStatus());
        return response;
   }




}
