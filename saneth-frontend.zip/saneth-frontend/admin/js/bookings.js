import { showAlert as alert, showPrompt as prompt } from '../../js/dialogs.js';
import { watchEmail } from './email-notifications.js';
import {
apiRequest,
requireAuth,
peso,
badge,
assetUrl,
safe
} from './api.js';

import { initLayout } from './layout.js';

requireAuth();
initLayout();

const table = document.getElementById('bookingsTable');
const refreshBtn = document.getElementById('refreshBtn');

const filterTabs =
document.querySelectorAll('[data-booking-filter]');

const bookingsSectionTitle =
document.getElementById('bookingsSectionTitle');

const bookingsSectionMeta =
document.getElementById('bookingsSectionMeta');

const countAll =
document.getElementById('countAll');

const countPending =
document.getElementById('countPending');

const countConfirmed =
document.getElementById('countConfirmed');

const countCompleted =
document.getElementById('countCompleted');

const countCancelled =
document.getElementById('countCancelled');

// ============================================================
// EDIT MODAL
// ============================================================

const editModal =
document.getElementById('editBookingModal');

const editForm =
document.getElementById('editBookingForm');

const closeEditModalBtn =
document.getElementById('closeEditModalBtn');

const cancelEditBtn =
document.getElementById('cancelEditBtn');

const editBookingId =
document.getElementById('editBookingId');

const editEventType =
document.getElementById('editEventType');

const editEventDate =
document.getElementById('editEventDate');

const editEventTime =
document.getElementById('editEventTime');

const editEventPlace =
document.getElementById('editEventPlace');

const editNumberOfPax =
document.getElementById('editNumberOfPax');

const editQuotedPrice =
document.getElementById('editQuotedPrice');

const editDownPayment =
document.getElementById('editDownPayment');

const editAdminNote =
document.getElementById('editAdminNote');

const selectedMenuItems =
document.getElementById('selectedMenuItems');

const selectedAddons =
document.getElementById('selectedAddons');

// CUSTOMER DETAILS

const detailCustomerName =
document.getElementById('detailCustomerName');

const detailCustomerEmail =
document.getElementById('detailCustomerEmail');

const detailCustomerPhone =
document.getElementById('detailCustomerPhone');

const detailCustomerAddress =
document.getElementById('detailCustomerAddress');

// EDIT PRICE DISPLAY

const quotedPriceDisplay =
document.getElementById('quotedPriceDisplay');

const downPaymentDisplay =
document.getElementById('downPaymentDisplay');

const remainingBalanceDisplay =
document.getElementById('remainingBalanceDisplay');

// ============================================================
// CONFIRM MODAL
// ============================================================

const confirmBookingModal =
document.getElementById('confirmBookingModal');

const confirmBookingForm =
document.getElementById('confirmBookingForm');

const closeConfirmModalBtn =
document.getElementById('closeConfirmModalBtn');

const cancelConfirmBtn =
document.getElementById('cancelConfirmBtn');

const confirmBookingId =
document.getElementById('confirmBookingId');

const confirmBookingReference =
document.getElementById('confirmBookingReference');

const confirmCustomerName =
document.getElementById('confirmCustomerName');

const confirmQuotedPrice =
document.getElementById('confirmQuotedPrice');

const confirmDownPayment =
document.getElementById('confirmDownPayment');

const confirmQuotedDisplay =
document.getElementById('confirmQuotedDisplay');

const confirmDownPaymentDisplay =
document.getElementById('confirmDownPaymentDisplay');

const confirmBalanceDisplay =
document.getElementById('confirmBalanceDisplay');

// ============================================================
// LOCATION MODAL
// ============================================================

const locationModal =
document.getElementById('bookingLocationModal');

const closeLocationModalBtn =
document.getElementById('closeLocationModalBtn');

const closeLocationModalFooterBtn =
document.getElementById('closeLocationModalFooterBtn');

const locationModalTitle =
document.getElementById('locationModalTitle');

const locationPlaceText =
document.getElementById('locationPlaceText');

const locationPinText =
document.getElementById('locationPinText');

const locationNoteText =
document.getElementById('locationNoteText');

const locationMapFrame =
document.getElementById('locationMapFrame');

const locationMapLink =
document.getElementById('locationMapLink');

// ============================================================
// STATE
// ============================================================

let bookingsCache = [];

let isLoading = false;

let isUpdating = false;

let activeBookingFilter = 'ALL';
let loadVersion = 0;
const bookingMessage = document.getElementById('bookingMessage');
const selectedArchiveIds = new Set();
const selectAllBookings = document.getElementById('selectAllBookings');
const archiveSelectedBtn = document.getElementById('archiveSelectedBtn');
const archiveIcon = '<svg class="record-action-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 8h16v13H4zM3 3h18v5H3zM9 12h6"/></svg>';
archiveSelectedBtn.innerHTML = archiveIcon + 'Archive Selected';

function archiveEligible(booking) {
  return ['COMPLETED', 'CANCELLED'].includes(booking.bookingStatus);
}

function syncArchiveSelection() {
  const eligible = getFilteredBookings().filter(archiveEligible);
  const validIds = new Set(bookingsCache.filter(archiveEligible).map(booking => String(booking.id)));
  selectedArchiveIds.forEach(id => { if (!validIds.has(id)) selectedArchiveIds.delete(id); });
  const count = eligible.filter(booking => selectedArchiveIds.has(String(booking.id))).length;
  selectAllBookings.checked = eligible.length > 0 && count === eligible.length;
  selectAllBookings.indeterminate = count > 0 && count < eligible.length;
  selectAllBookings.disabled = isUpdating || !eligible.length;
  archiveSelectedBtn.disabled = isUpdating || !count;
  table.querySelectorAll('[data-archive-select]').forEach(input => {
    input.checked = selectedArchiveIds.has(input.dataset.archiveSelect);
    input.disabled = isUpdating;
  });
}

selectAllBookings.addEventListener('change', () => {
  if (isUpdating) return;
  getFilteredBookings().filter(archiveEligible).forEach(booking => {
    if (selectAllBookings.checked) selectedArchiveIds.add(String(booking.id));
    else selectedArchiveIds.delete(String(booking.id));
  });
  syncArchiveSelection();
});
table.addEventListener('change', event => {
  const input = event.target.closest('[data-archive-select]');
  if (!input || isUpdating) return;
  if (input.checked) selectedArchiveIds.add(input.dataset.archiveSelect);
  else selectedArchiveIds.delete(input.dataset.archiveSelect);
  syncArchiveSelection();
});
archiveSelectedBtn.addEventListener('click', async () => {
  if (isUpdating) return;
  const bookings = getFilteredBookings().filter(booking => archiveEligible(booking) && selectedArchiveIds.has(String(booking.id)));
  if (!bookings.length) return;
  const reason = (await prompt(`Reason for archiving ${bookings.length} selected booking(s):`))?.trim();
  if (!reason) return;
  isUpdating = true;
  loadVersion += 1;
  isLoading = false;
  renderBookings(getFilteredBookings());
  let archived = 0;
  const failures = [];
  try {
    for (const booking of bookings) {
      try {
        await apiRequest('/api/admin/archives/bookings/' + encodeURIComponent(booking.id), {
          method: 'PUT', body: JSON.stringify({ reason })
        });
        bookingsCache = bookingsCache.filter(item => String(item.id) !== String(booking.id));
        selectedArchiveIds.delete(String(booking.id));
        archived += 1;
      } catch (error) { failures.push(`${booking.bookingReference}: ${error.message}`); }
    }
    await loadBookings(false, true);
  } finally {
    isUpdating = false;
    updateBookingCounts();
    renderBookings(getFilteredBookings());
    showMessage(`${archived} booking(s) archived.${failures.length ? ' Could not archive: ' + failures.join('; ') : ''}`);
  }
});


function showMessage(message) {
  bookingMessage.textContent = message;
  bookingMessage.hidden = !message;
}

function findBooking(id, statuses) {
  const booking = bookingsCache.find(item => String(item.id) === String(id));
  if (!booking || (statuses && !statuses.includes(booking.bookingStatus))) {
    alert('This booking is no longer available for this action. Refresh and try again.');
    return null;
  }
  return booking;
}

function canCompleteBooking(booking) {
  const quoted = Number(booking.quotedPrice);
  const paid = Number(booking.downPaymentAmount ?? 0);
  return booking.bookingStatus === 'CONFIRMED' &&
    Number.isFinite(quoted) && quoted > 0 &&
    Number.isFinite(paid) && paid >= quoted;
}

async function mutateBooking(id, path, body, message, onSuccess) {
  if (isUpdating) return false;
  isUpdating = true;
  // Invalidate any list response that began before this mutation.
  loadVersion += 1;
  isLoading = false;
  const controls = [...document.querySelectorAll('#bookingsTable button, #refreshBtn, .modal button')];
  const previousDisabled = controls.map(control => control.disabled);
  controls.forEach(control => { control.disabled = true; });
  showMessage('Saving booking...');
  try {
    const updated = await apiRequest(path, {
      method: 'PUT',
      ...(body === undefined ? {} : { body: JSON.stringify(body) })
    });
    if (updated && String(updated.id) === String(id)) {
      bookingsCache = bookingsCache.map(booking => String(booking.id) === String(id) ? updated : booking)
        .filter(booking => booking.bookingStatus !== 'ARCHIVED');
    }
    updateBookingCounts();
    renderBookings(getFilteredBookings());
    onSuccess?.();
    const refreshed = await loadBookings(false, true);
    const emailPending = path.endsWith('/confirm') ? ' Confirmation email is queued for sending.' : '';
    showMessage((refreshed ? message : message + ' Could not refresh the list. Please click Refresh.') + emailPending);
    if (path.endsWith('/confirm')) watchEmail(id, 'CONFIRMATION', status => showMessage('Booking confirmed. ' + status));
    return true;
  } catch (error) {
    // Older backend builds may save a confirmation before SMTP throws.
    // Verify the saved state before suggesting that the admin retries.
    if (path.endsWith('/confirm') && /mail|smtp|TLS|PKIX|certificate/i.test(error.message || '')) {
      try {
        const saved = await apiRequest('/api/admin/bookings/' + id);
        if (saved?.bookingStatus === 'CONFIRMED' &&
            Number(saved.quotedPrice) === Number(body.quotedPrice) &&
            Number(saved.requiredDownPayment) === Number(body.downPayment)) {
          bookingsCache = bookingsCache.map(booking => String(booking.id) === String(id) ? saved : booking);
          updateBookingCounts();
          onSuccess?.();
          showMessage('Booking confirmed. The confirmation email could not be sent. Please contact the customer directly.');
          return true;
        }
      } catch { /* Leave the modal open when the saved state cannot be verified. */ }
      showMessage('Could not verify the booking confirmation after an email error. Refresh the bookings list before trying again.');
      return false;
    }
    showMessage(error.message || 'Unable to save the booking. Please try again.');
    alert(error.message || 'Unable to save the booking. Please try again.');
    return false;
  } finally {
    isUpdating = false;
    controls.forEach((control, index) => { control.disabled = previousDisabled[index]; });
    renderBookings(getFilteredBookings());
  }
}

// ============================================================
// EVENTS
// ============================================================

if (refreshBtn) {
refreshBtn.addEventListener(
'click',
() => { if (!isUpdating) loadBookings(true, true); }
);
}

filterTabs.forEach(tab => {

tab.addEventListener('click', () => {

activeBookingFilter =
  tab.dataset.bookingFilter;

updateFilterTabs();

renderBookings(
  getFilteredBookings()
);

});

});

closeEditModalBtn?.addEventListener(
'click',
closeEditModal
);

cancelEditBtn?.addEventListener(
'click',
closeEditModal
);

closeConfirmModalBtn?.addEventListener(
'click',
closeConfirmModal
);

cancelConfirmBtn?.addEventListener(
'click',
closeConfirmModal
);

closeLocationModalBtn?.addEventListener(
'click',
closeLocationModal
);

closeLocationModalFooterBtn?.addEventListener(
'click',
closeLocationModal
);

editForm?.addEventListener(
'submit',
updateEditedBooking
);

confirmBookingForm?.addEventListener(
'submit',
confirmBooking
);

editQuotedPrice?.addEventListener(
'input',
updateEditPriceDisplay
);

editDownPayment?.addEventListener(
'input',
updateEditPriceDisplay
);

confirmQuotedPrice?.addEventListener(
'input',
updateConfirmPriceDisplay
);

confirmDownPayment?.addEventListener(
'input',
updateConfirmPriceDisplay
);

// ============================================================
// INITIAL LOAD
// ============================================================

loadBookings(true, true);

// Refresh every 3 seconds

setInterval(() => {

if (!isUpdating && !document.hidden && !completeBookingDialog.open && !archiveBookingDialog.open &&
    [editModal, confirmBookingModal, locationModal, document.getElementById('editPaymentModal')].every(modal => modal.classList.contains('hidden'))) {
loadBookings(false, false);
}

}, 3000);

// ============================================================
// LOAD BOOKINGS
// ============================================================

async function loadBookings(showLoading = true, force = false) {
  if ((isLoading || isUpdating) && !force) return false;
  const version = ++loadVersion;
  isLoading = true;
  if (showLoading && !bookingsCache.length) {
    table.innerHTML = '<tr><td colspan="9">Loading bookings...</td></tr>';
  }
  try {
    const bookings = await apiRequest('/api/admin/bookings');
    if (!Array.isArray(bookings)) throw new Error('Invalid booking response. Please refresh.');
    await loadBookingPackageMenus(bookings);
    if (version !== loadVersion) return false;
    if (!Array.isArray(bookings)) throw new Error('Invalid booking response. Please refresh.');
    bookingsCache = bookings.filter(booking => booking.bookingStatus !== 'ARCHIVED');
    updateBookingCounts();
    updateFilterTabs();
    renderBookings(getFilteredBookings());
    if (!isUpdating) showMessage('');
    return true;
  } catch (error) {
    if (version !== loadVersion) return false;
    showMessage('Could not refresh bookings: ' + error.message);
    if (!bookingsCache.length) {
      table.innerHTML = '<tr><td colspan="9">Unable to load bookings. Click Refresh to try again.</td></tr>';
    }
    return false;
  } finally {
    if (version === loadVersion) isLoading = false;
  }
}

// ============================================================
// FILTER
// ============================================================

function getFilteredBookings() {

if (activeBookingFilter === 'ALL') {
return bookingsCache;
}

return bookingsCache.filter(
booking =>
booking.bookingStatus ===
activeBookingFilter
);

}

function updateFilterTabs() {

filterTabs.forEach(tab => {

tab.classList.toggle(
  'active',
  tab.dataset.bookingFilter ===
  activeBookingFilter
);

});

const label =
getFilterLabel(activeBookingFilter);

bookingsSectionTitle.textContent =
`${label} Bookings`;

bookingsSectionMeta.textContent =
activeBookingFilter === 'ALL'
? 'Showing all non-archived bookings.'
: `Showing ${label.toLowerCase()} bookings only.`;

}

function updateBookingCounts() {

const counts =
countBookingsByStatus(
bookingsCache
);

countAll.textContent =
counts.ALL;

countPending.textContent =
counts.PENDING;

countConfirmed.textContent =
counts.CONFIRMED;

countCompleted.textContent =
counts.COMPLETED;

countCancelled.textContent =
counts.CANCELLED;

}

function countBookingsByStatus(bookings) {

return bookings.reduce(
(counts, booking) => {

  counts.ALL += 1;

  if (
    counts[booking.bookingStatus]
    !== undefined
  ) {

    counts[
      booking.bookingStatus
    ] += 1;

  }

  return counts;

},
{
  ALL: 0,
  PENDING: 0,
  CONFIRMED: 0,
  COMPLETED: 0,
  CANCELLED: 0
}

);

}

function getFilterLabel(status) {

return {

ALL: 'All',

PENDING: 'Pending',

CONFIRMED: 'Confirmed',

COMPLETED: 'Completed',

CANCELLED: 'Cancelled'

}[status] || 'All';

}

// ============================================================
// RENDER BOOKINGS
// ============================================================

function renderBookings(bookings) {
syncArchiveSelection();

if (!bookings.length) {

table.innerHTML = `
  <tr>
    <td colspan="9">
      No ${getFilterLabel(
        activeBookingFilter
      ).toLowerCase()} bookings found.
    </td>
  </tr>
`;

return;

}

table.innerHTML =
bookings.map(booking => {

  const location =
    parseEventLocation(
      booking.eventPlace
    );

  const menuText =
    renderMenuSummary(
      booking
    );

  const addonsText =
    renderAddonSummary(
      booking
    );


  const quotedPrice =
    Number(
      booking.quotedPrice ??
      0
    );


  const actualPaid =
    Number(
      booking.downPaymentAmount ??
      0
    );


  const remainingBalance =
    Math.max(
      quotedPrice - actualPaid,
      0
    );


  return `

  <tr>

    <td>
      <strong>
        ${safe(
          booking.bookingReference
        )}
      </strong>
    </td>


    <td>

      ${safe(
        booking.customerName
      )}

      <br>

      <span class="muted">
        ${safe(
          booking.email
        )}
      </span>

    </td>


    <td>

      ${safe(
        booking.eventType
      )}

      <br>

      <span class="muted">

        ${safe(
          booking.eventDate
        )}

        ${safe(
          booking.eventTime
        )}

        • ${safe(
          booking.numberOfPax
        )} pax

      </span>

    </td>


    <td>
      ${renderLocationCell(
        location,
        booking.id
      )}
    </td>


    <td>
      ${menuText}
    </td>


    <td>
      ${addonsText}
    </td>


    <td>

      ${
        quotedPrice > 0
          ? `
            <strong>
              ${peso(quotedPrice)}
            </strong>

            ${
              ['CONFIRMED', 'COMPLETED'].includes(booking.bookingStatus)
                ? `
                  <br>
                  <span class="muted">
                    Paid: ${peso(actualPaid)}
                  </span>

                  <br>

                  <span class="muted">
                    Balance: ${peso(remainingBalance)}
                  </span>
                `
                : ''
            }
          `
          : `
            <span class="muted">
              Not quoted
            </span>
          `
      }

    </td>


    <td>

      ${badge(
        booking.bookingStatus
      )}

      <br>

      ${badge(
        booking.paymentStatus
      )}

    </td>


    <td>

      <div class="actions">

        ${renderActions(
          booking
        )}

      </div>

    </td>

  </tr>

  `;

}).join('');

if (isUpdating) table.querySelectorAll('button').forEach(button => { button.disabled = true; });

table
.querySelectorAll('[data-edit]')
.forEach(button => {

  button.addEventListener(
    'click',
    () =>
      openEditModal(
        button.dataset.edit
      )
  );

});

table
.querySelectorAll('[data-confirm]')
.forEach(button => {

  button.addEventListener(
    'click',
    () =>
      openConfirmModal(
        button.dataset.confirm
      )
  );

});

table
.querySelectorAll('[data-payment]')
.forEach(button => {

  button.addEventListener(
    'click',
    () =>
      window.location.assign(`payments.html?bookingId=${encodeURIComponent(button.dataset.payment)}`)
  );

});

table
.querySelectorAll('[data-complete]')
.forEach(button => {

  button.addEventListener(
    'click',
    () =>
      updateBooking(
        button,
        button.dataset.complete,
        'complete'
      )
  );

});

table
.querySelectorAll('[data-cancel]')
.forEach(button => {

  button.addEventListener(
    'click',
    () =>
      cancelBooking(
        button,
        button.dataset.cancel
      )
  );

});

table
.querySelectorAll('[data-archive]')
.forEach(button => {

button.addEventListener(
    'click',
    () =>
      archiveBooking(
        button,
        button.dataset.archive
      )
  );

});

table
.querySelectorAll('[data-location]')
.forEach(button => {

  button.addEventListener(
    'click',
    () =>
      openLocationModal(
        button.dataset.location
      )
  );

});

}

// ============================================================
// ACTION BUTTONS
// ============================================================

function renderActions(booking) {

const status =
booking.bookingStatus;

if (status === 'PENDING') {

return `

  <button
    class="btn btn-light btn-small"
    data-edit="${booking.id}">
    Review
  </button>


  <button
    class="btn btn-dark btn-small"
    data-confirm="${booking.id}">
    Confirm
  </button>


  <button
    class="btn btn-danger btn-small"
    data-cancel="${booking.id}">
    Cancel
  </button>

`;

}

if (status === 'CONFIRMED') {

return `

  <button
    class="btn btn-light btn-small"
    data-edit="${booking.id}">
    Edit
  </button>


  <button
    class="btn btn-light btn-small"
    data-payment="${booking.id}"
    >
    Record Payment
  </button>


  <button
    class="btn btn-light btn-small"
    data-complete="${booking.id}"
    ${canCompleteBooking(booking) ? '' : 'disabled'}>
    Complete
  </button>
  ${canCompleteBooking(booking) ? '' : '<span class="muted booking-action-help">Record full payment before completing.</span>'}


  <button
    class="btn btn-danger btn-small"
    data-cancel="${booking.id}">
    Cancel
  </button>

`;

}

if (
status === 'COMPLETED' ||
status === 'CANCELLED'
) {

return `

  <label class="record-row-select"><input type="checkbox" data-archive-select="${safe(booking.id)}" aria-label="Select ${safe(booking.bookingReference)} for archiving" ${selectedArchiveIds.has(String(booking.id)) ? 'checked' : ''} ${isUpdating ? 'disabled' : ''}></label>
  <button type="button"
    class="btn btn-small record-archive-action"
    data-archive="${booking.id}" ${isUpdating ? 'disabled' : ''}>
    ${archiveIcon}Archive
  </button>

`;

}

return `     <span class="muted">
      No actions     </span>
  `;

}

// ============================================================
// MENU SUMMARY
// ============================================================

async function loadBookingPackageMenus(bookings) {
  const packageIds = [...new Set(bookings
    .filter(booking => booking.menuPackageId != null && !booking.packageMenuItems?.length)
    .map(booking => String(booking.menuPackageId)))];

  const menus = new Map(await Promise.all(packageIds.map(async id => {
    try {
      const items = await apiRequest(`/api/admin/menu-packages/${encodeURIComponent(id)}/items`);
      if (Array.isArray(items) && items.length) return [id, items];
    } catch (_) {
      // Older servers may expose the menu only in package details.
    }
    try {
      const pack = await apiRequest(`/api/menu-packages/${encodeURIComponent(id)}`);
      return [id, pack.items || pack.menuItems || []];
    } catch (_) {
      return [id, []];
    }
  })));

  bookings.forEach(booking => {
    if (!booking.packageMenuItems?.length && booking.menuPackageId != null) {
      booking.packageMenuItems = menus.get(String(booking.menuPackageId)) || [];
    }
  });
}

function renderMenuSummary(booking) {

const packageItems = booking.packageMenuItems || [];
const customItems = booking.customMenuItems || booking.menuItems || [];
const items = packageItems.length ? packageItems : customItems;
const packageName = booking.menuPackageName;

if (!items.length && !packageName) {
  return '<span class="muted">No menu items</span>';
}

return `
  <div class="menu-summary">
    ${packageName ? `<strong>${safe(packageName)}</strong>` : ''}
    ${items.map(item => `
      <span class="menu-summary-item">${safe(item.name)}</span>
    `).join('')}
    ${!items.length && packageName ? '<span class="muted">Menu items unavailable</span>' : ''}
  </div>
`;

}

// ============================================================
// ADD-ON SUMMARY
// ============================================================

function renderAddonSummary(booking) {

const addons = [];

if (booking.projector === true) {
addons.push('Projector');
}

if (booking.videoke === true) {
addons.push('Videoke');
}

if (booking.lechon === true) {
addons.push('Lechon');
}

if (booking.cake === true) {
addons.push('Cake');
}

if (!addons.length) {

return `
  <span class="muted">
    None
  </span>
`;

}

return `

<div class="addon-summary">

  ${addons.map(addon => `
    <span class="addon-tag">
      ${safe(addon)}
    </span>
  `).join('')}

</div>

`;

}

// ============================================================
// LOCATION
// ============================================================

function parseEventLocation(rawValue) {

const raw =
rawValue || '';

const parts =
raw
.split('|')
.map(part => part.trim())
.filter(Boolean);

const location = {

raw,

place:
  parts[0] ||
  raw ||
  'No event place',

note: '',

lat: null,

lon: null,

mapUrl: ''

};

parts.slice(1)
.forEach(part => {

  if (
    part
      .toLowerCase()
      .startsWith('pin:')
  ) {

    const coordinates =
      part
        .replace(
          /^pin:/i,
          ''
        )
        .split(',')
        .map(
          value =>
            Number(
              value.trim()
            )
        );


    if (
      Number.isFinite(
        coordinates[0]
      ) &&
      Number.isFinite(
        coordinates[1]
      )
    ) {

      location.lat =
        coordinates[0];

      location.lon =
        coordinates[1];

    }

    return;

  }


  if (
    part
      .toLowerCase()
      .startsWith('map:')
  ) {

    location.mapUrl =
      part
        .replace(
          /^map:/i,
          ''
        )
        .trim();

    return;

  }


  if (
    part
      .toLowerCase()
      .startsWith('note:')
  ) {

    location.note =
      part
        .replace(
          /^note:/i,
          ''
        )
        .trim();

  }

});

if (
!location.mapUrl &&
location.lat !== null &&
location.lon !== null
) {

location.mapUrl =
  `https://www.google.com/maps?q=${location.lat},${location.lon}`;

}

return location;

}

function renderLocationCell(
location,
bookingId
) {

const hasPin =
location.lat !== null &&
location.lon !== null;

return `

<div class="booking-location">

  <strong
    title="${safe(
      location.place
    )}">
    ${safe(
      location.place
    )}
  </strong>


  ${
    location.note
      ? `
        <span>
          ${safe(
            location.note
          )}
        </span>
      `
      : `
        <span class="muted">
          No location note
        </span>
      `
  }


  ${
    hasPin
      ? `
        <button
          type="button"
          class="text-link location-link"
          data-location="${bookingId}">
          View map
        </button>
      `
      : `
        <span class="muted">
          No pin provided
        </span>
      `
  }

</div>

`;

}

// ============================================================
// LOCATION MODAL
// ============================================================

function openLocationModal(id) {

const booking =
bookingsCache.find(
item =>
String(item.id) ===
String(id)
);

if (!booking) {

alert(
  'Booking not found.'
);

return;

}

const location =
parseEventLocation(
booking.eventPlace
);

if (
location.lat === null ||
location.lon === null
) {

alert(
  'This booking has no map pin.'
);

return;

}

locationModalTitle.textContent =
booking.bookingReference ||
'Booking Location';

locationPlaceText.textContent =
location.place;

locationPinText.textContent =
`${location.lat.toFixed(6)}, ${location.lon.toFixed(6)}`;

locationNoteText.textContent =
location.note ||
'No location note';

const mapUrl =
location.mapUrl ||
`https://www.google.com/maps?q=${location.lat},${location.lon}`;

locationMapLink.href =
mapUrl;

locationMapFrame.src =
`https://maps.google.com/maps?q=${location.lat},${location.lon}&z=17&output=embed`;

locationModal.classList.remove(
'hidden'
);

}

function closeLocationModal() {

locationModal.classList.add(
'hidden'
);

locationMapFrame.src = '';

}

// ============================================================
// EDIT BOOKING
// ============================================================

function openEditModal(id) {

const booking =
bookingsCache.find(
item =>
String(item.id) ===
String(id)
);

if (!booking) {

alert(
  'Booking not found.'
);

return;

}

editBookingId.value =
booking.id;

editEventType.value =
booking.eventType || '';

editEventDate.value =
booking.eventDate || '';

editEventTime.value =
booking.eventTime || '';

editEventPlace.value =
booking.eventPlace || '';

editNumberOfPax.value =
booking.numberOfPax || '';

editQuotedPrice.value =
booking.quotedPrice ??
'';


/*

* IMPORTANT:
*
* In the edit modal, downPaymentAmount
* means ACTUAL AMOUNT PAID.
*
* It is NOT the required downpayment.
  */

editDownPayment.value =
booking.downPaymentAmount ??
'';

editAdminNote.value = '';

detailCustomerName.textContent =
booking.customerName || '-';

detailCustomerEmail.textContent =
booking.email || '-';

detailCustomerPhone.textContent =
booking.phoneNumber || '-';

detailCustomerAddress.textContent =
booking.customerAddress || '-';

renderSelectedMenuItems(
booking
);

renderSelectedAddons(
booking
);

updateEditPriceDisplay();

editModal.classList.remove(
'hidden'
);

}

function closeEditModal() {

editModal.classList.add(
'hidden'
);

editForm.reset();

}

// ============================================================
// SELECTED MENU ITEMS
// ============================================================

function renderSelectedMenuItems(
booking
) {

const packageItems = booking.packageMenuItems || [];
const customItems = booking.customMenuItems || booking.menuItems || [];
const items = packageItems.length ? packageItems : customItems;
const packageTitle = booking.menuPackageName
  ? `<div class="empty-detail"><strong>Package:</strong> ${safe(booking.menuPackageName)}</div>`
  : '';

if (!items.length) {

selectedMenuItems.innerHTML =
  `${packageTitle || `
    <div class="empty-detail">
      No custom menu items selected.
    </div>
  `}`;

return;

}

selectedMenuItems.innerHTML =
`${packageTitle}${items.map(item => `

  <div class="selected-menu-item">

    ${
      item.imageUrl
        ? `
          <img
            src="${safe(
              assetUrl(item.imageUrl)
            )}"
            alt="${safe(
              item.name
            )}">
        `
        : ''
    }


    <div>

      <strong>
        ${safe(
          item.name
        )}
      </strong>


      ${
        item.categoryName
          ? `
            <span>
              ${safe(
                item.categoryName
              )}
              ${
                item.subCategoryName
                  ? ` • ${safe(
                      item.subCategoryName
                    )}`
                  : ''
              }
            </span>
          `
          : ''
      }

    </div>

  </div>

`).join('')}`;

}

// ============================================================
// ADD-ONS IN MODAL
// ============================================================

function renderSelectedAddons(
booking
) {

const addons = [];

if (booking.projector === true) {
addons.push('Projector');
}

if (booking.videoke === true) {
addons.push('Videoke');
}

if (booking.lechon === true) {
addons.push('Lechon');
}

if (booking.cake === true) {
addons.push('Cake');
}

if (!addons.length) {

selectedAddons.innerHTML =
  `
    <div class="empty-detail">
      No add-ons selected.
    </div>
  `;

return;

}

selectedAddons.innerHTML =
addons.map(addon => `

  <div class="addon-detail">
    <span>✓</span>
    <strong>
      ${safe(addon)}
    </strong>
  </div>

`).join('');

}

// ============================================================
// EDIT PRICE DISPLAY
// ============================================================

function updateEditPriceDisplay() {

const quoted =
Number(
editQuotedPrice.value
) || 0;

const actualPaid =
Number(
editDownPayment.value
) || 0;

const balance =
Math.max(
quoted - actualPaid,
0
);

quotedPriceDisplay.textContent =
peso(quoted);

downPaymentDisplay.textContent =
peso(actualPaid);

remainingBalanceDisplay.textContent =
peso(balance);

}

// ============================================================
// SAVE EDITED BOOKING
// ============================================================

async function updateEditedBooking(event) {
  event.preventDefault();
  if (isUpdating || !editForm.reportValidity()) return;
  const id = editBookingId.value;
  if (!findBooking(id, ['PENDING', 'CONFIRMED'])) return;
  const body = {
    eventType: editEventType.value.trim(),
    eventDate: editEventDate.value,
    eventTime: editEventTime.value,
    eventPlace: editEventPlace.value.trim(),
    numberOfPax: Number(editNumberOfPax.value),
    adminNote: editAdminNote.value.trim()
  };
  if (!body.eventType || !body.eventPlace || !Number.isInteger(body.numberOfPax) || body.numberOfPax < 1 || body.numberOfPax > 500) {
    alert('Enter an event type, location, and a whole number of guests from 1 to 500.');
    return;
  }
  await mutateBooking(id, '/api/admin/bookings/' + id, body, 'Booking details saved.', closeEditModal);
}

// ============================================================
// CONFIRM MODAL
// ============================================================

function openConfirmModal(id) {

const booking =
bookingsCache.find(
item =>
String(item.id) ===
String(id)
);

if (!booking) {

alert(
  'Booking not found.'
);

return;

}

confirmBookingId.value =
booking.id;

confirmBookingReference.textContent =
booking.bookingReference || '-';

confirmCustomerName.textContent =
booking.customerName || '-';

const emailNotice = document.getElementById('confirmEmailNotice');
if (emailNotice) {
  emailNotice.textContent = booking.email
    ? `Confirmation will be emailed to ${booking.email} after saving. A payment receipt is sent after payment is verified.`
    : 'This booking has no customer email. Check the customer details before confirming.';
}

/*

* Admin sets the final quoted price.
  */

confirmQuotedPrice.value =
booking.quotedPrice ??
booking.packagePrice ??
'';

/*

* This field is the REQUIRED DOWNPAYMENT.
*
* It is NOT money already paid.
  */

confirmDownPayment.value =
booking.requiredDownPayment ??
'';

updateConfirmPriceDisplay();

confirmBookingModal.classList.remove(
'hidden'
);

}

function closeConfirmModal() {

confirmBookingModal.classList.add(
'hidden'
);

confirmBookingForm.reset();

}

// ============================================================
// CONFIRM PRICE DISPLAY
// ============================================================

function updateConfirmPriceDisplay() {
    const quotedValue = confirmQuotedPrice?.value.trim() ?? "";
    const downPaymentValue = confirmDownPayment?.value.trim() ?? "";

    const quotedPrice = Number(quotedValue) || 0;
    const requiredDownPayment = Number(downPaymentValue) || 0;

    // Always display entered values
    confirmQuotedDisplay.textContent = peso(quotedPrice);
    confirmDownPaymentDisplay.textContent = peso(requiredDownPayment);

    // Do not calculate balance until BOTH fields have values
    if (quotedValue === "" || downPaymentValue === "") {
        confirmBalanceDisplay.textContent = peso(0);
        return;
    }

    const balance = Math.max(
        0,
        quotedPrice - requiredDownPayment
    );

    confirmBalanceDisplay.textContent = peso(balance);
}


// ============================================================
// CONFIRM BOOKING
// ============================================================

async function confirmBooking(event) {
  event.preventDefault();
  if (isUpdating || !confirmBookingForm.reportValidity()) return;
  const id = confirmBookingId.value;
  if (!findBooking(id, ['PENDING'])) return;
  const quotedPrice = Number(confirmQuotedPrice.value);
  const downPayment = Number(confirmDownPayment.value);
  if (!Number.isFinite(quotedPrice) || quotedPrice <= 0 || !Number.isFinite(downPayment) || downPayment < 0 || downPayment > quotedPrice) {
    alert('Enter a positive quoted price and a required downpayment between zero and the quoted price.');
    return;
  }
  const button = confirmBookingForm.querySelector('button[type="submit"]');
  const previousLabel = button?.textContent;
  if (button) button.textContent = 'Confirming...';
  try {
    await mutateBooking(id, '/api/admin/bookings/' + id + '/confirm', { quotedPrice, downPayment }, 'Booking confirmed.', closeConfirmModal);
  } finally {
    if (button) button.textContent = previousLabel;
  }
}

// ============================================================
// EDIT ACTUAL PAYMENT
// ============================================================

function openPaymentModal(id) {
  if (isUpdating) return;
  const booking = findBooking(id, ['CONFIRMED']);
  if (!booking) return;
  const form = document.getElementById('editPaymentForm');
  form.dataset.id = id;
  document.getElementById('editPaymentReference').textContent = booking.bookingReference;
  form.elements.totalPaid.value = booking.downPaymentAmount || 0;
  form.elements.paymentMethod.value = booking.paymentMethod || '';
  form.elements.totalPaid.max = booking.quotedPrice;
  previewPayment();
  document.getElementById('editPaymentModal').classList.remove('hidden');
}

function previewPayment() {
  const input = document.getElementById('editPaymentTotal');
  document.getElementById('editPaymentBalance').textContent = `Remaining balance: ${peso(Number(input.max) - Number(input.value))}`;
}
document.getElementById('editPaymentTotal').addEventListener('input', previewPayment);
document.getElementById('closeEditPayment').addEventListener('click', () => {
  document.getElementById('editPaymentModal').classList.add('hidden');
});
document.getElementById('editPaymentForm').addEventListener('submit', async event => {
  event.preventDefault();
  const form = event.currentTarget;
  if (isUpdating || !form.reportValidity()) return;
  await mutateBooking(form.dataset.id, `/api/admin/bookings/${form.dataset.id}/payment`,
    { downPaymentAmount: Number(form.elements.totalPaid.value), paymentMethod: form.elements.paymentMethod.value }, 'Payment updated.',
    () => document.getElementById('editPaymentModal').classList.add('hidden'));
});

const completeBookingDialog = document.getElementById('completeBookingDialog');
const cancelCompleteBooking = document.getElementById('cancelCompleteBooking');
const submitCompleteBooking = document.getElementById('submitCompleteBooking');
let completingBookingId = null;

cancelCompleteBooking.addEventListener('click', () => {
  if (!isUpdating) completeBookingDialog.close();
});
completeBookingDialog.addEventListener('cancel', event => {
  if (isUpdating) event.preventDefault();
});
completeBookingDialog.addEventListener('close', () => { completingBookingId = null; });
submitCompleteBooking.addEventListener('click', async () => {
  if (isUpdating || completingBookingId === null) return;
  const booking = findBooking(completingBookingId, ['CONFIRMED']);
  if (!booking || !canCompleteBooking(booking)) {
    completeBookingDialog.close();
    alert('Record and verify the remaining payment before completing this booking.');
    return;
  }
  cancelCompleteBooking.disabled = true;
  submitCompleteBooking.disabled = true;
  submitCompleteBooking.textContent = 'Completing...';
  try {
    await mutateBooking(completingBookingId, '/api/admin/bookings/' + completingBookingId + '/complete',
      undefined, 'Booking completed.', () => completeBookingDialog.close());
  } finally {
    cancelCompleteBooking.disabled = false;
    submitCompleteBooking.disabled = false;
    submitCompleteBooking.textContent = 'Yes, Complete';
  }
});

async function updateBooking(button, id, action) {
  if (isUpdating || button.disabled || action !== 'complete') return;
  const booking = findBooking(id, ['CONFIRMED']);
  if (!booking) return;
  if (!canCompleteBooking(booking)) {
    alert('Record and verify the remaining payment before completing this booking.');
    return;
  }
  if (completeBookingDialog.open) return;
  completingBookingId = id;
  completeBookingDialog.showModal();
}

async function cancelBooking(button, id) {
  if (isUpdating || button.disabled || !findBooking(id, ['PENDING', 'CONFIRMED'])) return;
  const reason = (await prompt('Reason for cancellation:'))?.trim();
  if (!reason) return;
  return mutateBooking(id, '/api/admin/bookings/' + id + '/cancel', { reason }, 'Booking cancelled.');
}

const archiveBookingDialog = document.getElementById('archiveBookingDialog');
const archiveBookingForm = document.getElementById('archiveBookingForm');
const archiveBookingReason = document.getElementById('archiveBookingReason');
const cancelArchiveBooking = document.getElementById('cancelArchiveBooking');
const submitArchiveBooking = document.getElementById('submitArchiveBooking');
const archiveBookingLabel = document.getElementById('archiveBookingLabel');
let archivingBookingId = null;

function updateArchiveButton() {
  submitArchiveBooking.disabled = isUpdating || !archiveBookingReason.value.trim();
}
archiveBookingReason.addEventListener('input', updateArchiveButton);
cancelArchiveBooking.addEventListener('click', () => {
  if (!isUpdating) archiveBookingDialog.close();
});
archiveBookingDialog.addEventListener('cancel', event => {
  if (isUpdating) event.preventDefault();
});
archiveBookingDialog.addEventListener('close', () => {
  archivingBookingId = null;
  archiveBookingForm.reset();
  updateArchiveButton();
});
archiveBookingForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (isUpdating || archivingBookingId === null) return;
  const reason = archiveBookingReason.value.trim();
  if (!reason || !archiveBookingForm.reportValidity()) {
    updateArchiveButton();
    archiveBookingReason.focus();
    return;
  }
  if (!findBooking(archivingBookingId, ['COMPLETED', 'CANCELLED'])) {
    archiveBookingDialog.close();
    return;
  }
  cancelArchiveBooking.disabled = true;
  submitArchiveBooking.disabled = true;
  archiveBookingReason.disabled = true;
  archiveBookingLabel.textContent = 'Archiving...';
  try {
    await mutateBooking(archivingBookingId, '/api/admin/archives/bookings/' + archivingBookingId,
      { reason }, 'Booking archived.', () => archiveBookingDialog.close());
  } finally {
    cancelArchiveBooking.disabled = false;
    archiveBookingReason.disabled = false;
    archiveBookingLabel.textContent = 'Archive Booking';
    updateArchiveButton();
  }
});

async function archiveBooking(button, id) {
  if (isUpdating || button.disabled || archiveBookingDialog.open || !findBooking(id, ['COMPLETED', 'CANCELLED'])) return;
  archivingBookingId = id;
  archiveBookingForm.reset();
  updateArchiveButton();
  archiveBookingDialog.showModal();
}
