import { clearToken } from './api.js';

const links = [
  { href: 'dashboard.html', label: 'Dashboard', icon: 'dashboard' },
  { href: 'bookings.html', label: 'Bookings', icon: 'bookings' },
  { href: 'payments.html', label: 'Payments', icon: 'payments' },
  { href: 'calendar.html', label: 'Calendar', icon: 'calendar' },
  { href: 'menu-items.html', label: 'Menu Items', icon: 'menuItems' },
  { href: 'menu-packages.html', label: 'Menu Packages', icon: 'packages' },
  { href: 'analytics.html', label: 'Analytics', icon: 'analytics' },
  { href: 'feedbacks.html', label: 'Feedbacks', icon: 'feedbacks' },
  { href: 'archives.html', label: 'Archives', icon: 'archives' },
  { href: 'audit-logs.html', label: 'Audit Logs', icon: 'bookings' }
];

const iconPaths = {
  dashboard: `
    <path d="M4 5.5A1.5 1.5 0 0 1 5.5 4h3A1.5 1.5 0 0 1 10 5.5v3A1.5 1.5 0 0 1 8.5 10h-3A1.5 1.5 0 0 1 4 8.5v-3Z" />
    <path d="M14 5.5A1.5 1.5 0 0 1 15.5 4h3A1.5 1.5 0 0 1 20 5.5v3A1.5 1.5 0 0 1 18.5 10h-3A1.5 1.5 0 0 1 14 8.5v-3Z" />
    <path d="M4 15.5A1.5 1.5 0 0 1 5.5 14h3a1.5 1.5 0 0 1 1.5 1.5v3A1.5 1.5 0 0 1 8.5 20h-3A1.5 1.5 0 0 1 4 18.5v-3Z" />
    <path d="M14 15.5A1.5 1.5 0 0 1 15.5 14h3a1.5 1.5 0 0 1 1.5 1.5v3a1.5 1.5 0 0 1-1.5 1.5h-3a1.5 1.5 0 0 1-1.5-1.5v-3Z" />`,
  bookings: `
    <path d="M7 4h10a2 2 0 0 1 2 2v14H5V6a2 2 0 0 1 2-2Z" />
    <path d="M8 8h8" />
    <path d="M8 12h8" />
    <path d="M8 16h5" />`,
  payments: `
    <path d="M4 7a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7Z" />
    <path d="M4 9h16" />
    <path d="M7 15h4" />`,
  calendar: `
    <path d="M7 3v4" />
    <path d="M17 3v4" />
    <path d="M5 6h14a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2Z" />
    <path d="M3 11h18" />
    <path d="M8 15h.01" />
    <path d="M12 15h.01" />
    <path d="M16 15h.01" />`,
  menuItems: `
    <path d="M6 4v16" />
    <path d="M10 4v16" />
    <path d="M6 10h4" />
    <path d="M17 4v7a3 3 0 0 1-3 3h0" />
    <path d="M17 14v6" />`,
  packages: `
    <path d="M4 8 12 4l8 4-8 4-8-4Z" />
    <path d="M4 8v8l8 4 8-4V8" />
    <path d="M12 12v8" />`,
  analytics: `
    <path d="M5 19V9" />
    <path d="M12 19V5" />
    <path d="M19 19v-7" />
    <path d="M3 19h18" />`,
  feedbacks: `
    <path d="M5 5h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H9l-4 4v-4H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z" />
    <path d="m8 11 2 2 5-5" />`,
  archives: `
    <path d="M4 7h16v13H4V7Z" />
    <path d="M6 4h12l2 3H4l2-3Z" />
    <path d="M9 12h6" />`
};

function icon(name) {
  return `
    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      ${iconPaths[name]}
    </svg>
  `;
}

export function initLayout() {
  const sidebar = document.querySelector('.sidebar');

  if (sidebar) {
    const current = window.location.pathname.split('/').pop();
    const isCollapsed = localStorage.getItem('sidebar_collapsed') === 'true';

    document.body.classList.toggle('sidebar-collapsed', isCollapsed);
    document.documentElement.classList.remove('sidebar-collapsed-pending');

    sidebar.innerHTML = `
      <div class="sidebar-brand">
        <a class="sidebar-logo-link" href="dashboard.html" aria-label="Go to dashboard" title="Go to dashboard">
          <img class="sidebar-logo" src="images/logo.jpg" alt="Saneth logo" />
        </a>

        <div class="brand-text">
          <div class="sidebar-title">Saneth</div>
          <div class="sidebar-subtitle">Admin Management</div>
        </div>

        <button class="sidebar-toggle" id="sidebarToggle" title="Toggle sidebar" aria-label="Toggle sidebar">
          <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
            <rect x="3.5" y="4.5" width="17" height="15" rx="3" />
            <path d="M9 5v14" />
            <path d="m16 9-3 3 3 3" />
          </svg>
        </button>
      </div>

      <nav class="nav-menu">
        ${links.map(link => `
          <a class="nav-link ${current === link.href ? 'active' : ''}" href="${link.href}" title="${link.label}">
            <span class="nav-icon">${icon(link.icon)}</span>
            <span class="nav-label">${link.label}</span>
          </a>
        `).join('')}
      </nav>
    `;

    const toggleBtn = document.getElementById('sidebarToggle');

    toggleBtn.addEventListener('click', () => {
      const collapsed = document.body.classList.toggle('sidebar-collapsed');
      document.documentElement.classList.remove('sidebar-collapsed-pending');
      localStorage.setItem('sidebar_collapsed', collapsed);
    });
  }

  const logoutBtn = document.getElementById('logoutBtn');

  if (logoutBtn) {
    let logoutDialog = document.getElementById('logoutConfirmation');

    if (!logoutDialog) {
      logoutDialog = document.createElement('dialog');
      logoutDialog.id = 'logoutConfirmation';
      logoutDialog.className = 'logout-confirmation';
      logoutDialog.setAttribute('aria-labelledby', 'logoutConfirmationTitle');
      logoutDialog.setAttribute('aria-describedby', 'logoutConfirmationMessage');
      logoutDialog.innerHTML = `
        <form method="dialog">
          <div class="logout-confirmation-header">
            <h2 id="logoutConfirmationTitle">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <path d="M9 4H5v16h4M10 12h10m-4-4 4 4-4 4" />
              </svg>
              Log Out?
            </h2>
            <button class="logout-confirmation-close" type="submit" value="cancel" aria-label="Close logout confirmation">&times;</button>
          </div>
          <p id="logoutConfirmationMessage">Are you sure you want to log out of your Saneth Catering account?</p>
          <div class="logout-confirmation-actions">
            <button class="logout-confirmation-cancel" type="submit" value="cancel" autofocus>Cancel</button>
            <button class="logout-confirmation-submit" type="submit" value="logout">Log Out</button>
          </div>
        </form>
      `;
      document.body.appendChild(logoutDialog);
      logoutDialog.addEventListener('close', () => {
        if (logoutDialog.returnValue === 'logout') {
          clearToken();
          window.location.href = 'index.html';
        }
      });
    }

    logoutBtn.addEventListener('click', () => {
      if (!logoutDialog.open) {
        logoutDialog.returnValue = '';
        logoutDialog.showModal();
      }
    });
  }
}
