const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

function page() {
  const dialogs = [];
  let focusRestored = 0;
  const document = {
    activeElement: { focus() { focusRestored++; } },
    body: { append(dialog) { dialogs.push(dialog); } },
    createElement() {
      const events = {};
      const nodes = new Map();
      return {
        setAttribute() {},
        querySelector(selector) {
          if (selector === 'textarea' && !this.innerHTML.includes('<textarea')) return null;
          if (selector === '[data-cancel]' && !this.innerHTML.includes('data-cancel')) return null;
          if (!nodes.has(selector)) nodes.set(selector, { value: '', focus() {}, addEventListener() {} });
          return nodes.get(selector);
        },
        addEventListener(type, callback) { events[type] = callback; },
        showModal() { this.open = true; },
        close(value = '') { this.returnValue = value; this.open = false; events.close?.(); },
        remove() { this.removed = true; }
      };
    }
  };
  const source = fs.readFileSync(path.join(__dirname, '../js/dialogs.js'), 'utf8').replace(/^export /gm, '');
  const api = vm.createContext({ document });
  vm.runInContext(source, api);
  return { api, dialogs, restored: () => focusRestored };
}

test('decisions await explicit acceptance, reject duplicate clicks and restore focus', async () => {
  const p = page();
  const first = p.api.showConfirm('<strong>Verify received funds?</strong>');
  assert.equal(await p.api.showConfirm('Duplicate'), false);
  assert.equal(p.dialogs.length, 1);
  assert.equal(p.dialogs[0].querySelector('p').textContent, '<strong>Verify received funds?</strong>');
  p.dialogs[0].close('cancel');
  assert.equal(await first, false);
  const accepted = p.api.showConfirm('Verify this payment?');
  await Promise.resolve(); await Promise.resolve();
  p.dialogs[1].close('accept');
  assert.equal(await accepted, true);
  assert.equal(p.restored(), 2);
});

test('cancelled reason dialogs resolve null and accepted reasons are trimmed', async () => {
  const p = page();
  const cancelled = p.api.showPrompt('Reason');
  await Promise.resolve();
  p.dialogs[0].close();
  assert.equal(await cancelled, null);
  const accepted = p.api.showPrompt('Reason');
  await Promise.resolve(); await Promise.resolve();
  p.dialogs[1].querySelector('textarea').value = '  Incorrect transaction reference  ';
  p.dialogs[1].close('accept');
  assert.equal(await accepted, 'Incorrect transaction reference');
});
