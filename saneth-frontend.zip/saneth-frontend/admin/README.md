# Saneth Catering admin frontend

All existing admin pages and assets are preserved here. Shared configuration, build/deployment instructions, and tests are documented in [the frontend README](../README.md).

Open `/admin/index.html` to sign in. The frontend and backend are now independent projects.
