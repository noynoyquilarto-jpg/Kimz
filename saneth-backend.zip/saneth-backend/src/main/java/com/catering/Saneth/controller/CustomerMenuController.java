package com.catering.Saneth.controller;

import com.catering.Saneth.dto.response.MenuItemResponse;
import com.catering.Saneth.service.MenuItemService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/menu-items")
@RequiredArgsConstructor
public class CustomerMenuController {

    private final MenuItemService menuItemService;

    @GetMapping
    public List<MenuItemResponse> getAllMenuItems() {
        return menuItemService.getAllMenu();
    }

    @GetMapping("/{id}")
    public MenuItemResponse getMenuItem(@PathVariable Long id) {
        return menuItemService.getMenuById(id);
    }
}