package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.MenuSubCategoryRequest;
import com.catering.Saneth.dto.response.MenuSubCategoryResponse;
import com.catering.Saneth.model.MenuCategory;
import com.catering.Saneth.model.MenuSubCategory;
import com.catering.Saneth.repository.MenuCategoryRepo;
import com.catering.Saneth.repository.MenuSubCategoryRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MenuSubCategoryService {

    private final MenuSubCategoryRepo repo;
    private final MenuCategoryRepo categoryRepo;

    public MenuSubCategoryResponse create(MenuSubCategoryRequest request){

        MenuCategory category = categoryRepo.findById(request.getCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found."));

        MenuSubCategory subCategory = MenuSubCategory.builder()
                .name(request.getName())
                .category(category)
                .build();

        return map(repo.save(subCategory));
    }

    public List<MenuSubCategoryResponse> getAll(){

        return repo.findAll()
                .stream()
                .map(this::map)
                .toList();
    }

    private MenuSubCategoryResponse map(MenuSubCategory sub){

        return MenuSubCategoryResponse.builder()
                .id(sub.getId())
                .name(sub.getName())
                .categoryId(sub.getCategory().getId())
                .categoryName(sub.getCategory().getName())
                .build();
    }

}