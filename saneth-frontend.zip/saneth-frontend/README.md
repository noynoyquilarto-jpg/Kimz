# Saneth Catering frontend

Independent HTML/CSS/JavaScript customer and admin application. The original homepage, sign-in, registration, OTP steps, booking forms, package recommendations, tracking, payment screens, analytics, feedback, archive, audit logs, and responsive styles are retained.

All existing customer pages are in `customer/`; all existing admin pages are in `admin/`. Root `index.html` displays the customer homepage. Shared code is in `js/` and `css/`; original images remain beside their pages. Backend code and server secrets do not belong in this repository.

## Local use

Install Node.js 22 or newer and npm. No third-party frontend packages are required.

```powershell
npm ci
Copy-Item .env.example .env
```

Edit `.env` and set `SANETH_API_BASE_URL` to your local backend, for example `http://localhost:8080` or `http://localhost:18080`. Then run:

```powershell
npm test
npm run build
npm run dev
```

Open `http://localhost:5500/` and `http://localhost:5500/admin/index.html`. The development server serves only the generated `dist/` directory. Use HTTP rather than opening HTML with `file://`, which cannot reliably load JavaScript modules or make API requests.

For VS Code Live Server, serve this repository as the root. Unbuilt source uses `js/runtime-config.js` and the shared resolver: localhost and private network addresses default to the same hostname on port 8080. Set `window.SANETH_CONFIG.apiBaseUrl` in that public configuration file for a different port, or use `npm run dev` and `.env`. Add the exact Live Server origin to the backend's `SANETH_ALLOWED_ORIGINS` if it uses a different port or a phone/LAN hostname.

## Deploy on Vercel

1. Upload this folder to its own `saneth-frontend` GitHub repository.
2. Import that repository into Vercel. Choose framework **Other**, root directory `.`, Node.js 22 or newer, build command `npm run build`, and output directory `dist`.
3. Add `SANETH_API_BASE_URL=https://YOUR_BACKEND_HOST` to the Production environment and any Preview environments you will use. This public value is the backend origin, optionally ending in `/api`; do not include credentials or query parameters.
4. Deploy. `vercel.json` supplies the build/output settings, security headers, and redirects for the old frontend folder names.
5. Set backend `SANETH_ALLOWED_ORIGINS` to the exact Vercel/custom frontend origins, separated by commas. Set backend `SANETH_TRACKING_URL` to `https://YOUR_FRONTEND_HOST/customer/track-booking.html`.
6. Redeploy after changing environment values. Verify customer and admin flows using a test account.

Vercel builds generate `dist/js/runtime-config.js` from **only** `SANETH_API_BASE_URL`. Missing production configuration or an HTTP backend fails the build. Browser code cannot read server environment variables directly; generation makes this public setting available to both existing API helpers. No database, JWT, queue encryption, admin, or Gmail secrets are copied into the frontend output.

The shared configuration prevents duplicate `/api` prefixes and resolves backend upload paths against the configured backend. Both frontend API helpers retain their existing exports and callers. Local alerts, confirmations, and reason prompts use accessible styled dialogs; cancellation and duplicate-click protection remain in place.

## Verification and deployment requirements

`npm test` runs the preserved customer/admin regression checks plus deployment-configuration and dialog checks. `npm run check` checks every HTML page's local assets, JavaScript imports/syntax, CSS assets, and viewport metadata. `npm run build` also performs these checks.

A real HTTPS backend, allowed CORS origins, configured Gmail delivery, and a compatible MySQL database are required for the complete live workflow. Automated tests use fixtures and isolated backend tests; browser visual/device checks and live email delivery must be completed after deployment. An exact end-to-end checklist is in the release `DEPLOYMENT.md`.

Frontend build/configuration details follow [Vercel's project configuration documentation](https://vercel.com/docs/project-configuration/vercel-json) and [environment-variable documentation](https://vercel.com/docs/environment-variables).
