package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.FeedbackRequest;
import com.catering.Saneth.dto.response.FeedbackResponse;
import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.Feedback;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.repository.BookingRepo;
import com.catering.Saneth.repository.FeedbackRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@org.springframework.transaction.annotation.Transactional
@RequiredArgsConstructor
public class FeedbackService {
    private final FeedbackRepo feedbackRepo;
    private final BookingRepo bookingRepo;

    public FeedbackResponse submitFeedback(FeedbackRequest request) {
        Booking booking = bookingRepo.findByBookingReferenceAndEmail(
                        request.getBookingReference(),
                        request.getEmail()
                )
                .orElseThrow(() -> new RuntimeException("Booking not found"));

        if (booking.getBookingStatus() != BookingStatus.COMPLETED) {
            throw new RuntimeException("Feedback can only be submitted after the booking is completed.");
        }

        if (feedbackRepo.existsByBookingId(booking.getId())) {
            throw new RuntimeException("Feedback has already been submitted for this booking.");
        }

        Feedback feedback = Feedback.builder()
                .booking(booking)
                .menuPackage(booking.getMenuPackage())
                .customerName(booking.getCustomerName())
                .email(booking.getEmail())
                .rating(request.getRating())
                .comment(request.getComment())
                .build();

        Feedback savedFeedback = feedbackRepo.save(feedback);

        return mapToResponse(savedFeedback);
    }

    public List<FeedbackResponse> getAllFeedback() {
        return feedbackRepo.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public FeedbackResponse getFeedbackById(Long id) {
        Feedback feedback = feedbackRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Feedback not found"));

        return mapToResponse(feedback);
    }



    private FeedbackResponse mapToResponse(Feedback feedback){
        return FeedbackResponse.builder()
                .id(feedback.getId())
                .bookingReference(feedback.getBooking().getBookingReference())
                .customerName(feedback.getCustomerName())
                .email(feedback.getEmail())
                .menuPackageId(feedback.getMenuPackage() == null ? null : feedback.getMenuPackage().getId())
                .menuPackageName(feedback.getMenuPackage() == null ? null : feedback.getMenuPackage().getName())
                .rating(feedback.getRating())
                .comment(feedback.getComment())
                .createdAt(feedback.getCreatedAt())
                .build();
    }



}
