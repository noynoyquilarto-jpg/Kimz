package com.catering.Saneth.controller;

import com.catering.Saneth.dto.request.AdminLoginRequest;
import com.catering.Saneth.dto.response.AdminLoginResponse;
import com.catering.Saneth.dto.response.AdminResponse;
import com.catering.Saneth.security.JwtService;
import com.catering.Saneth.service.AdminAuthService;
import com.catering.Saneth.service.RateLimitService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/admin/auth")
@RequiredArgsConstructor
public class AdminAuthController {

    private final AdminAuthService adminAuthService;
    private final JwtService jwtService;
    private final RateLimitService rateLimitService;
    private final com.catering.Saneth.service.AdminAuditLogService auditLogService;

    @PostMapping("/login")
    public AdminLoginResponse login(@Valid @RequestBody AdminLoginRequest request, HttpServletRequest httpRequest) {
        rateLimitService.check(httpRequest, "admin-login", 6, java.time.Duration.ofMinutes(10));
        rateLimitService.checkKey("admin-login:email:" + request.getEmail(), 6, java.time.Duration.ofMinutes(15));
        AdminLoginResponse response = adminAuthService.login(request);
        auditLogService.recordForActor(jwtService.extractEmail(response.getToken()), "ADMIN_LOGIN", "ADMIN", null,
                "Successful admin sign in");
        return response;
    }

    @GetMapping("/me")
    public AdminResponse getProfile(@RequestHeader("Authorization") String authorizationHeader) {
        String token = authorizationHeader.substring(7);
        String email = jwtService.extractEmail(token);

        return adminAuthService.getAdminProfile(email);
    }
}
