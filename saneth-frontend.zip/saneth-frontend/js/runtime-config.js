window.SANETH_CONFIG = Object.freeze({ apiBaseUrl: '' });
