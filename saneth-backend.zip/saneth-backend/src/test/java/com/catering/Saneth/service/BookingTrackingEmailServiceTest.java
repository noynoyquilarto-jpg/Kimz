package com.catering.Saneth.service;
import com.catering.Saneth.model.Booking;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class BookingTrackingEmailServiceTest {
    @Test void manualRequestDoesNotClaimQueuedMailWasSent() {
        var email = mock(EmailService.class); var queue = mock(NotificationQueue.class);
        var service = new BookingTrackingEmailService(email, queue);
        var booking = Booking.builder().id(5L).build();
        assertThat(service.resendConfirmation(booking, List.of())).isFalse();
        when(queue.accepted("CONFIRMATION:5")).thenReturn(true);
        assertThat(service.resendConfirmation(booking, List.of())).isTrue();
        verify(email, times(2)).retryBookingConfirmationEmail(booking, List.of());
    }
    @Test void invalidQuoteCannotQueueConfirmation() {
        var email = mock(EmailService.class);
        var service = new BookingTrackingEmailService(email, mock(NotificationQueue.class));
        assertThatThrownBy(() -> service.sendAfterBookingConfirmed(new Booking(), null, 0)).isInstanceOf(IllegalArgumentException.class);
        verifyNoInteractions(email);
    }
}
