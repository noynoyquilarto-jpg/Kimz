-- Existing archives have no reliable prior status; leave unknown history NULL.
ALTER TABLE bookings ADD COLUMN status_before_archive VARCHAR(32) NULL;
