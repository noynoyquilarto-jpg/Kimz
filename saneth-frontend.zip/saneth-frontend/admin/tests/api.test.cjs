const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../js/api.js'), 'utf8')
  .replace(/^import[^\n]+\n/gm, '').replace(/^export /gm, '');

function setup(status, data) {
  const storage = new Map([['saneth_admin_token', 'saved-token'], ['saneth_admin_role', 'ADMIN']]);
  const calls = [];
  const context = vm.createContext({
    window: { location: { hostname: '127.0.0.1', href: 'bookings.html' } },
    localStorage: {
      getItem: key => storage.get(key) ?? null,
      setItem: (key, value) => storage.set(key, value),
      removeItem: key => storage.delete(key)
    },
    FormData, API_ORIGIN: 'http://127.0.0.1:8080',
    fetch: async (url, options) => {
      calls.push({ url, options });
      return { status, ok: status >= 200 && status < 300, text: async () => JSON.stringify(data) };
    }
  });
  vm.runInContext(source, context);
  return { context, storage, calls };
}

async function run() {
  for (const status of [401, 403, 500]) {
    const { context, storage, calls } = setup(status, { message: 'Authentication failed' });
    await assert.rejects(context.apiRequest('/api/admin/bookings/1/confirm', {
      method: 'PUT', body: JSON.stringify({ quotedPrice: 30000, downPayment: 10000 })
    }), /Please log in again/);
    assert.equal(calls[0].options.headers.Authorization, 'Bearer saved-token');
    assert.equal(calls.length, 1, 'Never automatically replay a booking mutation');
    assert.equal(storage.has('saneth_admin_token'), false);
    assert.equal(storage.has('saneth_admin_role'), false);
    assert.equal(context.window.location.href, 'index.html');
  }
  const forbidden = setup(403, { message: 'Access denied' });
  await assert.rejects(forbidden.context.apiRequest('/api/admin/bookings'), /not allowed/);
  assert.equal(forbidden.storage.get('saneth_admin_token'), 'saved-token');
  assert.equal(forbidden.context.window.location.href, 'bookings.html');

  const login = setup(401, { message: 'Authentication failed' });
  login.context.window.location.href = 'index.html';
  await assert.rejects(login.context.apiRequest('/api/admin/auth/login', { method: 'POST' }), /Invalid email or password/);
  assert.equal(login.calls[0].options.headers.Authorization, undefined);

  for (const token of [undefined, null, '', 'undefined', 'null', '   ']) {
    assert.throws(() => login.context.setToken(token), /valid session/);
    assert.equal(login.context.getToken(), null);
  }
  login.context.setToken(' new-token ');
  assert.equal(login.context.getToken(), 'new-token');

  const success = setup(200, { id: 1, bookingStatus: 'CONFIRMED' });
  const result = await success.context.apiRequest('/api/admin/bookings/1/confirm', { method: 'PUT' });
  assert.equal(result.bookingStatus, 'CONFIRMED');
  assert.equal(success.context.window.location.href, 'bookings.html');
  console.log('PASS: authentication recovery, login failures, token validation, permissions, and successful requests.');
}

run().catch(error => { console.error(error); process.exitCode = 1; });
