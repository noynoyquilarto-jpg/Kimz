import { apiRequest, requireAuth, peso, badge, safe } from './api.js';
import { initLayout } from './layout.js';

requireAuth();
initLayout();

const table = document.getElementById('archivesTable');
const refreshBtn = document.getElementById('refreshBtn');
let busy = false;
const message = document.getElementById('archiveMessage');
let archivedBookings = [];
const selectedIds = new Set();
const selectAll = document.getElementById('selectAllArchives');
const deleteSelectedBtn = document.getElementById('deleteSelectedBtn');
const deleteBookingDialog = document.getElementById('deleteBookingDialog');
const deleteBookingForm = document.getElementById('deleteBookingForm');
const deleteBookingConfirmation = document.getElementById('deleteBookingConfirmation');
const cancelDeleteBooking = document.getElementById('cancelDeleteBooking');
const submitDeleteBooking = document.getElementById('submitDeleteBooking');
const deleteBookingError = document.getElementById('deleteBookingError');
let pendingDeleteIds = [];

function describePendingDeletion() {
  const description = document.getElementById('deleteBookingDescription');
  if (pendingDeleteIds.length === 1) {
    const booking = archivedBookings.find(item => String(item.id) === pendingDeleteIds[0]);
    description.innerHTML = `Are you sure you want to permanently delete booking <strong>${safe(booking?.bookingReference || pendingDeleteIds[0])}</strong>?`;
  } else {
    description.textContent = `Are you sure you want to permanently delete ${pendingDeleteIds.length} selected bookings?`;
  }
}

function openDeleteBookingDialog(ids) {
  if (busy || deleteBookingDialog.open) return;
  const validIds = new Set(archivedBookings.map(booking => String(booking.id)));
  pendingDeleteIds = [...new Set(ids.map(String))].filter(id => validIds.has(id));
  if (!pendingDeleteIds.length) return;
  deleteBookingConfirmation.value = '';
  submitDeleteBooking.disabled = true;
  deleteBookingError.hidden = true;
  deleteBookingError.textContent = '';
  describePendingDeletion();
  deleteBookingDialog.showModal();
}

deleteBookingConfirmation.addEventListener('input', () => {
  submitDeleteBooking.disabled = busy || deleteBookingConfirmation.value !== 'DELETE';
});
cancelDeleteBooking.addEventListener('click', () => {
  if (!busy) deleteBookingDialog.close();
});
deleteBookingDialog.addEventListener('cancel', event => {
  if (busy) event.preventDefault();
});
deleteBookingDialog.addEventListener('close', () => {
  pendingDeleteIds = [];
  deleteBookingConfirmation.value = '';
  submitDeleteBooking.disabled = true;
});
deleteBookingForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (busy || !pendingDeleteIds.length || deleteBookingConfirmation.value !== 'DELETE') return;
  cancelDeleteBooking.disabled = true;
  submitDeleteBooking.disabled = true;
  deleteBookingConfirmation.disabled = true;
  const label = document.getElementById('deleteBookingLabel');
  label.textContent = 'Deleting...';
  deleteBookingError.hidden = true;
  try {
    await deleteArchives([...pendingDeleteIds]);
    pendingDeleteIds = pendingDeleteIds.filter(id => archivedBookings.some(booking => String(booking.id) === id));
    if (!pendingDeleteIds.length) deleteBookingDialog.close();
    else {
      describePendingDeletion();
      deleteBookingError.textContent = message.textContent;
      deleteBookingError.hidden = false;
      deleteBookingConfirmation.value = '';
    }
  } finally {
    cancelDeleteBooking.disabled = false;
    deleteBookingConfirmation.disabled = false;
    submitDeleteBooking.disabled = deleteBookingConfirmation.value !== 'DELETE';
    label.textContent = 'Delete Permanently';
    if (deleteBookingDialog.open) deleteBookingConfirmation.focus();
  }
});

function syncSelection() {
  const validIds = new Set(archivedBookings.map(booking => String(booking.id)));
  selectedIds.forEach(id => { if (!validIds.has(id)) selectedIds.delete(id); });
  selectAll.checked = archivedBookings.length > 0 && selectedIds.size === archivedBookings.length;
  selectAll.indeterminate = selectedIds.size > 0 && selectedIds.size < archivedBookings.length;
  selectAll.disabled = busy || !archivedBookings.length;
  deleteSelectedBtn.disabled = busy || !selectedIds.size;
  refreshBtn.disabled = busy;
  table.querySelectorAll('button, input').forEach(control => { control.disabled = busy; });
  table.querySelectorAll('[data-archive-select]').forEach(input => {
    input.checked = selectedIds.has(input.dataset.archiveSelect);
  });
}

selectAll.addEventListener('change', () => {
  if (busy) return;
  archivedBookings.forEach(booking => {
    if (selectAll.checked) selectedIds.add(String(booking.id));
    else selectedIds.delete(String(booking.id));
  });
  syncSelection();
});
table.addEventListener('change', event => {
  const input = event.target.closest('[data-archive-select]');
  if (!input || busy) return;
  if (input.checked) selectedIds.add(input.dataset.archiveSelect);
  else selectedIds.delete(input.dataset.archiveSelect);
  syncSelection();
});
deleteSelectedBtn.addEventListener('click', async () => {
  if (busy || !selectedIds.size) return;
  const ids = [...selectedIds];
  openDeleteBookingDialog(ids);
});
table.addEventListener('click', async event => {
  const button = event.target.closest('button[data-action]');
  if (!button || busy) return;
  const booking = archivedBookings.find(item => String(item.id) === button.dataset.id);
  if (!booking) return;
  openDeleteBookingDialog([String(booking.id)]);
});

async function deleteArchives(ids) {
  if (busy) return;
  busy = true;
  syncSelection();
  message.textContent = 'Deleting selected bookings...';
  let deleted = 0;
  const failures = [];
  try {
    for (const id of ids) {
      try {
        await apiRequest(`/api/admin/archives/bookings/${encodeURIComponent(id)}`, { method: 'DELETE' });
        archivedBookings = archivedBookings.filter(booking => String(booking.id) !== String(id));
        selectedIds.delete(String(id));
        deleted += 1;
      } catch (error) {
        const booking = archivedBookings.find(item => String(item.id) === String(id));
        failures.push(`${booking?.bookingReference || id}: ${error.message}`);
      }
    }
    renderArchives(archivedBookings);
    message.textContent = `${deleted} booking(s) permanently deleted.${failures.length ? ' Could not delete: ' + failures.join('; ') : ''}`;
  } finally {
    busy = false;
    syncSelection();
  }
}

refreshBtn.addEventListener('click', loadArchives);
loadArchives();

async function loadArchives() {
  if (busy || deleteBookingDialog.open) return;
  busy = true;
  syncSelection();
  refreshBtn.disabled = true;
  table.innerHTML = '<tr><td colspan="7">Loading archives...</td></tr>';
  try {
    const bookings = await apiRequest('/api/admin/archives/bookings');
    if (!Array.isArray(bookings)) throw new Error('Invalid archive response. Please refresh.');
    archivedBookings = bookings;
    renderArchives(bookings);
  } catch (error) {
    archivedBookings = [];
    selectedIds.clear();
    table.innerHTML = `<tr><td colspan="7">${safe(error.message)}</td></tr>`;
  } finally {
    busy = false;
    refreshBtn.disabled = false;
    syncSelection();
  }
}

function renderArchives(bookings) {
  syncSelection();
  if (!bookings.length) {
    table.innerHTML = '<tr><td colspan="7">No archived bookings found.</td></tr>';
    return;
  }

  const sortedBookings = [...bookings].sort((a, b) =>
    String(b.eventDate || '').localeCompare(String(a.eventDate || ''))
  );
  table.innerHTML = sortedBookings.map(booking => `
    <tr>
      <td><strong>${safe(booking.bookingReference)}</strong></td>
      <td>${safe(booking.customerName)}</td>
      <td>${safe(booking.eventDate)}</td>
      <td>${safe(booking.menuPackageName)}<br><span class="muted">${peso(booking.packagePrice)}</span></td>
      <td>${badge(booking.bookingStatus)}</td>
      <td>${badge(booking.paymentStatus)}</td>
      <td><div class="actions">
        <label class="record-row-select"><input type="checkbox" data-archive-select="${safe(booking.id)}" aria-label="Select ${safe(booking.bookingReference)} for deletion" ${selectedIds.has(String(booking.id)) ? 'checked' : ''} ${busy ? 'disabled' : ''}></label>
        <button type="button" class="btn btn-danger btn-small" data-action="delete" data-id="${safe(booking.id)}">Delete</button>
      </div></td>
    </tr>
  `).join('');
  syncSelection();
}
