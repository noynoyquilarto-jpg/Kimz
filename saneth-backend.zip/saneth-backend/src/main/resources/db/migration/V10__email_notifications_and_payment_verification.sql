CREATE TABLE IF NOT EXISTS email_notifications (
    id VARCHAR(36) PRIMARY KEY,
    event_key VARCHAR(180) NOT NULL UNIQUE,
    kind VARCHAR(30) NOT NULL,
    booking_id BIGINT NULL,
    customer_id BIGINT NULL,
    status VARCHAR(30) NOT NULL,
    encrypted_content MEDIUMTEXT NULL,
    attempts INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP(6) NOT NULL,
    next_attempt_at TIMESTAMP(6) NOT NULL,
    expires_at TIMESTAMP(6) NULL,
    accepted_at TIMESTAMP(6) NULL,
    lease_token VARCHAR(36) NULL,
    last_error VARCHAR(80) NULL,
    INDEX idx_email_due (status, next_attempt_at),
    INDEX idx_email_booking (booking_id),
    INDEX idx_email_customer (customer_id)
);
ALTER TABLE booking_payments ADD COLUMN verification_status VARCHAR(30) NOT NULL DEFAULT 'VERIFIED';
ALTER TABLE booking_payments ADD COLUMN verified_at DATETIME(6) NULL;
ALTER TABLE booking_payments ADD COLUMN submission_key VARCHAR(36) NULL;
UPDATE booking_payments SET verified_at = created_at WHERE verification_status = 'VERIFIED';
CREATE UNIQUE INDEX uq_payment_submission ON booking_payments (booking_id, submission_key);
