package com.catering.Saneth.dto.response;

import com.catering.Saneth.model.enums.PaymentMethod;
import com.catering.Saneth.model.enums.PaymentStatus;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Builder
public class PaymentResponse {
    private java.util.List<com.catering.Saneth.service.NotificationQueue.Status> emailNotifications;

    private Long bookingId;
    private String bookingReference;

    private String customerName;
    private String email;
    private String phoneNumber;

    private Double packagePrice;
    private Double downPaymentAmount;
    private Double totalPaid;
    private Double remainingBalance;

    private PaymentMethod paymentMethod;
    private String paymentReferenceNumber;
    private String paymentNote;
    private PaymentStatus paymentStatus;

    private String rejectionReason;
    private List<PaymentRecordResponse> payments;
}
