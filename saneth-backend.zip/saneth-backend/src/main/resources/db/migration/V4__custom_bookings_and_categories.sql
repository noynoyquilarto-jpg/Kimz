CREATE TABLE IF NOT EXISTS menu_categories (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE
);
CREATE TABLE IF NOT EXISTS menu_subcategories (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category_id BIGINT NOT NULL,
    CONSTRAINT fk_subcategory_category FOREIGN KEY (category_id) REFERENCES menu_categories(id)
);

-- Supports both the original schema and installations already updated by Hibernate.
DELIMITER //
CREATE PROCEDURE saneth_add_column(IN table_name_arg VARCHAR(64), IN column_name_arg VARCHAR(64), IN definition_arg VARCHAR(255))
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
        WHERE table_schema = DATABASE() AND table_name = table_name_arg AND column_name = column_name_arg) THEN
        SET @ddl = CONCAT('ALTER TABLE `', table_name_arg, '` ADD COLUMN `', column_name_arg, '` ', definition_arg);
        PREPARE migration_stmt FROM @ddl;
        EXECUTE migration_stmt;
        DEALLOCATE PREPARE migration_stmt;
    END IF;
END //
DELIMITER ;

CALL saneth_add_column('menu_items', 'category_id', 'BIGINT NULL');
CALL saneth_add_column('menu_items', 'subcategory_id', 'BIGINT NULL');
CALL saneth_add_column('bookings', 'booking_type', "VARCHAR(255) NOT NULL DEFAULT 'PACKAGE'");
CALL saneth_add_column('bookings', 'quoted_price', 'DECIMAL(38,2) NULL');
CALL saneth_add_column('bookings', 'down_payment', 'DECIMAL(38,2) NULL');
CALL saneth_add_column('bookings', 'projector', 'BIT DEFAULT 0');
CALL saneth_add_column('bookings', 'videoke', 'BIT DEFAULT 0');
CALL saneth_add_column('bookings', 'lechon', 'BIT DEFAULT 0');
CALL saneth_add_column('bookings', 'cake', 'BIT DEFAULT 0');
CALL saneth_add_column('bookings', 'special_request', 'VARCHAR(500) NULL');
DROP PROCEDURE saneth_add_column;

INSERT INTO menu_categories(name) SELECT 'Other' WHERE NOT EXISTS (SELECT 1 FROM menu_categories WHERE name = 'Other');
UPDATE menu_items SET category_id = (SELECT id FROM menu_categories WHERE name = 'Other') WHERE category_id IS NULL;
ALTER TABLE menu_items MODIFY category_id BIGINT NOT NULL;
ALTER TABLE bookings MODIFY menu_package_id BIGINT NULL;
ALTER TABLE bookings MODIFY event_place VARCHAR(1000) NOT NULL;

CREATE TABLE IF NOT EXISTS booking_menu_items (
    id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    booking_id BIGINT NOT NULL,
    menu_item_id BIGINT NOT NULL,
    CONSTRAINT fk_custom_booking FOREIGN KEY (booking_id) REFERENCES bookings(id),
    CONSTRAINT fk_custom_item FOREIGN KEY (menu_item_id) REFERENCES menu_items(id)
);

-- Reconcile the cached amount with the payment ledger used by the Payments page.
UPDATE bookings b SET down_payment_amount = (
    SELECT COALESCE(SUM(p.amount), 0) FROM booking_payments p WHERE p.booking_id = b.id
) WHERE EXISTS (SELECT 1 FROM booking_payments p WHERE p.booking_id = b.id);
