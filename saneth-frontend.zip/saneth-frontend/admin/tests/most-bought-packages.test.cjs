// Run with: node saneth-admin-frontend/tests/most-bought-packages.test.cjs
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const source = fs.readFileSync(path.join(__dirname, '../js/most-bought-packages.js'), 'utf8')
  .replace(/^import .*;$/gm, '').replace(/export /g, '');
const context = vm.createContext({ safe: value => String(value) });
vm.runInContext(source, context);

for (const field of ['totalBookings', 'totalBought', 'count']) {
  for (const count of [0, 1, 12, '7']) {
    const ranked = context.rankPackages([{ packageName: 'Package A', [field]: count }]);
    assert.equal(ranked[0].totalBookings, Number(count));
    assert.match(context.renderPackageRanking(ranked), new RegExp(`${count} booking`));
    assert.match(context.renderPackageRanking(ranked, true), new RegExp(`<td>${count}</td>`));
  }
}
assert.equal(context.rankPackages([{ totalBookings: 0, totalBought: 9 }])[0].totalBookings, 0);
assert.equal(context.rankPackages([{ totalBookings: null, totalBought: 3 }])[0].totalBookings, 3);
const mixed = context.rankPackages([
  { packageName: 'A', totalBought: 2 },
  { packageName: 'B', totalBookings: 7 },
  { packageName: 'C', count: 4 }
]);
assert.equal(mixed.map(item => item.packageName).join(','), 'B,C,A');
for (const item of [{}, { count: -1 }, { count: 'invalid' }, { count: '' }]) {
  assert.throws(() => context.rankPackages([item]));
}
console.log('PASS: all supported count fields, numeric strings, zero preservation, mixed ranking, both views, and malformed counts.');
