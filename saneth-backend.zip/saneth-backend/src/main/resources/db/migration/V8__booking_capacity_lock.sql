CREATE TABLE IF NOT EXISTS booking_capacity_lock (id INTEGER PRIMARY KEY);
INSERT INTO booking_capacity_lock (id) SELECT 1 WHERE NOT EXISTS (SELECT 1 FROM booking_capacity_lock WHERE id = 1);
