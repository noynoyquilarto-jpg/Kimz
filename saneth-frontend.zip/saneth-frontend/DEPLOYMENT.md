# Upload and deploy Saneth Catering

These instructions use two new repositories, Vercel for the frontend, and a Docker-compatible Java host for the backend. Production URLs and secrets must be supplied by the owner. No remote repository, hosting account, or live database was changed during source preparation.

## 1. Create two GitHub repositories

Sign in to GitHub and create empty repositories named `saneth-frontend` and `saneth-backend`. Choose your visibility. Leave automatic README, license, and `.gitignore` creation unchecked because the projects already contain their own files. Authenticate Git with your account when prompted; do not place access tokens in commands or remote URLs.

Open PowerShell in this `Saneth-Catering` folder. Replace `YOUR-USERNAME` with the repository owner. Run each block inside its intended project; do not upload the original combined workspace, backups, or verification cache.

```powershell
Set-Location .\saneth-frontend
git init -b main
git add .
git diff --cached --stat
git status --short
git commit -m "Prepare independent Saneth Catering frontend"
git remote add origin https://github.com/YOUR-USERNAME/saneth-frontend.git
git push -u origin main
Set-Location ..
```

```powershell
Set-Location .\saneth-backend
git init -b main
git add .
git diff --cached --stat
git status --short
git commit -m "Prepare independent Saneth Catering backend"
git remote add origin https://github.com/YOUR-USERNAME/saneth-backend.git
git push -u origin main
Set-Location ..
```

Before committing, confirm `.env`, `.saneth-local.properties`, database exports, logs, upload contents, `target/`, and `dist/` are absent from the staged list. The projects' ignore rules already exclude them. If working in an already initialized extracted copy, skip initialization and add the remote only if it does not exist. Follow [GitHub's instructions for importing local source](https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github?platform=windows).

## 2. Prepare production MySQL without losing records

Back up the existing MySQL database and restore it into staging first. Keep `flyway_schema_history`, existing primary keys, relationships, user records, payments, and bookings. Copy uploads separately. Use a dedicated database user and a provider-supplied TLS JDBC URL; keep its password only in backend environment settings.

The backend README explains schema validation and legacy V5. Start with migrations disabled and schema validation enabled. If startup reports a schema mismatch or migration-history mismatch, resolve it on the restored copy before cutover. This release did not run MySQL migrations against your existing records. Never import an empty demo database over your existing system.

## 3. Deploy the Java backend (Render example)

1. In Render choose **New > Web Service**, connect GitHub, and select `saneth-backend`.
2. Choose **Docker** as the language/runtime, repository root `.`, and Dockerfile `./Dockerfile`. The Dockerfile runs the Maven verification build and starts Java 21. [Render documents Docker-based Java deployments](https://render.com/docs/docker).
3. Choose a service plan that supports outbound Gmail SMTP and persistent disk storage. Render's free web services block SMTP ports including 587; [its SMTP restriction notice](https://render.com/changelog/free-web-services-will-no-longer-allow-outbound-traffic-to-smtp-ports) explains the paid-service requirement. Choose the plan yourself before creating a billed service.
4. Add all backend environment values from `saneth-backend/.env.example`, using your real MySQL settings, unique secrets, admin seed details, and Gmail account/App Password. Set `SPRING_PROFILES_ACTIVE=prod`. Let the host provide `PORT`, or use its required port. Do not put passwords into the repository or frontend settings.
5. Set `SANETH_ALLOWED_ORIGINS` to the intended frontend origin, for example `https://YOUR_FRONTEND.vercel.app`. Set `SANETH_TRACKING_URL=https://YOUR_FRONTEND.vercel.app/customer/track-booking.html`. Update these if the final URL differs.
6. Attach a persistent disk at `/var/saneth/uploads` and set `SANETH_UPLOAD_DIR` to that path. Ensure the Docker user can write there and copy the existing image files into its `images/` child directory. Render's [persistent-disk documentation](https://render.com/docs/disks) explains that files outside the mount are ephemeral.
7. Set the health-check path to `/api/menu-packages`. Deploy and inspect the startup/build logs. A schema-validation failure is a deployment requirement to resolve on staging, not a reason to enable destructive schema generation.
8. Record the actual backend HTTPS origin. Check `https://YOUR_BACKEND_HOST/api/menu-packages` returns JSON. Public reads should work; `/api/admin/bookings` without a token should return 401.

Other Docker/Java 21 services can use the same Dockerfile or `java -jar target/Saneth-0.0.1-SNAPSHOT.jar`. They must permit MySQL connectivity and SMTP, retain uploads, and run a continuously available process for notification retries. Keep one instance while using a local persistent upload disk.

## 4. Deploy the frontend to Vercel

1. In Vercel choose **Add New > Project** and import `saneth-frontend`.
2. Use framework **Other**, root `.`, Node.js 22 or newer, build command `npm run build`, and output `dist`. The included `vercel.json` already supplies build/output configuration, redirects, and response headers. [Vercel documents these project settings](https://vercel.com/docs/project-configuration/vercel-json).
3. Add public environment variable `SANETH_API_BASE_URL=https://YOUR_BACKEND_HOST` for Production. Set it for Preview too if preview deployments should connect to an allowed staging backend.
4. Deploy. The build generates the browser configuration; environment changes require redeployment. [Vercel's environment documentation](https://vercel.com/docs/environment-variables) describes the environment scopes.
5. Open the resulting frontend URL and `/admin/index.html`. Update backend `SANETH_ALLOWED_ORIGINS` and `SANETH_TRACKING_URL` to this exact origin/URL and restart or redeploy the backend.
6. If adding a custom frontend domain, add both the Vercel origin and custom origin to allowed origins when both are used. Use the canonical custom tracking URL in emails. Include only specific trusted preview origins; never enable `*` or all `*.vercel.app` domains for admin access.

All site pages use the same shared backend configuration. Uploaded menu images are loaded from the backend's `/uploads/` path. Preserve the original image filenames when moving uploaded files.

## 5. Verify Gmail and the complete live workflow

Use a disposable staging customer email you control and a dedicated staging database. Set the Gmail account's App Password securely; 2-Step Verification and account eligibility are required by [Google's App Password instructions](https://support.google.com/mail/answer/185833?hl=en). Keep visible sender name **Saneth Catering**.

1. Customer registration: submit matching passwords, confirm one unverified account is created, and receive an OTP email. Check inbox/spam and sender name. No password or OTP should appear in API responses or URLs.
2. OTP: reject an incorrect or expired code; resend after cooldown; verify the correct code. Confirm the existing success step leads to Sign In and the verified account can sign in normally.
3. Booking: choose package/custom menu, date, guests, venue, and add-ons. Verify the pending booking/reference and tracking page. Check confirmation/payment instructions are not shown as approval before the admin approves.
4. Admin: sign in, confirm with the intended quote and required down payment, and receive the customer's booking confirmation email with correct event, quote, tracking URL, and payment details.
5. Capacity: on staging, confirm three bookings at distinct times on one date. Verify the indicator shows fully booked, pending requests do not reserve slots, and a fourth confirmation is rejected. Check cancellation frees the expected slot and completed/archived history follows the existing rules.
6. Payments: submit a test payment from a customer signed in with that booking's email. Confirm it remains pending until admin verification. Verify/reject appropriately; verify only after checking actual funds in a real transaction. A staging test must not move real money.
7. Receipt: verify one test payment, check cumulative paid/balance/status and customer receipt email. Try duplicate verification and overpayment; confirm neither adds duplicate funds/receipts. Test installments and full payment.
8. Other admin features: inspect dashboard, calendar, menu editing/images, recommendations, tracking, feedback eligibility, analytics, archive/restore, and audit logs. Use disposable records for deletion tests.
9. Test desktop/laptop plus 360px/390px/768px mobile/tablet widths. Check navigation, tables, forms, OTP step, dialogs, images, map, and no horizontal page overflow. Map/geocoding and external CDNs need network access.
10. Restart/redeploy the backend; confirm data and uploaded images persist, queued emails recover, and customer/admin login still works. Check notifications report SMTP acceptance honestly rather than claiming inbox delivery.

Record the results before switching traffic from the existing system. Real Gmail delivery, production MySQL compatibility, Docker execution, public-domain TLS/CORS, and visual device QA remain deployment checks; see `VERIFICATION.md` for completed local evidence.
