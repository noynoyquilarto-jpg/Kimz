package com.catering.Saneth.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
public class FeedbackResponse {
    private Long id;

    private String bookingReference;
    private String customerName;
    private String email;

    private Long menuPackageId;
    private String menuPackageName;

    private Integer rating;
    private String comment;

    private LocalDateTime createdAt;

}
