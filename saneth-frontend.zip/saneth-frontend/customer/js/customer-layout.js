const links = [
  { href: 'customer-home.html', label: 'Home' },
  { href: 'customer-packages.html', label: 'Packages' },
  { href: 'customer-booking.html', label: 'Book Now' },
  { href: 'track-booking.html', label: 'Track' },
  { href: 'customer-feedback.html', label: 'Feedback' }
];

export function initCustomerLayout() {
  const header = document.querySelector('.site-header');
  const currentPage = window.location.pathname.split('/').pop();
  const current = !currentPage || currentPage === 'index.html' ? 'customer-home.html' : currentPage;

  if (header) {
    header.innerHTML = `
      <div class="container navbar">
        <a class="brand" href="customer-home.html" aria-label="Saneth Catering home">
          <img class="brand-mark" src="Pictures/saneth-logo.jpg" alt="Saneth Catering logo" width="56" height="56" />
          <span class="brand-text">Saneth Catering<span>Reservations and packages</span></span>
        </a>

        <nav class="nav-links" id="navLinks">
          ${links.map(link => `
            <a href="${link.href}" class="${current === link.href ? 'active' : ''}">${link.label}</a>
          `).join('')}
        </nav>

        <div class="nav-actions">
          <a href="track-booking.html" class="btn btn-light">Track Booking</a>
          <a href="customer-login.html" class="btn btn-light" id="customerAuth">Log Out</a>
          <button class="menu-toggle" id="menuToggle" aria-label="Open menu">☰</button>
        </div>
      </div>
    `;

    let logoutDialog = document.getElementById('logoutConfirmation');

    if (!logoutDialog) {
      logoutDialog = document.createElement('dialog');
      logoutDialog.id = 'logoutConfirmation';
      logoutDialog.className = 'logout-confirmation';
      logoutDialog.setAttribute('aria-labelledby', 'logoutConfirmationTitle');
      logoutDialog.setAttribute('aria-describedby', 'logoutConfirmationMessage');
      logoutDialog.innerHTML = `
        <form method="dialog">
          <div class="logout-confirmation-header">
            <h2 id="logoutConfirmationTitle">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <path d="M9 4H5v16h4M10 12h10m-4-4 4 4-4 4" />
              </svg>
              Log Out?
            </h2>
            <button class="logout-confirmation-close" type="submit" value="cancel" aria-label="Close logout confirmation">&times;</button>
          </div>
          <p id="logoutConfirmationMessage">Are you sure you want to log out of your Saneth Catering account?</p>
          <div class="logout-confirmation-actions">
            <button class="logout-confirmation-cancel" type="submit" value="cancel" autofocus>Cancel</button>
            <button class="logout-confirmation-submit" type="submit" value="logout">Log Out</button>
          </div>
        </form>
      `;
      document.body.appendChild(logoutDialog);
      logoutDialog.addEventListener('close', () => {
        if (logoutDialog.returnValue === 'logout') {
          sessionStorage.removeItem('saneth_customer_token');
          sessionStorage.removeItem('saneth_customer_name');
          window.location.href = new URL('customer-login.html', document.baseURI).href;
        }
      });
    }

    document.getElementById('customerAuth')?.addEventListener('click', (event) => {
      event.preventDefault();
      if (!logoutDialog.open) {
        logoutDialog.returnValue = '';
        logoutDialog.showModal();
      }
    });

    const menuToggle = document.getElementById('menuToggle');
    menuToggle?.addEventListener('click', () => {
      document.body.classList.toggle('nav-open');
    });

    document.querySelectorAll('.nav-links a').forEach(link => {
      link.addEventListener('click', () => document.body.classList.remove('nav-open'));
    });
  }

  const footer = document.querySelector('.footer');
  if (footer) {
    footer.innerHTML = `
      <div class="container footer-inner">
        <span>© ${new Date().getFullYear()} Saneth Catering. All rights reserved.</span>
        <span>GCash payment instructions are sent after admin confirms your booking.</span>
      </div>
    `;
  }
}
