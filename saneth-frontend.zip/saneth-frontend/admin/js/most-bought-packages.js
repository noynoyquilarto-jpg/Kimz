import { apiRequest, safe } from './api.js';

export function rankPackages(data) {
  if (!Array.isArray(data)) throw new Error('Invalid package ranking response. Please try again.');
  return data.map(item => {
    // Older API deployments use totalBought or count for the same total.
    // Nullish fallback preserves a valid zero instead of selecting another field.
    const count = item?.totalBookings ?? item?.totalBought ?? item?.count;
    const totalBookings = Number(count);
    if (count === null || count === undefined || String(count).trim() === '' ||
        !Number.isSafeInteger(totalBookings) || totalBookings < 0) {
      throw new Error('Invalid package booking count. Please try again.');
    }
    return {
      packageId: item.packageId,
      packageName: String(item.packageName ?? '').trim() || 'Unnamed package',
      totalBookings
    };
  }).sort((a, b) => b.totalBookings - a.totalBookings ||
    a.packageName.localeCompare(b.packageName) ||
    String(a.packageId).localeCompare(String(b.packageId))).slice(0, 5);
}

export function renderPackageRanking(packages, table = false) {
  if (!packages.length) {
    return table ? '<tr><td colspan="3">No package bookings yet.</td></tr>'
      : '<p class="muted">No package bookings yet.</p>';
  }
  return packages.map((item, index) => table ? `
    <tr>
      <td>${index + 1}</td>
      <td><strong>${safe(item.packageName)}</strong></td>
      <td>${item.totalBookings}</td>
    </tr>` : `
    <div class="list-item">
      <div>
        <strong>${index + 1}. ${safe(item.packageName)}</strong>
        <p class="muted">${item.totalBookings} ${item.totalBookings === 1 ? 'booking' : 'bookings'}</p>
      </div>
    </div>`).join('');
}

export function createPackageRankingLoader(container, refreshButton, table = false) {
  let loading = false;
  const message = text => table
    ? `<tr><td colspan="3">${safe(text)}</td></tr>`
    : `<p class="muted">${safe(text)}</p>`;
  async function load() {
    if (loading) return;
    loading = true;
    refreshButton.disabled = true;
    container.setAttribute('aria-busy', 'true');
    container.innerHTML = message('Loading packages...');
    try {
      const data = await apiRequest('/api/admin/analytics/most-bought-packages');
      container.innerHTML = renderPackageRanking(rankPackages(data), table);
    } catch (error) {
      container.innerHTML = message(`Could not load package rankings: ${error.message}`);
    } finally {
      loading = false;
      refreshButton.disabled = false;
      container.setAttribute('aria-busy', 'false');
    }
  }
  refreshButton.addEventListener('click', load);
  window.addEventListener('focus', load);
  setInterval(() => {
    if (!document.hidden) load();
  }, 15000);
  return load;
}
