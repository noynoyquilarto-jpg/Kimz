package com.catering.Saneth.controller;

import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.repository.BookingRepo;
import com.catering.Saneth.service.AdminAuditLogService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.LockModeType;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/archives")
public class ArchiveDeleteController {
    private final BookingRepo bookingRepo;
    private final AdminAuditLogService adminAuditLogService;
    private final EntityManager entityManager;

    public record RestoreRequest(BookingStatus status) {}

    @Transactional
    @PutMapping("/bookings/{id}/unarchive")
    public ResponseEntity<?> unarchiveBooking(@PathVariable("id") Long id,
                                              @RequestBody RestoreRequest request) {
        if (request.status() != BookingStatus.COMPLETED && request.status() != BookingStatus.CANCELLED) {
            return ResponseEntity.badRequest().body(Map.of("message", "Choose Completed or Cancelled."));
        }
        bookingRepo.lockDailyCapacity();
        Booking booking = entityManager.find(Booking.class, id, LockModeType.PESSIMISTIC_WRITE);
        if (booking == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "Archived booking not found."));
        }
        if (booking.getBookingStatus() != BookingStatus.ARCHIVED) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("message", "Only archived bookings can be restored."));
        }
        if (booking.getStatusBeforeArchive() != null && request.status() != booking.getStatusBeforeArchive()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Restore this booking as " + booking.getStatusBeforeArchive() + " to preserve its history."));
        }
        if (request.status() == BookingStatus.COMPLETED && booking.getStatusBeforeArchive() != BookingStatus.COMPLETED
                && bookingRepo.countByEventDateAndBookingStatusIn(booking.getEventDate(),
                com.catering.Saneth.service.BookingService.CAPACITY_STATUSES) >= com.catering.Saneth.service.BookingService.DAILY_CAPACITY) {
            return ResponseEntity.badRequest().body(Map.of("message", "This date is fully booked."));
        }
        booking.setBookingStatus(request.status());
        booking.setArchiveReason(null);
        bookingRepo.saveAndFlush(booking);
        adminAuditLogService.record("BOOKING_UNARCHIVED", "BOOKING", id,
                "Restored " + booking.getBookingReference() + " as " + request.status());
        return ResponseEntity.noContent().build();
    }

    @Transactional
    @DeleteMapping("/bookings/{id}")
    public ResponseEntity<?> deleteArchivedBooking(@PathVariable("id") Long id) {
        Booking booking = entityManager.find(Booking.class, id, LockModeType.PESSIMISTIC_WRITE);
        if (booking == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("message", "Archived booking not found. Refresh the archive list."));
        }
        if (booking.getBookingStatus() != BookingStatus.ARCHIVED) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("message", "Only archived bookings can be deleted."));
        }
        String reference = booking.getBookingReference();
        // Remove dependent reviews before their booking; roll back both if deletion fails.
        int deletedFeedback = entityManager.createQuery(
                "delete from Feedback f where f.booking.id = :id")
                .setParameter("id", id).executeUpdate();
        entityManager.createQuery("delete from BookingPayment p where p.booking.id = :id")
                .setParameter("id", id).executeUpdate();
        bookingRepo.delete(booking);
        bookingRepo.flush();
        adminAuditLogService.record("BOOKING_DELETED", "BOOKING", id,
                "Archived booking permanently deleted: " + reference
                        + "; linked feedback deleted: " + deletedFeedback);
        return ResponseEntity.noContent().build();
    }
}
