package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.AdminUpdateBookingRequest;
import com.catering.Saneth.dto.request.ConfirmBookingRequest;
import com.catering.Saneth.dto.request.UpdatePaymentRequest;
import com.catering.Saneth.dto.response.BookingResponse;
import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.MenuPackage;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.model.enums.PaymentStatus;
import com.catering.Saneth.repository.BookingRepo;
import com.catering.Saneth.repository.MenuPackageRepo;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
@org.springframework.transaction.annotation.Transactional(isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
@RequiredArgsConstructor
public class AdminBookingService {

    private final BookingRepo bookingRepo;
    private final BookingTrackingEmailService bookingTrackingEmailService;
    private final ReceiptEmailService receiptEmailService;
    private final MenuPackageRepo menuPackageRepo;
    private final com.catering.Saneth.repository.BookingPaymentRepo bookingPaymentRepo;

    public List<BookingResponse> getAllBookings() {

        return bookingRepo
                .findByBookingStatusNotOrderByCreatedAtDesc(
                        BookingStatus.ARCHIVED
                )
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public boolean sendConfirmationEmail(Long id) {
        Booking booking = bookingRepo.findForUpdateById(id)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found."));
        List<String> names = booking.getMenuPackage() != null
                ? booking.getMenuPackage().getItems().stream().map(com.catering.Saneth.model.MenuItem::getName).toList()
                : booking.getCustomMenuItems().stream().map(item -> item.getMenuItem().getName()).toList();
        return bookingTrackingEmailService.resendConfirmation(booking, names);
    }

    public BookingResponse getBookingById(Long id) {

        Booking booking = bookingRepo.findForUpdateById(id)
                .orElseThrow(() ->
                        new RuntimeException("Booking does not exist!")
                );

        return mapToResponse(booking);
    }

    public BookingResponse updateBookingStatus(
            Long id,
            BookingStatus status
    ) {
        if (status == BookingStatus.CONFIRMED) {
            throw new RuntimeException("Use Confirm Booking and supply the approved quote and down payment.");
        }
        if (status == BookingStatus.COMPLETED) return completeBooking(id);

        Booking booking = bookingRepo.findForUpdateById(id)
                .orElseThrow(() ->
                        new RuntimeException("Booking not found!")
                );

        validateBookingStatusTransition(
                booking,
                status
        );

        booking.setBookingStatus(status);

        if (status == BookingStatus.CONFIRMED) {
            booking.setPaymentStatus(
                    PaymentStatus.AWAITING_PAYMENT
            );
        }

        return mapToResponse(
                bookingRepo.save(booking)
        );
    }

    // =========================================================
    // CONFIRM BOOKING
    // =========================================================

    public BookingResponse confirmBooking(
            Long id,
            @Valid ConfirmBookingRequest request
    ) {

        bookingRepo.lockDailyCapacity();

        Booking booking = bookingRepo.findForUpdateById(id)
                .orElseThrow(() ->
                        new RuntimeException("Booking not found.")
                );

        if (booking.getBookingStatus() != BookingStatus.PENDING) {

            throw new RuntimeException(
                    "Only pending bookings can be confirmed."
            );
        }

        if (request.getQuotedPrice() == null ||
                request.getQuotedPrice()
                        .compareTo(BigDecimal.ZERO) <= 0) {

            throw new RuntimeException(
                    "Quoted price must be greater than zero."
            );
        }

        if (request.getDownPayment() == null ||
                request.getDownPayment()
                        .compareTo(BigDecimal.ZERO) < 0) {

            throw new RuntimeException(
                    "Required downpayment cannot be negative."
            );
        }

        if (request.getDownPayment()
                .compareTo(request.getQuotedPrice()) > 0) {

            throw new RuntimeException(
                    "Required downpayment cannot be greater than the quoted price."
            );
        }

        if (bookingRepo.countByEventDateAndBookingStatusIn(booking.getEventDate(), BookingService.CAPACITY_STATUSES) >= BookingService.DAILY_CAPACITY) {
            throw new RuntimeException("Cannot confirm booking. This date is fully booked (3 bookings). Please select another date.");
        }
        boolean hasConflict =
                bookingRepo
                        .existsByEventDateAndEventTimeAndBookingStatusAndIdNot(
                                booking.getEventDate(),
                                booking.getEventTime(),
                                BookingStatus.CONFIRMED,
                                booking.getId()
                        );

        if (hasConflict) {

            throw new RuntimeException(
                    "Cannot confirm booking. There is already a confirmed booking on the same date and time."
            );
        }

        /*
         * IMPORTANT:
         *
         * quotedPrice = final price
         *
         * downPayment = REQUIRED downpayment
         *
         * downPaymentAmount = ACTUAL payment received
         *
         * At confirmation, customer has NOT paid yet.
         *
         * Therefore:
         *
         * downPaymentAmount = 0
         *
         * Balance = quotedPrice
         */

        booking.setQuotedPrice(
                request.getQuotedPrice()
        );

        booking.setDownPayment(
                request.getDownPayment()
        );

        booking.setDownPaymentAmount(
                0.0
        );

        booking.setBookingStatus(
                BookingStatus.CONFIRMED
        );

        booking.setPaymentStatus(
                PaymentStatus.AWAITING_PAYMENT
        );

        Booking updatedBooking =
                bookingRepo.save(booking);

        List<String> names = updatedBooking.getMenuPackage() != null
                ? updatedBooking.getMenuPackage().getItems().stream().map(com.catering.Saneth.model.MenuItem::getName).toList()
                : updatedBooking.getCustomMenuItems().stream().map(item -> item.getMenuItem().getName()).toList();
        bookingTrackingEmailService.sendAfterBookingConfirmed(updatedBooking,
                updatedBooking.getQuotedPrice(), updatedBooking.getDownPayment(), names);


        return mapToResponse(updatedBooking);
    }

    // =========================================================
    // UPDATE ACTUAL PAYMENT
    // =========================================================

    public BookingResponse updatePayment(
            Long id,
            @Valid UpdatePaymentRequest request
    ) {
        Booking booking = bookingRepo.findForUpdateById(id)
                .orElseThrow(() -> new RuntimeException("Booking not found!"));
        Double amount = request.getDownPaymentAmount();
        if (booking.getBookingStatus() != BookingStatus.CONFIRMED) {
            throw new RuntimeException("Only confirmed bookings can have payments edited.");
        }
        if (amount == null || !Double.isFinite(amount) || amount < 0
                || BigDecimal.valueOf(amount).stripTrailingZeros().scale() > 2
                || booking.getQuotedPrice() == null || booking.getQuotedPrice().signum() <= 0
                || BigDecimal.valueOf(amount).compareTo(booking.getQuotedPrice()) > 0) {
            throw new RuntimeException("Enter a total paid between zero and the quoted price, with at most two decimal places.");
        }
        var payments = bookingPaymentRepo.findByBookingIdOrderByCreatedAtAsc(id);
        BigDecimal recorded = payments.stream().filter(p -> "VERIFIED".equals(p.getVerificationStatus())).map(p -> BigDecimal.valueOf(p.getAmount()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal adjustment = BigDecimal.valueOf(amount).subtract(recorded);
        if (request.getPaymentMethod() != null) booking.setPaymentMethod(request.getPaymentMethod());
        if (adjustment.signum() != 0 && booking.getPaymentMethod() == null) {
            throw new RuntimeException("Select a payment method (Cash, GCash, or bank transfer) before saving the payment.");
        }
        com.catering.Saneth.model.BookingPayment receiptRecord = null;
        if (adjustment.signum() != 0) {
            receiptRecord = bookingPaymentRepo.save(com.catering.Saneth.model.BookingPayment.builder()
                    .booking(booking).amount(adjustment.doubleValue())
                    .paymentMethod(booking.getPaymentMethod())
                    .note("Admin corrected total paid to " + amount).build());
        }
        booking.setDownPaymentAmount(amount);
        booking.setPaymentStatus(amount == 0 ? PaymentStatus.AWAITING_PAYMENT
                : BigDecimal.valueOf(amount).compareTo(booking.getQuotedPrice()) == 0
                ? PaymentStatus.FULLY_PAID : PaymentStatus.PARTIALLY_PAID);
        booking.setPaymentRejectionReason(null);
        Booking saved = bookingRepo.save(booking);
        if (adjustment.signum() > 0) receiptEmailService.sendPaymentReceipt(saved, receiptRecord);
        return mapToResponse(saved);
    }

    // =========================================================
    // COMPLETE BOOKING
    // =========================================================

    public BookingResponse completeBooking(Long id) {

        Booking booking = bookingRepo.findForUpdateById(id)
                .orElseThrow(() ->
                        new RuntimeException("Booking not found!")
                );

        if (booking.getEventDate() == null || !booking.getEventDate().isBefore(
                java.time.LocalDate.now(java.time.ZoneId.of("Asia/Manila")))) {
            throw new RuntimeException("Bookings can be completed only after the event date.");
        }

        if (booking.getBookingStatus()
                != BookingStatus.CONFIRMED) {

            throw new RuntimeException(
                    "Only confirmed bookings can be completed."
            );
        }

        if (booking.getQuotedPrice() == null) {

            throw new RuntimeException(
                    "Quoted price has not been set."
            );
        }

        BigDecimal paid =
                BigDecimal.valueOf(
                        booking.getDownPaymentAmount() != null
                                ? booking.getDownPaymentAmount()
                                : 0.0
                );

        if (paid.compareTo(booking.getQuotedPrice()) < 0) {

            throw new RuntimeException(
                    "Booking must be fully paid before it can be completed."
            );
        }

        booking.setPaymentStatus(
                PaymentStatus.FULLY_PAID
        );

        booking.setBookingStatus(
                BookingStatus.COMPLETED
        );

        return mapToResponse(
                bookingRepo.save(booking)
        );
    }

    // =========================================================
    // CANCEL
    // =========================================================

    public BookingResponse cancelBooking(
            Long id,
            String reason
    ) {

        Booking booking = bookingRepo.findForUpdateById(id)
                .orElseThrow(() ->
                        new RuntimeException("Booking not found!")
                );

        if (booking.getBookingStatus()
                == BookingStatus.COMPLETED ||
                booking.getBookingStatus()
                        == BookingStatus.ARCHIVED) {

            throw new RuntimeException(
                    "Completed or archived bookings cannot be cancelled."
            );
        }

        booking.setBookingStatus(
                BookingStatus.CANCELLED
        );

        booking.setCancellationReason(
                reason
        );

        return mapToResponse(
                bookingRepo.save(booking)
        );
    }

    // =========================================================
    // UPDATE BOOKING DETAILS
    // =========================================================

    public BookingResponse updateBooking(
            Long bookingId,
            AdminUpdateBookingRequest request
    ) {

        bookingRepo.lockDailyCapacity();

        Booking booking = bookingRepo.findForUpdateById(bookingId)
                .orElseThrow(() ->
                        new RuntimeException("Booking not found")
                );

        if (booking.getBookingStatus()
                == BookingStatus.COMPLETED ||
                booking.getBookingStatus()
                        == BookingStatus.CANCELLED || booking.getBookingStatus() == BookingStatus.ARCHIVED) {

            throw new RuntimeException(
                    "Completed or cancelled bookings cannot be edited."
            );
        }

        MenuPackage menuPackage =
                booking.getMenuPackage();

        if (request.getMenuPackageId() != null) {

            menuPackage =
                    menuPackageRepo
                            .findById(
                                    request.getMenuPackageId()
                            )
                            .orElseThrow(() ->
                                    new RuntimeException(
                                            "Menu package not found"
                                    )
                            );
        }

        LocalDate newEventDate =
                request.getEventDate() != null
                        ? request.getEventDate()
                        : booking.getEventDate();

        LocalTime newEventTime =
                request.getEventTime() != null
                        ? request.getEventTime()
                        : booking.getEventTime();

        Integer newNumberOfPax =
                request.getNumberOfPax() != null
                        ? request.getNumberOfPax()
                        : booking.getNumberOfPax();

        validateAdminBookingUpdate(
                booking.getId(),
                newEventDate,
                newEventTime,
                newNumberOfPax,
                menuPackage
        );

        if (request.getEventType() != null &&
                !request.getEventType().isBlank()) {

            booking.setEventType(
                    request.getEventType()
            );
        }

        if (!newEventDate.equals(booking.getEventDate())
                && BookingService.CAPACITY_STATUSES.contains(booking.getBookingStatus())
                && bookingRepo.countByEventDateAndBookingStatusInAndIdNot(newEventDate, BookingService.CAPACITY_STATUSES, booking.getId()) >= BookingService.DAILY_CAPACITY) {
            throw new RuntimeException("This date is fully booked. Please select another event date.");
        }
        booking.setEventDate(
                newEventDate
        );

        booking.setEventTime(
                newEventTime
        );

        if (request.getEventPlace() != null &&
                !request.getEventPlace().isBlank()) {

            booking.setEventPlace(
                    request.getEventPlace()
            );
        }

        booking.setNumberOfPax(
                newNumberOfPax
        );

        booking.setMenuPackage(
                menuPackage
        );

        if (request.getAdminNote() != null &&
                !request.getAdminNote().isBlank()) {

            String oldNote =
                    booking.getPaymentNote() != null
                            ? booking.getPaymentNote() + "\n"
                            : "";

            booking.setPaymentNote(
                    oldNote +
                            "Booking updated by admin: " +
                            request.getAdminNote()
            );
        }

        return mapToResponse(
                bookingRepo.save(booking)
        );
    }

    // =========================================================
    // STATUS VALIDATION
    // =========================================================

    private void validateBookingStatusTransition(
            Booking booking,
            BookingStatus nextStatus
    ) {

        BookingStatus currentStatus =
                booking.getBookingStatus();

        if (currentStatus == nextStatus) {
            return;
        }

        boolean allowed =
                switch (currentStatus) {

                    case PENDING ->
                            nextStatus == BookingStatus.CONFIRMED ||
                                    nextStatus == BookingStatus.CANCELLED;

                    case CONFIRMED ->
                            nextStatus == BookingStatus.COMPLETED ||
                                    nextStatus == BookingStatus.CANCELLED;

                    case COMPLETED, CANCELLED ->
                            nextStatus == BookingStatus.ARCHIVED;

                    case ARCHIVED -> false;
                };

        if (!allowed) {

            throw new RuntimeException(
                    "Invalid booking status transition from "
                            + currentStatus +
                            " to "
                            + nextStatus +
                            "."
            );
        }

        if (nextStatus == BookingStatus.COMPLETED &&
                booking.getPaymentStatus()
                        != PaymentStatus.FULLY_PAID) {

            throw new RuntimeException(
                    "Booking must be fully paid before it can be completed."
            );
        }
    }

    // =========================================================
    // BOOKING UPDATE VALIDATION
    // =========================================================

    private void validateAdminBookingUpdate(
            Long bookingId,
            LocalDate eventDate,
            LocalTime eventTime,
            Integer numberOfPax,
            MenuPackage menuPackage
    ) {

        if (eventDate == null) {
            throw new RuntimeException(
                    "Event date is required."
            );
        }

        if (eventDate.isBefore(LocalDate.now())) {
            throw new RuntimeException(
                    "Event date cannot be in the past."
            );
        }

        if (eventTime == null) {
            throw new RuntimeException(
                    "Event time is required."
            );
        }

        if (numberOfPax == null ||
                numberOfPax <= 0) {

            throw new RuntimeException(
                    "Number of pax must be greater than 0."
            );
        }

        if (menuPackage != null) {

            if (menuPackage.getGoodForPax() != null &&
                    numberOfPax <
                            menuPackage.getGoodForPax()) {

                throw new RuntimeException(
                        "This package requires at least "
                                + menuPackage.getGoodForPax()
                                + " pax."
                );
            }

            if (!Boolean.TRUE.equals(
                    menuPackage.getAvailable())) {

                throw new RuntimeException(
                        "Selected menu package is not available."
                );
            }
        }

        boolean hasConflict =
                bookingRepo
                        .existsByEventDateAndEventTimeAndBookingStatusAndIdNot(
                                eventDate,
                                eventTime,
                                BookingStatus.CONFIRMED,
                                bookingId
                        );

        if (hasConflict) {

            throw new RuntimeException(
                    "There is already a confirmed booking on the same date and time."
            );
        }

        int maximumPax = 500;

        if (numberOfPax > maximumPax) {

            throw new RuntimeException(
                    "Number of pax cannot exceed "
                            + maximumPax
                            + "."
            );
        }
    }

    // =========================================================
    // RESPONSE
    // =========================================================

    BookingResponse mapToResponse(
            Booking booking
    ) {

        BigDecimal quotedPrice =
                booking.getQuotedPrice();

        BigDecimal actualPaid =
                BigDecimal.valueOf(
                        booking.getDownPaymentAmount() != null
                                ? booking.getDownPaymentAmount()
                                : 0.0
                );

        BigDecimal balance =
                quotedPrice != null
                        ? quotedPrice.subtract(actualPaid)
                        : BigDecimal.ZERO;

        if (balance.compareTo(BigDecimal.ZERO) < 0) {
            balance = BigDecimal.ZERO;
        }

        return BookingResponse.builder()
                .emailNotifications(bookingTrackingEmailService.status(booking.getId()))

                .id(booking.getId())

                .bookingReference(
                        booking.getBookingReference()
                )

                .customerName(
                        booking.getCustomerName()
                )

                .email(
                        booking.getEmail()
                )

                .phoneNumber(
                        booking.getPhoneNumber()
                )

                .customerAddress(
                        booking.getCustomerAddress()
                )

                .eventPlace(
                        booking.getEventPlace()
                )

                .eventDate(
                        booking.getEventDate()
                )

                .eventTime(
                        booking.getEventTime()
                )

                .eventType(
                        booking.getEventType()
                )

                .numberOfPax(
                        booking.getNumberOfPax()
                )

                .bookingType(
                        booking.getBookingType()
                )

                .menuPackageId(
                        booking.getMenuPackage() != null
                                ? booking.getMenuPackage().getId()
                                : null
                )

                .menuPackageName(
                        booking.getMenuPackage() != null
                                ? booking.getMenuPackage().getName()
                                : null
                )

                .packagePrice(
                        booking.getMenuPackage() != null
                                ? booking.getMenuPackage().getPackagePrice()
                                : null
                )

                .goodForPax(
                        booking.getMenuPackage() != null
                                ? booking.getMenuPackage().getGoodForPax()
                                : null
                )

                .packageMenuItems(
                        booking.getMenuPackage() != null
                                ? (booking.getCustomMenuItems().isEmpty()
                                        ? booking.getMenuPackage().getItems().stream()
                                        : booking.getCustomMenuItems().stream().map(item -> item.getMenuItem()))
                                        .map(this::mapPackageMenuItem)
                                        .toList()
                                : List.of()
                )

                .customMenuItems(
                        booking.getCustomMenuItems()
                                .stream()
                                .filter(item -> booking.getBookingType() == com.catering.Saneth.model.enums.BookingType.CUSTOM)
                                .map(item ->
                                        com.catering.Saneth.dto.response.MenuItemResponse
                                                .builder()
                                                .id(
                                                        item.getMenuItem().getId()
                                                )
                                                .name(
                                                        item.getMenuItem().getName()
                                                )
                                                .description(
                                                        item.getMenuItem().getDescription()
                                                )
                                                .imageUrl(
                                                        item.getMenuItem().getImageUrl()
                                                )
                                                .available(
                                                        item.getMenuItem().getAvailable()
                                                )
                                                .categoryId(item.getMenuItem().getCategory().getId())
                                                .categoryName(item.getMenuItem().getCategory().getName())
                                                .subCategoryId(
                                                        item.getMenuItem()
                                                                .getSubCategory() != null
                                                                ? item.getMenuItem()
                                                                .getSubCategory()
                                                                .getId()
                                                                : null
                                                )
                                                .subCategoryName(
                                                        item.getMenuItem()
                                                                .getSubCategory() != null
                                                                ? item.getMenuItem()
                                                                .getSubCategory()
                                                                .getName()
                                                                : null
                                                )
                                                .build()
                                )
                                .toList()
                )

                .projector(
                        booking.getProjector()
                )

                .videoke(
                        booking.getVideoke()
                )

                .lechon(
                        booking.getLechon()
                )

                .cake(
                        booking.getCake()
                )

                .specialRequest(
                        booking.getSpecialRequest()
                )

                .quotedPrice(
                        quotedPrice
                )

                .requiredDownPayment(
                        booking.getDownPayment()
                )

                .downPaymentAmount(
                        booking.getDownPaymentAmount()
                )

                .balance(
                        balance
                )

                .paymentMethod(
                        booking.getPaymentMethod()
                )

                .paymentReferenceNumber(
                        booking.getPaymentReferenceNumber()
                )

                .paymentNote(
                        booking.getPaymentNote()
                )

                .bookingStatus(
                        booking.getBookingStatus()
                )

                .paymentStatus(
                        booking.getPaymentStatus()
                )

                .archiveReason(
                        booking.getArchiveReason()
                )
                .statusBeforeArchive(booking.getStatusBeforeArchive())

                .build();
    }

    private com.catering.Saneth.dto.response.MenuItemResponse mapPackageMenuItem(
            com.catering.Saneth.model.MenuItem item) {
        return com.catering.Saneth.dto.response.MenuItemResponse.builder()
                .id(item.getId())
                .name(item.getName())
                .description(item.getDescription())
                .imageUrl(item.getImageUrl())
                .available(item.getAvailable())
                .categoryId(item.getCategory().getId())
                .categoryName(item.getCategory().getName())
                .subCategoryId(item.getSubCategory() != null ? item.getSubCategory().getId() : null)
                .subCategoryName(item.getSubCategory() != null ? item.getSubCategory().getName() : null)
                .build();
    }
}
