import { apiRequest, badge, getQueryParam, peso, safe, setResult, clearResult } from './customer-api.js';
import { initCustomerLayout } from './customer-layout.js';
import { bookingNotifications } from './notifications.js';

initCustomerLayout();

const trackForm = document.getElementById('trackForm');
const trackResult = document.getElementById('trackResult');
const refInput = document.getElementById('bookingReference');
const emailInput = document.getElementById('email');
const submitButton = trackForm.querySelector('[type="submit"]');
let isTracking = false;

function renderIncludedMenu(items) {
  const sections = [
    { name: 'Soup', match: /soup/i, icon: '<path d="M4 12h16a8 8 0 0 1-16 0ZM8 3c-3 3 3 3 0 6m4-6c-3 3 3 3 0 6m4-6c-3 3 3 3 0 6"/>' },
    { name: 'Salad & Appetizer', match: /salad|appetizer/i, icon: '<path d="M3 11h18a9 9 0 0 1-18 0Zm3 0C3 5 8 3 11 7c3-6 9-4 7 4M11 7l2 4"/>' },
    { name: 'Pasta & Noodles', match: /pasta|noodle|pancit/i, icon: '<path d="M4 3v6m3-6v6M2 3v6c0 4 6 4 6 0M5 12v9M19 3c-5 3-5 10 0 10V3Zm0 10v8"/>' },
    { name: 'Main Courses', match: /main|chicken|pork|beef|fish|seafood|vegetable/i, icon: '<path d="M4 10h16v10H4ZM2 7h20M10 4h4M12 4V2"/>' },
    { name: 'Dessert', match: /dessert/i, icon: '<path d="M4 10h16v10H4Zm0 0 12-6 4 6M8 14h8M8 17h8M16 4V2"/>' },
    { name: 'Drinks', match: /drink|beverage|refreshment/i, icon: '<path d="M6 7h12l-2 14H8ZM5 7h14M13 7l2-5h4M7 12h10"/>' }
  ];
  // Older menu records use "Other"; infer a display group only when no category was saved.
  const dishCategories = [
    /soup/i,
    /salad|lumpia|shanghai|appetizer/i,
    /pasta|noodle|pancit|spaghetti|carbonara|lasagna|macaroni/i,
    /chicken|lechon|kawali|pork|embutido|fish|beef|seafood|vegetable/i,
    /dessert|crema|fruta|cake|fruit|buko|leche flan/i,
    /soft\s*drinks?|juice|iced?\s*tea|beverage|water/i
  ];
  const categories = new Map();
  for (const item of Array.isArray(items) ? items : []) {
    const name = String(item?.name || '').trim();
    if (!name) continue;
    const rawCategory = String(item.categoryName || '').trim() || 'Other';
    const missingCategory = /^(other|uncategorized|n\/a)$/i.test(rawCategory);
    const inferredIndex = missingCategory ? dishCategories.findIndex(pattern => pattern.test(name)) : -1;
    const category = sections.find(section => section.match.test(rawCategory))?.name
      || (inferredIndex >= 0 ? sections[inferredIndex].name : missingCategory ? '' : rawCategory);
    if (!categories.has(category)) categories.set(category, []);
    categories.get(category).push(name);
  }
  if (!categories.size) return '';

  const groups = [...categories.entries()]
    .sort(([a], [b]) => {
      const rank = name => { const index = sections.findIndex(section => section.name === name); return index < 0 ? sections.length : index; };
      return rank(a) - rank(b) || a.localeCompare(b);
    })
    .map(([category, names]) => `
      <div class="included-menu-group${category ? '' : ' included-menu-ungrouped'}">
        ${category ? `<dt><svg class="included-menu-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${sections.find(section => section.name === category)?.icon || '<path d="M4 6h16M4 12h16M4 18h16"/>'}</svg>${safe(category)}</dt>` : '<dt hidden>Menu items</dt>'}
        <dd><ul>${names.map(name => `<li>${safe(name)}</li>`).join('')}</ul></dd>
      </div>`).join('');

  return `<div class="status-row included-menu-row"><h3>Included Menu</h3><dl class="included-menu-groups">${groups}</dl></div>`;
}

refInput.value = (getQueryParam('ref') || '').trim();
emailInput.value = (getQueryParam('email') || '').trim();
refInput.addEventListener('blur', () => { refInput.value = refInput.value.trim(); });
emailInput.addEventListener('blur', () => { emailInput.value = emailInput.value.trim(); });

trackForm?.addEventListener('submit', trackBooking);

if (refInput.value && emailInput.value) {
  trackForm.requestSubmit();
}

async function trackBooking(event) {
  event.preventDefault();
  if (isTracking) return;
  refInput.value = refInput.value.trim();
  emailInput.value = emailInput.value.trim();
  if (!trackForm.reportValidity()) return;
  clearResult(trackResult);
  isTracking = true;
  submitButton.disabled = true;
  submitButton.textContent = 'Checking booking...';
  trackResult.setAttribute('aria-busy', 'true');

  const body = {
    bookingReference: refInput.value.trim(),
    email: emailInput.value.trim()
  };

  try {
    const data = await apiRequest('/api/bookings/track', {
      method: 'POST',
      body: JSON.stringify(body)
    });

    if (!data || typeof data !== 'object' || !data.bookingReference) {
      throw new Error('Unable to read your booking. Please try again.');
    }
    const price = Number(data.quotedPrice ?? data.packagePrice ?? 0);
    const paid = Number(data.downPaymentAmount ?? 0);
    const balance = Math.max(price - paid, 0);

    setResult(trackResult, `
      <strong>Booking found</strong>
      ${bookingNotifications(data)}
      <div class="status-list">
        <div class="status-row"><span>Reference</span><strong>${safe(data.bookingReference)}</strong></div>
        <div class="status-row"><span>Customer</span><strong>${safe(data.customerName)}</strong></div>
        <div class="status-row"><span>Package</span><strong>${safe(data.menuPackageName || (data.bookingType === 'CUSTOM' ? 'Custom Menu' : null))}</strong></div>
        ${renderIncludedMenu(data.bookingType === 'CUSTOM' ? data.customMenuItems : data.packageMenuItems)}
        <div class="status-row"><span>Event Date</span><strong>${safe(data.eventDate)} ${safe(data.eventTime)}</strong></div>
        <div class="status-row"><span>Booking Status</span><strong>${badge(data.bookingStatus)}</strong></div>
        <div class="status-row"><span>Payment Status</span><strong>${badge(data.paymentStatus)}</strong></div>
        <div class="status-row"><span>${data.quotedPrice != null ? 'Quoted Price' : 'Package Price'}</span><strong>${peso(price)}</strong></div>
        <div class="status-row"><span>Total Paid</span><strong>${peso(paid)}</strong></div>
        <div class="status-row"><span>Balance</span><strong>${peso(balance)}</strong></div>
      </div>
      <p class="notice"><strong>Payment reminder:</strong> GCash details are sent by email only after admin confirms your booking. Send your proof through the Messenger link in the email.</p>
      ${data.bookingStatus === 'CONFIRMED' && balance > 0 ? paymentSubmissionForm() : ''}
    `, 'success');
    document.getElementById('submitPaymentDetails')?.addEventListener('submit', event => submitPaymentDetails(event, data.bookingReference));
  } catch (error) {
    const message = /booking.*(not exist|not found)/i.test(error.message)
      ? 'No booking matches that reference and email. Check your booking reference and use the email address entered when booking.'
      : error.message;
    setResult(trackResult, safe(message), 'error');
  } finally {
    isTracking = false;
    submitButton.disabled = false;
    submitButton.textContent = 'Track booking';
    trackResult.setAttribute('aria-busy', 'false');
  }
}

function paymentSubmissionForm() {
  if (!sessionStorage.getItem('saneth_customer_token')) return '<p class="notice">Sign in with the email used for this booking to submit payment details for admin verification.</p>';
  return `<form id="submitPaymentDetails" class="form-grid">
    <h3>Submit payment details for verification</h3>
    <label>Amount paid<input name="amount" type="number" min="0.01" step="0.01" required></label>
    <label>Payment method<select name="paymentMethod"><option value="GCASH">GCash</option><option value="BANK_TRANSFER">Bank transfer</option><option value="CASH">Cash</option></select></label>
    <label>Transaction reference<input name="paymentReferenceNumber" maxlength="255"></label>
    <label>Payment details<input name="note" maxlength="255" placeholder="Optional details; send screenshots through Messenger"></label>
    <button type="submit" class="btn btn-primary">Submit for admin verification</button><p id="paymentSubmissionMessage" role="status"></p>
  </form>`;
}
async function submitPaymentDetails(event, reference) {
  event.preventDefault();
  const form = event.currentTarget;
  if (!form.reportValidity()) return;
  const button = form.querySelector('button');
  button.disabled = true;
  const message = document.getElementById('paymentSubmissionMessage');
  form.dataset.submissionKey ||= '10000000-1000-4000-8000-100000000000'.replace(/[018]/g, char =>
    (Number(char) ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> Number(char) / 4).toString(16));
  try {
    const fields = Object.fromEntries(new FormData(form));
    const response = await apiRequest(`/api/customer/bookings/${encodeURIComponent(reference)}/payments`, {
      method: 'POST', headers: { Authorization: `Bearer ${sessionStorage.getItem('saneth_customer_token')}` },
      body: JSON.stringify({ ...fields, amount: Number(fields.amount), submissionKey: form.dataset.submissionKey })
    });
    message.textContent = response.message;
  } catch (error) { message.textContent = error.message; button.disabled = false; }
}
