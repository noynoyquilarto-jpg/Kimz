import { showAlert as alert, showConfirm as confirm } from '../../js/dialogs.js';
import { apiRequest, uploadImage, requireAuth, badge, safe, assetUrl, getCategories } from './api.js';
import { initLayout } from './layout.js';

requireAuth();
initLayout();

let currentSubCategoryId = null;

const form = document.getElementById('menuItemForm');
const list = document.getElementById('itemsList');
const message = document.getElementById('formMessage');
const resetBtn = document.getElementById('resetBtn');
const refreshBtn = document.getElementById('refreshBtn');
const formTitle = document.getElementById('formTitle');
const imageUrlInput = document.getElementById('imageUrl');
const imageFileInput = document.getElementById('imageFile');
const imageFileName = document.getElementById('imageFileName');
const imagePreview = document.getElementById('imagePreview');

async function loadCategories() {

    const categories = await getCategories();

const categorySelect = document.getElementById("categoryId");

    categorySelect.innerHTML = `
        <option value="">Select Category</option>
    `;

    categories.forEach(category => {

        categorySelect.innerHTML += `
            <option value="${category.id}">
                ${safe(category.name)}
            </option>
        `;

    });

    if (categories.length > 0) {
        categorySelect.value = categories[0].id;
    }
}

init();

async function init() {
  try {
    await loadCategories();
  } catch (error) {
    message.textContent = `Categories could not be loaded: ${error.message}`;
  }
  await loadItems();
}

refreshBtn.addEventListener('click', loadItems);
resetBtn.addEventListener('click', resetForm);
imageFileInput.addEventListener('change', () => previewSelectedFile(imageFileInput.files[0]));

form.addEventListener('submit', async (event) => {
  event.preventDefault();

  const id = document.getElementById('itemId').value;

  try {
    message.textContent = 'Saving...';

    if (imageFileInput.files[0]) {
      message.textContent = 'Uploading image...';
      const upload = await uploadImage(imageFileInput.files[0]);
      imageUrlInput.value = upload.imageUrl;
    }

    if (!imageUrlInput.value) {
      throw new Error('Please choose an image.');
    }

    const categoryIdValue = document.getElementById('categoryId').value;
    if (!categoryIdValue) {
      throw new Error('Please select a category.');
    }

const body = {
      name: document.getElementById('name').value.trim(),
      categoryId: Number(categoryIdValue),
      subCategoryId: currentSubCategoryId,
      description: document.getElementById('description').value.trim(),
      imageUrl: imageUrlInput.value.trim(),
      available: document.getElementById('available').value === 'true'
    };

    message.textContent = 'Saving...';
    await apiRequest(id ? `/api/admin/menu-items/${id}` : '/api/admin/menu-items', {
      method: id ? 'PUT' : 'POST',
      body: JSON.stringify(body)
    });
    message.textContent = id ? 'Menu item updated.' : 'Menu item created.';
    resetForm();
    loadItems();
  } catch (error) {
    message.textContent = error.message;
  }
});

async function loadItems() {
  list.innerHTML = '<div class="empty-state">Loading menu items...</div>';
  try {
    const items = await apiRequest('/api/admin/menu-items');
    renderItems(items || []);
  } catch (error) {
    list.innerHTML = `<div class="empty-state">${safe(error.message)}</div>`;
  }
}

function renderItems(items) {
  if (!items.length) {
    list.innerHTML = '<div class="empty-state">No menu items yet.</div>';
    return;
  }

  list.innerHTML = items.map(item => `
    <article class="item-card">
      ${imageBlock(item.imageUrl, item.name)}
      <div>
        <h3>${safe(item.name)}</h3>
        <div class="card-meta">
          <span class="badge">${safe(item.categoryName)}</span>
          ${item.subCategoryName ? `<span class="badge">${safe(item.subCategoryName)}</span>` : ''}
          ${badge(item.available ? 'Available' : 'Unavailable')}
        </div>
        <p>${safe(item.description || 'No description')}</p>
        <div class="actions">
          <button class="btn btn-light btn-small" data-edit='${encodeURIComponent(JSON.stringify(item))}'>Edit</button>
          <button class="btn btn-danger btn-small" data-delete="${item.id}">Delete</button>
        </div>
      </div>
    </article>
  `).join('');

  list.querySelectorAll('[data-edit]').forEach(button => {
    button.addEventListener('click', () => editItem(JSON.parse(decodeURIComponent(button.dataset.edit))));
  });

  list.querySelectorAll('[data-delete]').forEach(button => {
    button.addEventListener('click', () => deleteItem(button.dataset.delete));
  });
}

function imageBlock(url, name) {
  if (url) return `<img class="card-image" src="${safe(assetUrl(url))}" alt="${safe(name)}" onerror="this.outerHTML='<div class=&quot;card-placeholder&quot;>No image</div>'" />`;
  return '<div class="card-placeholder">No image</div>';
}

function editItem(item) {
  formTitle.textContent = 'Edit Menu Item';

  document.getElementById('itemId').value = item.id;
  document.getElementById('name').value = item.name || '';
  document.getElementById('description').value = item.description || '';
  document.getElementById('available').value = item.available ? 'true' : 'false';

  imageUrlInput.value = item.imageUrl || '';
  imageFileInput.value = '';
  imageFileName.textContent = item.imageUrl ? 'Current image kept' : 'No image selected';
  updateImagePreview(item.imageUrl);

  const categorySelect = document.getElementById('categoryId');
  if (item.categoryId) {
    categorySelect.value = item.categoryId;
  }
  currentSubCategoryId = item.subCategoryId || null;

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function deleteItem(id) {
  if (!await confirm('Delete this menu item?')) return;
  try {
    await apiRequest(`/api/admin/menu-items/${id}`, { method: 'DELETE' });
    loadItems();
  } catch (error) {
    alert(error.message);
  }
}

function resetForm() {
  formTitle.textContent = 'Create Menu Item';
  form.reset();
  document.getElementById('itemId').value = '';
  imageFileInput.value = '';
  imageUrlInput.value = '';
  imageFileName.textContent = 'No image selected';
  document.getElementById('available').value = 'true';
  updateImagePreview('');
  currentSubCategoryId = null;
}

function previewSelectedFile(file) {
  if (!file) {
    imageFileName.textContent = imageUrlInput.value ? 'Current image kept' : 'No image selected';
    updateImagePreview(imageUrlInput.value);
    return;
  }

  imageFileName.textContent = file.name;
  const localUrl = URL.createObjectURL(file);
  updateImagePreview(localUrl, file.name);
}

function updateImagePreview(url, altText = 'Menu item preview') {
  const cleanUrl = String(url || '').trim();

  if (!cleanUrl) {
    imagePreview.className = 'image-preview empty';
    imagePreview.textContent = 'No image selected';
    return;
  }

  imagePreview.className = 'image-preview';
  imagePreview.innerHTML = `<img src="${safe(assetUrl(cleanUrl))}" alt="${safe(altText)}" onerror="this.parentElement.className='image-preview empty'; this.parentElement.textContent='Image not found';" />`;
}
