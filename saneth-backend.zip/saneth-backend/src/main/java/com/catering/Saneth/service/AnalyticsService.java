package com.catering.Saneth.service;

import com.catering.Saneth.dto.response.AnalyticsResponse;
import com.catering.Saneth.dto.response.MonthlySalesResponse;
import com.catering.Saneth.dto.response.MostBoughtPackageResponse;
import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.model.enums.PaymentStatus;
import com.catering.Saneth.repository.BookingRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AnalyticsService {

    private final BookingRepo bookingRepo;
    private final com.catering.Saneth.repository.BookingPaymentRepo paymentRepo;

    public AnalyticsResponse getDashboardAnalytics() {
        return AnalyticsResponse.builder()
                .totalBookings(bookingRepo.count())
                .pendingBookings(bookingRepo.countByBookingStatus(BookingStatus.PENDING))
                .confirmedBookings(bookingRepo.countByBookingStatus(BookingStatus.CONFIRMED))
                .completedBookings(bookingRepo.countByBookingStatus(BookingStatus.COMPLETED))
                .cancelledBookings(bookingRepo.countByBookingStatus(BookingStatus.CANCELLED))
                .totalSales(paymentRepo.findAll().stream().mapToDouble(payment -> payment.getAmount()).sum())
                .build();
    }

    public List<MostBoughtPackageResponse> getMostBoughtPackages() {
        return bookingRepo.findMostBoughtPackages();
    }

    public List<MonthlySalesResponse> getMonthlySalesTrend() {
        Map<YearMonth, Double> monthlySales = paymentRepo.findAll().stream()
                .filter(payment -> payment.getCreatedAt() != null)
                .collect(Collectors.groupingBy(
                        payment -> YearMonth.from(payment.getCreatedAt()),
                        TreeMap::new,
                        Collectors.summingDouble(com.catering.Saneth.model.BookingPayment::getAmount)
                ));

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM yyyy");

        return monthlySales.entrySet()
                .stream()
                .map(entry -> new MonthlySalesResponse(
                        entry.getKey().format(formatter),
                        entry.getValue()
                ))
                .toList();
    }
}
