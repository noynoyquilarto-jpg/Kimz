package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.MenuPackageRequest;
import com.catering.Saneth.dto.response.MenuPackageResponse;
import com.catering.Saneth.model.MenuItem;
import com.catering.Saneth.model.MenuPackage;
import com.catering.Saneth.repository.BookingRepo;
import com.catering.Saneth.repository.FeedbackRepo;
import com.catering.Saneth.repository.MenuPackageRepo;
import com.catering.Saneth.repository.MenuRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InOrder;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MenuPackageServiceTest {

    @Mock
    private MenuRepo menuRepo;

    @Mock
    private MenuPackageRepo packageRepo;

    @Mock
    private BookingRepo bookingRepo;

    @Mock
    private FeedbackRepo feedbackRepo;

    @InjectMocks
    private MenuPackageService packageItemService;

    private MenuItem item1;
    private MenuItem item2;
    private MenuPackage menuPackage;

    @BeforeEach
    void setUp() {
        item1 = MenuItem.builder()
                .id(1L)
                .name("Fried Chicken")
                .category(com.catering.Saneth.model.MenuCategory.builder().id(1L).name("Main Course").build())
                .description("Crispy fried chicken")
                .imageUrl("/images/menu/fried-chicken.jpg")
                .available(true)
                .build();

        item2 = MenuItem.builder()
                .id(2L)
                .name("Spaghetti")
                .category(com.catering.Saneth.model.MenuCategory.builder().id(1L).name("Pasta and Noodles").build())
                .description("Sweet style spaghetti")
                .imageUrl("/images/menu/spaghetti.jpg")
                .available(true)
                .build();

        menuPackage = MenuPackage.builder()
                .id(1L)
                .name("Package A")
                .description("Budget-friendly package")
                .imageUrl("/images/packages/package-a.jpg")
                .packagePrice(15000.0)
                .goodForPax(50)
                .available(true)
                .items(List.of(item1, item2))
                .build();
    }

    @Test
    void createMenuPackage_shouldReturnCreatedPackage() {
        MenuPackageRequest request = new MenuPackageRequest();
        request.setName("Package A");
        request.setDescription("Budget-friendly package");
        request.setImageUrl("/images/packages/package-a.jpg");
        request.setPackagePrice(15000.0);
        request.setGoodForPax(50);
        request.setAvailable(true);
        request.setMenuItemIds(List.of(1L, 2L));

        when(menuRepo.findAllById(List.of(1L, 2L))).thenReturn(List.of(item1, item2));
        when(packageRepo.save(any(MenuPackage.class))).thenReturn(menuPackage);

        MenuPackageResponse response = packageItemService.createMenuPackage(request);

        assertThat(response).isNotNull();
        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getName()).isEqualTo("Package A");
        assertThat(response.getPackagePrice()).isEqualTo(15000.0);
        assertThat(response.getGoodForPax()).isEqualTo(50);
        assertThat(response.getItems()).hasSize(2);

        verify(menuRepo, times(1)).findAllById(List.of(1L, 2L));
        verify(packageRepo, times(1)).save(any(MenuPackage.class));
    }

    @Test
    void createMenuPackage_shouldThrowException_whenSomeMenuItemsNotFound() {
        MenuPackageRequest request = new MenuPackageRequest();
        request.setName("Package A");
        request.setDescription("Budget-friendly package");
        request.setImageUrl("/images/packages/package-a.jpg");
        request.setPackagePrice(15000.0);
        request.setGoodForPax(50);
        request.setAvailable(true);
        request.setMenuItemIds(List.of(1L, 2L));

        when(menuRepo.findAllById(List.of(1L, 2L))).thenReturn(List.of(item1));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            packageItemService.createMenuPackage(request);
        });

        assertThat(exception.getMessage()).isEqualTo("One or more menu items were not found!");

        verify(menuRepo, times(1)).findAllById(List.of(1L, 2L));
        verify(packageRepo, never()).save(any(MenuPackage.class));
    }

    @Test
    void getAllMenuPackages_shouldReturnPackageList() {
        when(packageRepo.findAllWithItems()).thenReturn(List.of(menuPackage));

        List<MenuPackageResponse> response = packageItemService.getAllMenuPackages();

        assertThat(response).hasSize(1);
        assertThat(response.get(0).getName()).isEqualTo("Package A");
        assertThat(response.get(0).getItems()).hasSize(2);

        verify(packageRepo, times(1)).findAllWithItems();
    }

    @Test
    void getMenuPackageById_shouldReturnPackage_whenPackageExists() {
        when(packageRepo.findWithItemsById(1L)).thenReturn(Optional.of(menuPackage));

        MenuPackageResponse response = packageItemService.getMenuPackageById(1L);

        assertThat(response).isNotNull();
        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getName()).isEqualTo("Package A");

        verify(packageRepo, times(1)).findWithItemsById(1L);
    }

    @Test
    void getMenuPackageById_shouldThrowException_whenPackageNotFound() {
        when(packageRepo.findWithItemsById(99L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            packageItemService.getMenuPackageById(99L);
        });

        assertThat(exception.getMessage()).isEqualTo("Menu Package not found!");

        verify(packageRepo, times(1)).findWithItemsById(99L);
    }

    @Test
    void updateMenuPackage_shouldReturnUpdatedPackage() {
        MenuPackageRequest request = new MenuPackageRequest();
        request.setName("Updated Package A");
        request.setDescription("Updated description");
        request.setImageUrl("/images/packages/updated-package-a.jpg");
        request.setPackagePrice(18000.0);
        request.setGoodForPax(60);
        request.setAvailable(false);
        request.setMenuItemIds(List.of(1L, 2L));

        MenuPackage updatedPackage = MenuPackage.builder()
                .id(1L)
                .name("Updated Package A")
                .description("Updated description")
                .imageUrl("/images/packages/updated-package-a.jpg")
                .packagePrice(18000.0)
                .goodForPax(60)
                .available(false)
                .items(List.of(item1, item2))
                .build();

        when(packageRepo.findById(1L)).thenReturn(Optional.of(menuPackage));
        when(menuRepo.findAllById(List.of(1L, 2L))).thenReturn(List.of(item1, item2));
        when(packageRepo.save(any(MenuPackage.class))).thenReturn(updatedPackage);

        MenuPackageResponse response = packageItemService.updateMenuPackage(1L, request);

        assertThat(response.getName()).isEqualTo("Updated Package A");
        assertThat(response.getPackagePrice()).isEqualTo(18000.0);
        assertThat(response.getGoodForPax()).isEqualTo(60);
        assertThat(response.getAvailable()).isFalse();

        verify(packageRepo, times(1)).findById(1L);
        verify(menuRepo, times(1)).findAllById(List.of(1L, 2L));
        verify(packageRepo, times(1)).save(any(MenuPackage.class));
    }

    @Test
    void deleteMenuPackage_shouldDeletePackage_whenPackageExists() {
        when(packageRepo.findById(1L)).thenReturn(Optional.of(menuPackage));

        packageItemService.deleteMenuPackage(1L);

        verify(packageRepo, times(1)).findById(1L);
        InOrder deletionOrder = inOrder(bookingRepo, feedbackRepo, packageRepo);
        deletionOrder.verify(bookingRepo).detachMenuPackage(1L);
        deletionOrder.verify(feedbackRepo).detachMenuPackage(1L);
        deletionOrder.verify(packageRepo).delete(menuPackage);
    }
}
