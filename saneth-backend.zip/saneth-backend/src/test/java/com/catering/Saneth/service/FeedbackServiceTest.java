package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.FeedbackRequest;
import com.catering.Saneth.dto.response.FeedbackResponse;
import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.Feedback;
import com.catering.Saneth.model.MenuPackage;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.repository.BookingRepo;
import com.catering.Saneth.repository.FeedbackRepo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FeedbackServiceTest {

    @Mock
    private FeedbackRepo feedbackRepo;

    @Mock
    private BookingRepo bookingRepo;

    @InjectMocks
    private FeedbackService feedbackService;

    private MenuPackage menuPackage;
    private Booking booking;
    private Feedback feedback;

    @BeforeEach
    void setUp() {
        menuPackage = MenuPackage.builder()
                .id(1L)
                .name("Package A")
                .description("Budget-friendly package")
                .packagePrice(15000.0)
                .goodForPax(50)
                .available(true)
                .build();

        booking = Booking.builder()
                .id(1L)
                .bookingReference("CAT-2026-0001")
                .customerName("Juan Dela Cruz")
                .email("juan@gmail.com")
                .menuPackage(menuPackage)
                .bookingStatus(BookingStatus.COMPLETED)
                .build();

        feedback = Feedback.builder()
                .id(1L)
                .booking(booking)
                .menuPackage(menuPackage)
                .customerName("Juan Dela Cruz")
                .email("juan@gmail.com")
                .rating(5)
                .comment("The food was delicious.")
                .createdAt(LocalDateTime.now())
                .build();
    }

    @Test
    void submitFeedback_shouldSaveFeedback_whenBookingExists() {
        FeedbackRequest request = new FeedbackRequest();
        request.setBookingReference("CAT-2026-0001");
        request.setEmail("juan@gmail.com");
        request.setRating(5);
        request.setComment("The food was delicious.");

        when(bookingRepo.findByBookingReferenceAndEmail("CAT-2026-0001", "juan@gmail.com"))
                .thenReturn(Optional.of(booking));
        when(feedbackRepo.existsByBookingId(1L)).thenReturn(false);

        when(feedbackRepo.save(any(Feedback.class))).thenReturn(feedback);

        FeedbackResponse response = feedbackService.submitFeedback(request);

        assertThat(response).isNotNull();
        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getBookingReference()).isEqualTo("CAT-2026-0001");
        assertThat(response.getCustomerName()).isEqualTo("Juan Dela Cruz");
        assertThat(response.getMenuPackageName()).isEqualTo("Package A");
        assertThat(response.getRating()).isEqualTo(5);
        assertThat(response.getComment()).isEqualTo("The food was delicious.");

        verify(bookingRepo, times(1))
                .findByBookingReferenceAndEmail("CAT-2026-0001", "juan@gmail.com");
        verify(feedbackRepo, times(1)).save(any(Feedback.class));
    }

    @Test
    void submitFeedback_shouldThrowException_whenBookingNotFound() {
        FeedbackRequest request = new FeedbackRequest();
        request.setBookingReference("CAT-2026-9999");
        request.setEmail("wrong@gmail.com");
        request.setRating(5);
        request.setComment("Nice food.");

        when(bookingRepo.findByBookingReferenceAndEmail("CAT-2026-9999", "wrong@gmail.com"))
                .thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            feedbackService.submitFeedback(request);
        });

        assertThat(exception.getMessage()).isEqualTo("Booking not found");

        verify(bookingRepo, times(1))
                .findByBookingReferenceAndEmail("CAT-2026-9999", "wrong@gmail.com");
        verify(feedbackRepo, never()).save(any(Feedback.class));
    }

    @Test
    void getAllFeedback_shouldReturnFeedbackList() {
        when(feedbackRepo.findAll()).thenReturn(List.of(feedback));

        List<FeedbackResponse> response = feedbackService.getAllFeedback();

        assertThat(response).hasSize(1);
        assertThat(response.get(0).getCustomerName()).isEqualTo("Juan Dela Cruz");
        assertThat(response.get(0).getMenuPackageName()).isEqualTo("Package A");
        assertThat(response.get(0).getRating()).isEqualTo(5);

        verify(feedbackRepo, times(1)).findAll();
    }

    @Test
    void getFeedbackById_shouldReturnFeedback_whenFeedbackExists() {
        when(feedbackRepo.findById(1L)).thenReturn(Optional.of(feedback));

        FeedbackResponse response = feedbackService.getFeedbackById(1L);

        assertThat(response).isNotNull();
        assertThat(response.getId()).isEqualTo(1L);
        assertThat(response.getBookingReference()).isEqualTo("CAT-2026-0001");
        assertThat(response.getComment()).isEqualTo("The food was delicious.");

        verify(feedbackRepo, times(1)).findById(1L);
    }

    @Test
    void getFeedbackById_shouldThrowException_whenFeedbackNotFound() {
        when(feedbackRepo.findById(99L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            feedbackService.getFeedbackById(99L);
        });

        assertThat(exception.getMessage()).isEqualTo("Feedback not found");

        verify(feedbackRepo, times(1)).findById(99L);
    }
}
