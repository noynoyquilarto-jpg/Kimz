import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const root = fileURLToPath(new URL('../', import.meta.url));
export async function files(directory = root) {
  const found = [];
  for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
    if (['.git', 'dist', 'node_modules', 'verification', 'test-results'].includes(entry.name)) continue;
    const name = path.join(directory, entry.name);
    if (entry.isDirectory()) found.push(...await files(name));
    else found.push(name);
  }
  return found;
}

export async function check() {
  const all = await files();
  const available = new Set(all.map(f => path.relative(root, f).replaceAll('\\', '/')));
  const failures = [];
  const localReference = (file, ref, base) => {
    if (!ref || /^(?:[a-z][a-z\d+.-]*:|\/\/|#|\$\{)/i.test(ref)) return;
    const url = new URL(ref, base || 'https://saneth.invalid/' + path.relative(root, file).replaceAll('\\', '/'));
    if (url.origin !== 'https://saneth.invalid') return;
    const name = decodeURIComponent(url.pathname.slice(1));
    if (name && !available.has(name) && !available.has(name + '/index.html')) {
      failures.push(`${path.relative(root, file)} references missing file: ${ref}`);
    }
  };
  for (const file of all) {
    const relative = path.relative(root, file);
    if (/\.(?:m?js|cjs)$/.test(file)) {
      const syntax = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
      if (syntax.status !== 0) failures.push(syntax.stderr);
    }
    if (/\.html$/.test(file)) {
      const html = await fs.readFile(file, 'utf8');
      if (!/name\s*=\s*["']viewport["']/i.test(html)) failures.push(`${relative} needs a viewport meta tag`);
      const baseTag = html.match(/<base\s+href=["']([^"']+)/i);
      const base = baseTag && new URL(baseTag[1], 'https://saneth.invalid/' + relative.replaceAll('\\', '/')).href;
      for (const [, ref] of html.replace(/<base\b[^>]*>/gi, '').matchAll(/(?:src|href)=["']([^"']+)["']/g)) localReference(file, ref, base);
    }
    if (/\.js$/.test(file) && !relative.includes('tests')) {
      const js = await fs.readFile(file, 'utf8');
      for (const [, ref] of js.matchAll(/\bfrom\s+['"]([^'"]+)['"]/g)) localReference(file, ref);
      if (/window\.(?:alert|confirm|prompt)\s*\(/.test(js)) failures.push(`${relative} uses a browser dialog`);
    }
    if (/\.css$/.test(file)) {
      for (const [, ref] of (await fs.readFile(file, 'utf8')).matchAll(/url\(['"]?([^)'"\s]+)['"]?\)/g)) localReference(file, ref);
    }
  }
  if (failures.length) throw new Error(failures.join('\n'));
  console.log(`Frontend checks passed: ${all.filter(f => f.endsWith('.html')).length} pages; local paths and JavaScript syntax verified.`);
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) await check();
