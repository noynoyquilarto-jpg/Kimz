package com.catering.Saneth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SanethApplicationTests {

	@Test
	void contextLoads() {
	}

}
