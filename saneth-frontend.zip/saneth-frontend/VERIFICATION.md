# Release verification — 2026-11-15 (Asia/Manila)

Both independent source projects build successfully. The original source folders, MySQL database, and uploaded files were not modified by this release preparation. Builds and workflow checks used the separated copies.

| Check | Result | Scope |
| --- | --- | --- |
| Frontend automated tests | **17 passed**, zero failed/skipped | Existing admin/customer checks, OTP UI/sign-in transitions, API configuration, styled dialog cancellation and duplicate-click protection |
| Frontend build | **Passed** | 18 HTML pages, JavaScript syntax/imports, case-sensitive local HTML/CSS asset references, viewport metadata, generated public API configuration |
| Backend Maven verification | **115 passed**, zero failed/errors/skipped | Java 21 / Spring Boot 4.0.6; original regressions plus migration guard and cross-origin access checks |
| Executable backend packaging | **Passed** | `target/Saneth-0.0.1-SNAPSHOT.jar`; no sibling frontend dependency |
| Packaged application HTTP smoke test | **17 API checks and 18 served frontend pages passed** | Separate local frontend and executable JAR, H2 in memory, mail disabled |
| Source preservation | **Passed** | All 11 admin + 6 customer pages retained; 17 original images and 8 original CSS files match byte for byte |
| Database source preservation | **Passed** | All 16 model/enum files, 12 repository files, and 10 original SQL migrations match byte for byte |
| Credential exclusion | **Passed** | No matches for private password/secret values from the original local configuration in distributed source; local config, databases, logs, uploads, caches, and Git history excluded |
| Git ignore rules | **Passed** | Local env/config, build output, deployment metadata, logs, and upload contents are ignored in each independent local Git repository |

Backend automated coverage includes registration, generated OTP messages, expiry/attempt limits/resend, verification before sign-in, password hashing, customer/admin role isolation, custom/package booking persistence and rollback, capacity/history rules, confirmation recovery, payment verification/installments/overpayment/duplicate prevention, receipt and sender content, queued notification delivery/retry, feedback, analytics, menu editing, archive/restore/deletion constraints, and audit logging. Mail tests use mocked SMTP and isolated fixtures.

The HTTP smoke test starts the actual JAR on a temporary localhost port and an independent static frontend server. It checks CORS headers, protected admin requests, admin login, customer registration and the unverified login gate, menu setup, booking creation/confirmation, payment balances and overpayment rejection, tracking, queued confirmation/receipt events, capacity metadata, analytics, and audit logs. It does not send email or modify any existing MySQL data. The temporary processes are stopped after verification.

Source changes are limited to separation/build/configuration, portable environment settings, consistent configured reply-to defaults, styled asynchronous dialogs and their necessary awaits, root homepage navigation, relevant test expectations, and a guard that prevents legacy V5 from deleting existing matching packages. Original models, repository queries, migration contents, quotes, balances, capacity limit of three, booking state rules, and payment-processing logic remain unchanged.

## Evidence

Local verification files are in `verification/`: frontend test output, backend suite totals, preservation results, and a repeatable `smoke.cjs` script. Full Maven reports are generated in `saneth-backend/target/surefire-reports/`. These raw logs, generated outputs, and caches are deliberately excluded from GitHub source ZIPs. This summary is included in both independent projects.

The Windows execution sandbox caused JDK JAR canonicalization access errors during the first build attempts. Final Maven verification succeeded outside that restriction using a workspace copy of already installed dependencies. Tests still used H2 and mocked email. No shared dependency cache, production database, or local account settings were changed.

## Remaining deployment checks

- **Real Gmail delivery:** configure the authorized Gmail SMTP account and App Password securely, run the admin SMTP check, and receive actual registration, booking-confirmation, and verified-payment receipt emails. SMTP acceptance and inbox delivery are different outcomes. Test sender display name `Saneth Catering` in the real inbox.
- **Production MySQL:** restore a backup into staging; review its schema/Flyway history and confirm validation, relationships, existing records, notification encryption compatibility, and MySQL-specific migrations. Legacy V5 is guarded because it would delete certain named packages. No live MySQL migration has been run.
- **Hosting settings:** supply actual frontend/backend HTTPS URLs, exact allowed origins, tracking URL, MySQL TLS/connectivity, stable secrets, admin configuration, SMTP egress, and persistent uploads. Transfer existing uploads privately before cutover.
- **Docker and public deployment:** Docker was not installed locally, so the Docker image and hosted Vercel/backend deployments have not been executed. The Maven JAR and static frontend build were verified directly. GitHub upload and remote deployment require the owner's account access and chosen service settings.
- **Browser and responsive layout:** the computer-use helper stopped because it could not confidently determine the current Windows browser URL. Visual QA, interactive browser end-to-end testing, and mobile/tablet screenshots remain unverified. Existing responsive CSS is preserved; code checks and HTTP serving checks do not certify visual layout.
- **External integrations:** map tiles, geocoding, CDN resources, public-domain TLS, email inbox placement, and the business's real GCash/Messenger details need checks from the deployed site. No real financial transfer was performed.

Use the staging/live checklist in [DEPLOYMENT.md](DEPLOYMENT.md) to complete these checks before changing production traffic.
