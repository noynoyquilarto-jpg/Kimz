package com.catering.Saneth.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class simpleController {

    @GetMapping("/test")
    public String hello(){
        return "Hello woasdasdsadrld!";
    }

}
