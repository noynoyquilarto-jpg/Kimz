package com.catering.Saneth.controller;
import com.catering.Saneth.service.NotificationQueue;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/admin/mail") @RequiredArgsConstructor
public class NotificationController {
    private final NotificationQueue queue;
    @GetMapping("/booking/{id}")
    public List<NotificationQueue.Status> status(@PathVariable Long id) { return queue.bookingStatus(id); }
    @PostMapping("/notifications/{id}/retry")
    public NotificationQueue.Status retry(@PathVariable java.util.UUID id) { return queue.retry(id.toString()); }
}
