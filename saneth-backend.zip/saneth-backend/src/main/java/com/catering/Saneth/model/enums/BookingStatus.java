package com.catering.Saneth.model.enums;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    COMPLETED,
    CANCELLED,
    ARCHIVED
}
