import { apiRequest, requireAuth, safe } from './api.js';
import { initLayout } from './layout.js';

requireAuth();
initLayout();

const table = document.getElementById('auditTable');
const message = document.getElementById('auditMessage');
const search = document.getElementById('auditSearch');
const action = document.getElementById('auditAction');
const refresh = document.getElementById('refreshBtn');
const dialog = document.getElementById('auditDialog');
const details = document.getElementById('auditDetails');
let logs = [];
let bookings = new Map();
const activityActions = new Set([
  'CUSTOMER_BOOKING_CREATED', 'PAYMENT_CONFIRMED', 'BOOKING_CONFIRMED', 'BOOKING_CANCELLED'
]);
const actionLabels = {
  CUSTOMER_BOOKING_CREATED: 'Booking Submitted', PAYMENT_CONFIRMED: 'Payment Verified',
  BOOKING_CONFIRMED: 'Booking Confirmed', BOOKING_CANCELLED: 'Booking Cancelled',
  CUSTOMER_FEEDBACK_SUBMITTED: 'Feedback Submitted'
};
const label = value => actionLabels[value] || String(value || '').replaceAll('_', ' ').toLowerCase().replace(/\b\w/g, char => char.toUpperCase());
const timestamp = value => {
  if (!value) return 'Unavailable';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : `${date.toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' })} - ${date.toLocaleTimeString('en-PH', { hour: 'numeric', minute: '2-digit' })}`;
};

function customer(log) {
  const booking = log.targetType === 'BOOKING' ? bookings.get(String(log.targetId)) : null;
  const reference = booking?.bookingReference || log.details?.match(/\bsaneth-\d{4}-\d+\b/i)?.[0];
  const submittedName = log.action === 'CUSTOMER_BOOKING_CREATED' ? log.details?.match(/Customer (.*?) submitted /)?.[1] : null;
  return {
    name: booking?.customerName || submittedName || (log.action.startsWith('CUSTOMER_') ? log.adminEmail : 'Customer unavailable'),
    reference: reference || (log.targetId == null ? label(log.targetType) : `${label(log.targetType)} #${log.targetId}`)
  };
}

function render() {
  const query = search.value.trim().toLowerCase();
  const filtered = logs.filter(log => {
    const person = customer(log);
    return (!action.value || log.action === action.value) &&
      [person.name, person.reference, log.adminEmail, log.action, label(log.action), log.targetType, log.targetId, log.details]
        .some(value => String(value ?? '').toLowerCase().includes(query));
  });
  table.innerHTML = filtered.length ? filtered.map(log => {
    const person = customer(log);
    return `<tr><td><strong>${safe(person.name)}</strong><small>${safe(person.reference)}</small></td><td><strong>${safe(label(log.action))}</strong><small>${safe(timestamp(log.createdAt))}</small></td><td><button class="audit-view" type="button" data-log-id="${safe(log.id)}" aria-label="View ${safe(label(log.action))} details">View</button></td></tr>`;
  }).join('') : '<tr><td colspan="3">No audit logs found.</td></tr>';
  message.textContent = `${filtered.length} of ${logs.length} matching records.`;
}

async function load() {
  refresh.disabled = true;
  message.textContent = 'Loading audit logs...';
  try {
    const [response, bookingResponse] = await Promise.all([
      apiRequest('/api/admin/audit-logs'),
      apiRequest('/api/admin/bookings').catch(() => null)
    ]);
    if (!Array.isArray(response)) throw new Error('Invalid audit log response.');
    logs = response.filter(log => activityActions.has(log.action));
    bookings = new Map((Array.isArray(bookingResponse) ? bookingResponse : []).map(booking => [String(booking.id), booking]));
    render();
  } catch (error) {
    table.innerHTML = '<tr><td colspan="3">Audit logs could not be loaded. Click Refresh to retry.</td></tr>';
    message.textContent = error.message;
  } finally {
    refresh.disabled = false;
  }
}

table.addEventListener('click', event => {
  const button = event.target.closest('button[data-log-id]');
  if (!button) return;
  const log = logs.find(item => String(item.id) === button.dataset.logId);
  if (!log) return;
  const person = customer(log);
  details.innerHTML = Object.entries({
    Customer: person.name, Reference: person.reference, Action: label(log.action),
    'Date & Time': timestamp(log.createdAt),
    Description: log.details || label(log.action)
  }).map(([key, value]) => `<dt>${safe(key)}</dt><dd>${safe(value)}</dd>`).join('');
  dialog.showModal();
});
document.getElementById('closeAuditDialog').addEventListener('click', () => dialog.close());
search.addEventListener('input', render);
action.addEventListener('change', render);
refresh.addEventListener('click', load);
load();
