package com.catering.Saneth.config;

import lombok.RequiredArgsConstructor;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/** Initializes the capacity mutex even when the deployment does not run Flyway. */
@Component
@RequiredArgsConstructor
public class BookingCapacityInitializer implements ApplicationRunner {
    private final JdbcTemplate jdbc;

    @Override
    public void run(ApplicationArguments args) {
        jdbc.execute("CREATE TABLE IF NOT EXISTS booking_capacity_lock (id INTEGER PRIMARY KEY)");
        try {
            jdbc.update("INSERT INTO booking_capacity_lock (id) SELECT 1 WHERE NOT EXISTS (SELECT 1 FROM booking_capacity_lock WHERE id = 1)");
        } catch (DuplicateKeyException ignored) {
            // Another server initialized the same singleton row concurrently.
        }
    }
}
