import { showConfirm as confirm } from '../../js/dialogs.js';
import { apiRequest, uploadImage, requireAuth, peso, badge, safe, assetUrl, API_BASE_URL } from './api.js';
import { initLayout } from './layout.js';

requireAuth();
initLayout();

const form = document.getElementById('packageForm');
const list = document.getElementById('packagesList');
const message = document.getElementById('formMessage');
const resetBtn = document.getElementById('resetBtn');
const refreshBtn = document.getElementById('refreshBtn');
const checkboxes = document.getElementById('menuItemsCheckboxes');
const formTitle = document.getElementById('formTitle');
const imageUrlInput = document.getElementById('imageUrl');
const imageFileInput = document.getElementById('imageFile');
const imageFileName = document.getElementById('imageFileName');
const imagePreview = document.getElementById('imagePreview');

let menuItems = [];
let menuItemsLoaded = false;
let packagesById = new Map();

loadPage();
refreshBtn.addEventListener('click', loadPackages);
resetBtn.addEventListener('click', resetForm);
imageFileInput.addEventListener('change', () => previewSelectedFile(imageFileInput.files[0]));

form.addEventListener('submit', async (event) => {
  event.preventDefault();

  const id = document.getElementById('packageId').value;
  const selectedItemIds = [...document.querySelectorAll('input[name="menuItemIds"]:checked')]
    .map(input => Number(input.value));

  try {
    if (!menuItemsLoaded) {
      throw new Error('Menu items could not be loaded. Refresh the page before saving.');
    }
    if (!selectedItemIds.length) throw new Error('Select at least one menu item for this package.');
    message.textContent = 'Saving...';

    if (imageFileInput.files[0]) {
      message.textContent = 'Uploading image...';
      const upload = await uploadImage(imageFileInput.files[0]);
      imageUrlInput.value = upload.imageUrl;
    }

    if (!imageUrlInput.value) {
      throw new Error('Please choose an image.');
    }

  const body = {
    name: document.getElementById('name').value.trim(),
    description: document.getElementById('description').value.trim(),
    imageUrl: imageUrlInput.value.trim(),
    packagePrice: Number(document.getElementById('packagePrice').value),
    goodForPax: Number(document.getElementById('goodForPax').value),
    available: document.getElementById('available').value === 'true',
    menuItemIds: selectedItemIds
  };

    message.textContent = 'Saving...';
    const saved = await apiRequest(id ? `/api/admin/menu-packages/${id}` : '/api/admin/menu-packages', {
      method: id ? 'PUT' : 'POST',
      body: JSON.stringify(body)
    });
    const savedId = saved?.id ?? id;
    if (savedId) rememberPackageItems(savedId, selectedItemIds);
    message.textContent = id ? 'Package updated.' : 'Package created.';
    resetForm();
    await loadPackages();
  } catch (error) {
    message.textContent = error.message;
  }
});

async function loadPage() {
  await loadMenuItems();
  await loadPackages();
}

async function loadMenuItems() {
  try {
    menuItems = await apiRequest('/api/admin/menu-items');
    menuItemsLoaded = true;
    renderCheckboxes();
  } catch (error) {
    checkboxes.innerHTML = `<div class="empty-state">${safe(error.message)}</div>`;
  }
}

async function loadPackages() {
  list.innerHTML = '<div class="empty-state">Loading packages...</div>';
  try {
    const packages = await apiRequest('/api/menu-packages');
    if (!Array.isArray(packages)) {
      throw new Error('Invalid packages response. Refresh and try again.');
    }

    const packagesWithItems = await Promise.all(packages.map(async pack => {
      const listedItems = getPackageItems(pack);
      if (listedItems?.length) return pack;

      try {
        const items = await apiRequest(`/api/admin/menu-packages/${encodeURIComponent(pack.id)}/items`);
        if (Array.isArray(items)) return { ...pack, items };
      } catch (_) {
        // Older servers only expose menu items through package details.
      }

      try {
        const details = await apiRequest(`/api/menu-packages/${encodeURIComponent(pack.id)}`);
        if (!details || String(details.id) !== String(pack.id) || getPackageItems(details) === null) {
          throw new Error('Package details did not include its menu items.');
        }
        return { ...pack, ...details };
      } catch (error) {
        const rememberedItems = readRememberedPackageItems(pack.id);
        return {
          ...pack,
          ...(rememberedItems ? { items: rememberedItems, rememberedItems: true } : {}),
          itemDetailsError: error.message || 'Could not load menu items.'
        };
      }
    }));

    renderPackages(packagesWithItems);
  } catch (error) {
    list.innerHTML = `<div class="empty-state">${safe(error.message)}</div>`;
  }
}

function rememberPackageItems(id, selectedIds) {
  const items = selectedIds.map(id => menuItems.find(item => String(item.id) === String(id)) || { id });
  try {
    localStorage.setItem(`saneth_package_menu:${API_BASE_URL}:${id}`, JSON.stringify(items));
  } catch (_) {
    // The current page can still display confirmed selections when storage is unavailable.
  }
  const previous = packagesById.get(String(id)) || {};
  packagesById.set(String(id), { ...previous, id, items, rememberedItems: true });
}

function readRememberedPackageItems(id) {
  const current = packagesById.get(String(id));
  if (current?.rememberedItems && Array.isArray(current.items)) return current.items;
  try {
    const items = JSON.parse(localStorage.getItem(`saneth_package_menu:${API_BASE_URL}:${id}`));
    return Array.isArray(items) ? items : null;
  } catch (_) {
    return null;
  }
}

function renderCheckboxes(selectedIds = []) {
  const selected = new Set(selectedIds.map(String));
  if (!menuItems.length) {
    checkboxes.innerHTML = '<div class="empty-state">Create menu items first.</div>';
    return;
  }

  const groups = new Map();
  menuItems.forEach(item => {
    const category = packageMenuCategory(item);
    if (!groups.has(category)) groups.set(category, []);
    groups.get(category).push(item);
  });
  const order = ['Soup', 'Salad and Appetizer', 'Pasta and Noodles', 'Main Courses', 'Dessert', 'Drinks', 'Rice'];
  const rank = name => order.includes(name) ? order.indexOf(name) : order.length;
  checkboxes.innerHTML = [...groups].sort(([a], [b]) => rank(a) - rank(b) || a.localeCompare(b))
    .map(([category, items]) => `
      <fieldset class="package-menu-category">
        <legend>${safe(category)} (Choose ${category === 'Main Courses' ? 4 : 1})</legend>
        <div class="package-menu-options">
          ${items.map(item => `
            <label class="check-item">
              <input type="checkbox" name="menuItemIds" value="${safe(item.id)}" ${selected.has(String(item.id)) ? 'checked' : ''} />
              <span>${safe(item.name)}</span>
            </label>
          `).join('')}
        </div>
      </fieldset>
    `).join('');
}

function packageMenuCategory(item) {
  const name = String(item.name || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  // Match the printed menu, including dishes whose names do not mention their category.
  if (/soup|^(kbl|tinolang manok)$/.test(name)) return 'Soup';
  if (/chocolate cake|crema de fruta|buko pandan|fruit macaroni|fruit salad|tropical fruits|brownies/.test(name)) return 'Dessert';
  if (/salad|lumpia shanghai|cheese sticks|crunchy cheese dog bread rolls|onion rings/.test(name)) return 'Salad and Appetizer';
  if (/sotanghon|pancit|bihon|spaghetti|baked macaroni|lasagna/.test(name)) return 'Pasta and Noodles';
  if (/soft drinks|ice tea|iced tea|lemonade|pineapple juice|four seasons|orange juice|apple juice|dalandan juice/.test(name)) return 'Drinks';
  if (name === 'rice') return 'Rice';

  const category = String(item.categoryName || item.category?.name || '').trim();
  if (/soup/i.test(category)) return 'Soup';
  if (/salad|appetizer/i.test(category)) return 'Salad and Appetizer';
  if (/pasta|noodle/i.test(category)) return 'Pasta and Noodles';
  if (/main|chicken|pork|beef|fish|seafood|vegetable/i.test(category)) return 'Main Courses';
  if (/dessert/i.test(category)) return 'Dessert';
  if (/drink|beverage/i.test(category)) return 'Drinks';
  if (/rice/i.test(category)) return 'Rice';
  if (/chicken|pork|beef|fish|shrimp|chopsuey/.test(name)) return 'Main Courses';
  return category || 'Other Menu Items';
}

function getPackageItems(pack) {
  const itemArrays = [pack.items, pack.menuItems, pack.menuItemIds].filter(Array.isArray);
  const entries = itemArrays.find(items => items.length > 0) || itemArrays[0];
  if (!entries) return null;

  return entries.map(entry => {
    const id = entry && typeof entry === 'object' ? entry.id : entry;
    const item = menuItems.find(candidate => String(candidate.id) === String(id));
    return {
      ...item,
      ...(entry && typeof entry === 'object' ? entry : {}),
      id,
      name: (entry && typeof entry === 'object' ? entry.name : '') || item?.name || `Menu item #${id}`
    };
  });
}

function packageItemsText(pack) {
  const items = getPackageItems(pack);
  if (items === null) {
    return menuItems.length
      ? `<p class="muted">Available menu options — saved selections could not be retrieved.</p>${renderPackageMenuGroups(menuItems)}`
      : '<p class="muted">Menu items could not be loaded. Refresh to try again.</p>';
  }
  if (!items.length) return '<p class="muted">No menu items selected. Edit this package to add its menu.</p>';
  return `${pack.rememberedItems ? '<p class="muted">Last saved selections on this browser.</p>' : ''}${renderPackageMenuGroups(items)}`;
}

function renderPackageMenuGroups(items) {
  const groups = new Map();
  items.forEach(item => {
    const category = packageMenuCategory(item);
    if (!groups.has(category)) groups.set(category, []);
    groups.get(category).push(item.name);
  });
  return [...groups].map(([category, names]) => `
    <div class="package-menu-summary">
      <strong>${safe(category)}</strong>
      <ul>${names.map(name => `<li>${safe(name)}</li>`).join('')}</ul>
    </div>
  `).join('');
}

function renderPackages(packages) {
  packagesById = new Map(packages.map(pack => [String(pack.id), pack]));
  if (!packages.length) {
    list.innerHTML = '<div class="empty-state">No packages yet.</div>';
    return;
  }

  list.innerHTML = packages.map(pack => `
    <article class="item-card">
      ${imageBlock(pack.imageUrl, pack.name)}
      <div>
        <h3>${safe(pack.name)}</h3>
        <div class="card-meta">
          <span class="badge dark">${peso(pack.packagePrice)}</span>
          <span class="badge">Good for ${safe(pack.goodForPax)} pax</span>
          ${badge(pack.available ? 'Available' : 'Unavailable')}
        </div>
        ${renderPackageDescription(pack)}
        <div class="package-menu"><strong>Menu</strong>${packageItemsText(pack)}</div>
        <div class="actions">
          <button type="button" class="btn btn-light btn-small" data-edit="${safe(pack.id)}">Edit</button>
          <button type="button" class="btn btn-danger btn-small" data-delete="${safe(pack.id)}">Delete</button>
        </div>
        <p class="message" role="status" data-package-message></p>
      </div>
    </article>
  `).join('');

  list.querySelectorAll('[data-edit]').forEach(button => {
    button.addEventListener('click', () => editPackage(button.dataset.edit, button));
  });

  list.querySelectorAll('[data-delete]').forEach(button => {
    button.addEventListener('click', () => deletePackage(button.dataset.delete, button));
  });
}

function imageBlock(url, name) {
  if (url) return `<img class="card-image" src="${safe(assetUrl(url))}" alt="${safe(name)}" onerror="this.outerHTML='<div class=&quot;card-placeholder&quot;>No image</div>'" />`;
  return '<div class="card-placeholder">No image</div>';
}

async function editPackage(id, button) {
  if (button.disabled) return;
  button.disabled = true;
  message.textContent = 'Loading package details...';

  try {
    const details = await apiRequest(`/api/menu-packages/${encodeURIComponent(id)}`);
    const pack = { ...packagesById.get(String(id)), ...details };
    if (!pack || String(pack.id) !== String(id)) {
      throw new Error('Could not find this package. Refresh the list and try again.');
    }

    if (!menuItemsLoaded) {
      throw new Error('Menu items could not be loaded. Refresh the page before editing this package.');
    }

    const items = getPackageItems(pack);

    formTitle.textContent = 'Update Package';
    document.getElementById('packageId').value = pack.id;
    document.getElementById('name').value = pack.name || '';
    document.getElementById('description').value = pack.description || '';
    imageUrlInput.value = pack.imageUrl || '';
    imageFileInput.value = '';
    document.getElementById('packagePrice').value = pack.packagePrice ?? '';
    document.getElementById('goodForPax').value = pack.goodForPax ?? '';
    document.getElementById('available').value = String(pack.available !== false);
    imageFileName.textContent = pack.imageUrl ? 'Current image kept' : 'No image selected';
    updateImagePreview(pack.imageUrl || '', pack.name || 'Package preview');
    renderCheckboxes((items || []).map(item => item.id));
    message.textContent = items === null
      ? 'The saved menu items are unavailable. Select the menu items for this package before saving.'
      : '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } catch (error) {
    message.textContent = error.message || 'Could not load this package for editing.';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  } finally {
    button.disabled = false;
  }
}

async function deletePackage(id, button) {
  if (button?.disabled) return;
  if (!await confirm('Delete this package? Existing bookings and feedback will be kept, but detached from this package.')) return;
  const status = button?.closest('.item-card')?.querySelector('[data-package-message]');
  if (button) button.disabled = true;
  if (status) status.textContent = 'Deleting package...';
  try {
    await apiRequest(`/api/admin/menu-packages/${encodeURIComponent(id)}`, { method: 'DELETE' });
    packagesById.delete(String(id));
    try { localStorage.removeItem(`saneth_package_menu:${API_BASE_URL}:${id}`); } catch (_) {}
    if (String(document.getElementById('packageId').value) === String(id)) resetForm();
    message.textContent = 'Package deleted. Existing bookings and feedback were kept.';
    await loadPackages();
  } catch (error) {
    message.textContent = error.message || 'Could not delete this package.';
    if (status) status.textContent = message.textContent;
  } finally {
    if (button) button.disabled = false;
  }
}

function resetForm() {
  formTitle.textContent = 'Create Package';
  form.reset();
  document.getElementById('packageId').value = '';
  imageFileInput.value = '';
  imageUrlInput.value = '';
  imageFileName.textContent = 'No image selected';
  document.getElementById('available').value = 'true';
  updateImagePreview('');
  renderCheckboxes();
}

function previewSelectedFile(file) {
  if (!file) {
    imageFileName.textContent = imageUrlInput.value ? 'Current image kept' : 'No image selected';
    updateImagePreview(imageUrlInput.value);
    return;
  }

  imageFileName.textContent = file.name;
  const localUrl = URL.createObjectURL(file);
  updateImagePreview(localUrl, file.name);
}

function updateImagePreview(url, altText = 'Package preview') {
  const cleanUrl = String(url || '').trim();

  if (!cleanUrl) {
    imagePreview.className = 'image-preview empty';
    imagePreview.textContent = 'No image selected';
    return;
  }

  imagePreview.className = 'image-preview';
  imagePreview.innerHTML = `<img src="${safe(assetUrl(cleanUrl))}" alt="${safe(altText)}" onerror="this.parentElement.className='image-preview empty'; this.parentElement.textContent='Image not found';" />`;
}

function renderPackageDescription(pkg) {
  const description = String(pkg.description || '').trim();
  if (!/^package\s+[abc]$/i.test(String(pkg.name || '').trim()) || !description) {
    return `<p class="package-desc">${safe(description || 'A complete catering package for your event.')}</p>`;
  }
  const inclusions = description.replace(/^inclusions?\s*:?\s*/i, '')
    .split(/[;\r\n]+|,\s*:/)
    .map(item => item.replace(/^[\s:•-]+|[\s,;]+$/g, '').trim())
    .filter(Boolean);
  return `<div class="package-desc package-inclusions"><strong>Inclusions</strong><ul>${inclusions.map(item => `<li>${safe(item)}</li>`).join('')}</ul></div>`;
}