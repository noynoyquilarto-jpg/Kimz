package com.catering.Saneth.service;
import com.catering.Saneth.model.Booking;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.List;

@Service @RequiredArgsConstructor @Transactional
public class BookingTrackingEmailService {
    private final EmailService email;
    private final NotificationQueue queue;
    public List<NotificationQueue.Status> status(Long bookingId) { return queue.bookingStatus(bookingId); }
    public void sendAfterBookingSaved(Booking booking) { sendAfterBookingSaved(booking, List.of()); }
    public void sendAfterBookingSaved(Booking booking, List<String> names) { email.sendBookingAcknowledgement(booking, names); }
    public void sendAfterBookingConfirmed(Booking booking, Number quote, Number required) { sendAfterBookingConfirmed(booking, quote, required, List.of()); }
    public void sendAfterBookingConfirmed(Booking booking, Number quote, Number required, List<String> names) {
        if (quote == null || required == null || new BigDecimal(quote.toString()).signum() <= 0
                || new BigDecimal(required.toString()).signum() < 0 || new BigDecimal(required.toString()).compareTo(new BigDecimal(quote.toString())) > 0)
            throw new IllegalArgumentException("Valid approved quote and required down payment are required.");
        email.sendBookingConfirmationEmail(booking, names);
    }
    /** Repeated requests share the durable event; true only means prior SMTP acceptance. */
    public boolean resendConfirmation(Booking booking, List<String> names) {
        email.retryBookingConfirmationEmail(booking, names);
        return queue.accepted("CONFIRMATION:" + booking.getId());
    }
}
