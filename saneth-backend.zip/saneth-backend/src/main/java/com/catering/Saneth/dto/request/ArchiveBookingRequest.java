package com.catering.Saneth.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ArchiveBookingRequest {

    @NotBlank(message = "Archive reason is required")
    private String reason;
}