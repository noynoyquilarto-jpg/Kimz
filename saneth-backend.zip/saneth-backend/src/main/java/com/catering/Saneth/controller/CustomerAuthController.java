package com.catering.Saneth.controller;
import com.catering.Saneth.model.Customer;
import com.catering.Saneth.repository.CustomerRepo;
import com.catering.Saneth.security.JwtService;
import com.catering.Saneth.service.RateLimitService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/customer/auth") @RequiredArgsConstructor
public class CustomerAuthController {
 private final CustomerRepo repo;
 private final com.catering.Saneth.service.CustomerVerificationService verification;
 private final PasswordEncoder encoder;
 private final JwtService jwt;
 private final RateLimitService limits;
 private final com.catering.Saneth.service.NotificationQueue notifications;
 public record RegisterRequest(@NotBlank @Size(max=100) String firstName,@NotBlank @Size(max=100) String lastName,
   @NotBlank @Email @Size(max=255) String email,@NotBlank @Size(min=8) String password,
   @NotBlank String confirmPassword) {
  @Override public String toString() { return "RegisterRequest[credentials redacted]"; }
 }
 public record LoginRequest(@NotBlank @Email @Size(max=255) String email,@NotBlank String password) {
  @Override public String toString() { return "LoginRequest[credentials redacted]"; }
 }
 public record AuthResponse(String token,String role,String firstName,String lastName,String email) {}
 @PostMapping("/register") public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest r,HttpServletRequest request){
  limits.check(request,"customer-register",5,java.time.Duration.ofMinutes(15));
  String email=r.email().trim().toLowerCase(Locale.ROOT);
  if(!r.password().equals(r.confirmPassword()))return ResponseEntity.badRequest().body(Map.of("message","Passwords do not match"));
  if(repo.existsByEmailIgnoreCase(email))return ResponseEntity.status(409).body(Map.of("message","Email is already registered"));
  Customer c=new Customer();c.setFirstName(r.firstName().trim());c.setLastName(r.lastName().trim());c.setEmail(email);c.setPassword(encoder.encode(r.password()));
  String notificationId;
  try {notificationId=verification.register(c);}catch(DataIntegrityViolationException e){return ResponseEntity.status(409).body(Map.of("message","Email is already registered"));}
  return ResponseEntity.status(201).body(Map.of("message","Registration successful! Your verification code is queued for sending.",
    "notificationId",notificationId,"email",email,"verificationStatus","UNVERIFIED","expiresInSeconds",300,"resendCooldownSeconds",60));
 }
 public record VerifyRequest(@NotBlank @Email String email, @NotBlank @Pattern(regexp="[0-9]{6}") String code) {
  @Override public String toString() { return "VerifyRequest[code redacted]"; }
 }
 public record ResendRequest(@NotBlank @Email String email) {}
 @PostMapping("/verify") public ResponseEntity<?> verify(@Valid @RequestBody VerifyRequest r,HttpServletRequest request) {
  limits.check(request,"customer-verify",20,java.time.Duration.ofMinutes(15));
  boolean valid=verification.verify(r.email().trim().toLowerCase(Locale.ROOT),r.code());
  if(valid) return ResponseEntity.ok(Map.of("message","Email verified successfully. You can now sign in.","verificationStatus","VERIFIED"));
  return ResponseEntity.badRequest().body(Map.of("message","Invalid or expired code. Request a new code if needed."));
 }
 @PostMapping("/resend") public ResponseEntity<?> resend(@Valid @RequestBody ResendRequest r,HttpServletRequest request) {
  limits.check(request,"customer-resend",5,java.time.Duration.ofMinutes(15));
  String id=verification.resend(r.email().trim().toLowerCase(Locale.ROOT));
  Map<String,Object> result=new LinkedHashMap<>();
  result.put("message","If your account needs verification, a new code is queued for sending.");
  if(id!=null) result.put("notificationId",id);
  return ResponseEntity.ok(result);
 }
 @GetMapping("/notifications/{id}") public com.catering.Saneth.service.NotificationQueue.Status notification(@PathVariable java.util.UUID id,HttpServletRequest request) {
  limits.check(request,"otp-delivery-status",120,java.time.Duration.ofMinutes(10));
  return notifications.otpStatus(id.toString());
 }
 @PostMapping("/login") public ResponseEntity<?> login(@Valid @RequestBody LoginRequest r,HttpServletRequest request){
  limits.check(request,"customer-login",6,java.time.Duration.ofMinutes(10));
  String email=r.email().trim().toLowerCase(Locale.ROOT);
  limits.checkKey("customer-login:email:"+email,6,java.time.Duration.ofMinutes(15));
  Optional<Customer> found=repo.findByEmailIgnoreCase(email);
  if(found.isEmpty() || !encoder.matches(r.password(),found.get().getPassword()))return ResponseEntity.status(401).body(Map.of("message","Invalid email or password"));
  Customer c=found.get(); if(!c.isEmailVerified()) return ResponseEntity.status(403).body(Map.of("message","Please verify your email before signing in")); return ResponseEntity.ok(new AuthResponse(jwt.generateToken(c.getEmail(),"CUSTOMER"),"CUSTOMER",c.getFirstName(),c.getLastName(),c.getEmail()));
 }
}
