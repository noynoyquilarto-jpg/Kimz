package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.*;
import com.catering.Saneth.model.*;
import com.catering.Saneth.model.enums.*;
import com.catering.Saneth.repository.*;
import jakarta.mail.*;
import jakarta.mail.internet.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.transaction.*;
import org.springframework.transaction.support.TransactionTemplate;
import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest(properties = "saneth.mail.enabled=true") @AutoConfigureMockMvc
class NotificationWorkflowTest {
    @Autowired NotificationQueue queue;
    @Autowired NotificationDispatcher dispatcher;
    @Autowired EmailNotificationRepo notifications;
    @Autowired BookingRepo bookings;
    @Autowired BookingPaymentRepo records;
    @Autowired CustomerRepo customers;
    @Autowired EmailService email;
    @Autowired PaymentService payments;
    @Autowired AdminBookingService admin;
    @Autowired CustomerVerificationService verification;
    @Autowired PlatformTransactionManager manager;
    @Autowired NotificationCipher cipher;
    @MockitoBean JavaMailSender smtp;
    TransactionTemplate tx;
    @BeforeEach void setup() {
        tx = new TransactionTemplate(manager);
        when(smtp.createMimeMessage()).thenAnswer(invocation -> new MimeMessage(Session.getInstance(new Properties())));
    }
    Booking booking() {
        return bookings.saveAndFlush(Booking.builder().bookingReference("EMAIL-" + UUID.randomUUID()).customerName("Customer <One>")
                .email("customer+mail@gmail.com").phoneNumber("09123456789").customerAddress("Iloilo")
                .eventPlace("Function hall").eventDate(LocalDate.now().plusDays(500)).eventTime(LocalTime.of(17,0))
                .eventType("Birthday").numberOfPax(50).bookingType(BookingType.CUSTOM).quotedPrice(new BigDecimal("10000"))
                .downPayment(new BigDecimal("3000")).downPaymentAmount(0.0).bookingStatus(BookingStatus.CONFIRMED)
                .paymentStatus(PaymentStatus.AWAITING_PAYMENT).build());
    }
    PaymentRecordRequest request(double amount, String ref) {
        var request = new PaymentRecordRequest(); request.setAmount(amount); request.setPaymentMethod(PaymentMethod.GCASH);
        request.setPaymentReferenceNumber(ref); request.setSubmissionKey(UUID.randomUUID().toString()); return request;
    }
    @Test void rollbackRemovesNotificationAndUncommittedRowsCannotSend() {
        String key = "ROLLBACK:" + UUID.randomUUID();
        tx.executeWithoutResult(status -> {
            String id = queue.enqueue(key, "ACKNOWLEDGEMENT", null, null, null, "customer@gmail.com", "Test", "Body", "<p>Body</p>");
            dispatcher.deliver(id);
            verifyNoInteractions(smtp);
            status.setRollbackOnly();
        });
        assertThat(notifications.findByEventKey(key)).isEmpty();
    }
    @Test void encryptedQueueDeduplicatesAndOnlyReportsSentAfterSmtpAccepts() throws Exception {
        var booking = booking();
        tx.executeWithoutResult(status -> { email.sendBookingConfirmationEmail(booking); email.sendBookingConfirmationEmail(booking); });
        var rows = notifications.findByBookingIdOrderByCreatedAtDesc(booking.getId());
        assertThat(rows).hasSize(1);
        var row = rows.getFirst();
        assertThat(row.getEncryptedContent()).doesNotContain("customer", "10000", "Customer");
        assertThat(queue.bookingStatus(booking.getId()).getFirst().status()).isEqualTo("QUEUED");
        verifyNoInteractions(smtp);
        dispatcher.deliver(row.getId()); dispatcher.deliver(row.getId());
        var message = org.mockito.ArgumentCaptor.forClass(MimeMessage.class);
        verify(smtp, times(1)).send(message.capture());
        var from = (InternetAddress)message.getValue().getFrom()[0];
        assertThat(message.getValue().isMimeType("multipart/alternative")).isTrue();
        assertThat(message.getValue().getSentDate()).isNotNull();
        assertThat(message.getValue().getHeader("Auto-Submitted", null)).isEqualTo("auto-generated");
        assertThat(from.getAddress()).isEqualTo("test@example.invalid"); assertThat(from.getPersonal()).isEqualTo("Saneth Catering");
        assertThat(body(message.getValue(), "text/plain")).contains("PHP 10000.00", "PHP 3000.00", "GCash", "customer%2Bmail%40gmail.com");
        assertThat(body(message.getValue(), "text/html")).contains("&lt;One&gt;").doesNotContain("<One>");
        assertThat(queue.bookingStatus(booking.getId()).getFirst().status()).isEqualTo("SMTP_ACCEPTED");
        assertThat(notifications.findById(row.getId()).orElseThrow().getEncryptedContent()).isNull();
        queue.retry(row.getId()); dispatcher.deliver(row.getId()); verify(smtp, times(1)).send(any(MimeMessage.class));
    }
    @Test void pendingSubmissionDoesNotCountAsPaidAndRepeatedVerificationQueuesOneReceipt() {
        var booking = booking(); var request = request(3000, "PARTIAL-REF");
        var pending = payments.submitPayment(booking.getBookingReference(), booking.getEmail(), request);
        assertThat(pending.getVerificationStatus()).isEqualTo("PENDING_VERIFICATION");
        assertThat(payments.getPaymentByBookingId(booking.getId()).getTotalPaid()).isZero();
        assertThat(queue.bookingStatus(booking.getId())).isEmpty();
        assertThat(payments.submitPayment(booking.getBookingReference(), booking.getEmail(), request).getId()).isEqualTo(pending.getId());
        var verified = payments.verifyPayment(booking.getId(), pending.getId());
        assertThat(verified.getTotalPaid()).isEqualTo(3000.0); assertThat(verified.getRemainingBalance()).isEqualTo(7000.0);
        payments.verifyPayment(booking.getId(), pending.getId());
        assertThat(queue.bookingStatus(booking.getId())).hasSize(1);
        String first = queue.bookingStatus(booking.getId()).getFirst().id();
        assertThat(NotificationQueue.unpack(cipher.decrypt(notifications.findById(first).orElseThrow().getEncryptedContent()))[2])
                .contains("PHP 7000.00", "partial payment receipt", "Verification date:", "PARTIAL-REF");
        var finalRequest = request(7000, "FINAL-REF");
        var finalPending = payments.submitPayment(booking.getBookingReference(), booking.getEmail(), finalRequest);
        var fullyPaid = payments.verifyPayment(booking.getId(), finalPending.getId());
        assertThat(fullyPaid.getPaymentStatus()).isEqualTo(PaymentStatus.FULLY_PAID); assertThat(fullyPaid.getRemainingBalance()).isZero();
        assertThat(queue.bookingStatus(booking.getId())).hasSize(2);
        // A repeated admin add using the same transaction reference cannot increase totals or send another receipt.
        var replay = payments.addPayment(booking.getId(), finalRequest);
        assertThat(replay.getTotalPaid()).isEqualTo(10000.0); assertThat(queue.bookingStatus(booking.getId())).hasSize(2);
    }
    @Test void smtpFailurePreservesPaymentAndRetriesTheSameNotification() {
        var booking = booking(); payments.addPayment(booking.getId(), request(3000, "RETRY-REF"));
        String id = queue.bookingStatus(booking.getId()).getFirst().id();
        doThrow(new org.springframework.mail.MailSendException("sensitive provider detail must never be logged"))
                .when(smtp).send(any(MimeMessage.class));
        dispatcher.deliver(id);
        assertThat(queue.bookingStatus(booking.getId()).getFirst().status()).isEqualTo("RETRY_PENDING");
        assertThat(payments.getPaymentByBookingId(booking.getId()).getTotalPaid()).isEqualTo(3000.0);
        assertThat(records.findByBookingIdOrderByCreatedAtAsc(booking.getId())).hasSize(1);
        tx.executeWithoutResult(s -> notifications.findById(id).orElseThrow().setNextAttemptAt(Instant.now().minusSeconds(1)));
        doNothing().when(smtp).send(any(MimeMessage.class)); dispatcher.deliver(id);
        assertThat(queue.bookingStatus(booking.getId()).getFirst().status()).isEqualTo("SMTP_ACCEPTED");
        assertThat(notifications.findById(id).orElseThrow().getAttempts()).isEqualTo(2);
    }
    @Test void expiredOtpIsNeverSentAndResendCancelsOldQueuedOtp() {
        var c = new Customer(); c.setFirstName("OTP"); c.setLastName("Customer"); c.setEmail(UUID.randomUUID()+"@example.invalid"); c.setPassword("hash");
        String id = verification.register(c);
        assertThat(notifications.findById(id).orElseThrow().getEncryptedContent()).doesNotContain(c.getVerificationHash());
        tx.executeWithoutResult(s -> notifications.findById(id).orElseThrow().setExpiresAt(Instant.now().minusSeconds(1)));
        dispatcher.deliver(id); verifyNoInteractions(smtp);
        assertThat(notifications.findById(id).orElseThrow().getStatus()).isEqualTo("EXPIRED");
        tx.executeWithoutResult(s -> customers.findById(c.getId()).orElseThrow().setVerificationSentAt(Instant.now().minusSeconds(61)));
        String old = verification.resend(c.getEmail());
        tx.executeWithoutResult(s -> customers.findById(c.getId()).orElseThrow().setVerificationSentAt(Instant.now().minusSeconds(61)));
        String current = verification.resend(c.getEmail());
        assertThat(current).isNotEqualTo(old);
        assertThat(notifications.findById(old).orElseThrow().getStatus()).isEqualTo("CANCELLED");
        assertThat(notifications.findById(old).orElseThrow().getEncryptedContent()).isNull();
        dispatcher.deliver(old); verifyNoInteractions(smtp);
    }
    @Test void adminApprovalQueuesOneConfirmationWithApprovedAmounts() {
        var b = booking(); b.setBookingStatus(BookingStatus.PENDING); b.setEventDate(LocalDate.now().plusDays(700)); bookings.saveAndFlush(b);
        var request = new ConfirmBookingRequest(); request.setQuotedPrice(new BigDecimal("12345")); request.setDownPayment(new BigDecimal("3703.50"));
        admin.confirmBooking(b.getId(), request);
        assertThat(queue.bookingStatus(b.getId())).hasSize(1);
        String id = queue.bookingStatus(b.getId()).getFirst().id();
        assertThat(NotificationQueue.unpack(cipher.decrypt(notifications.findById(id).orElseThrow().getEncryptedContent()))[2])
                .contains("PHP 12345.00", "PHP 3703.50", "Booking status: CONFIRMED");
        assertThatThrownBy(() -> admin.confirmBooking(b.getId(), request)).isInstanceOf(RuntimeException.class);
        assertThat(queue.bookingStatus(b.getId())).hasSize(1);
    }
    @Test void pendingBookingAcknowledgementIsNotLabeledConfirmed() {
        var b = booking(); b.setBookingStatus(BookingStatus.PENDING);
        tx.executeWithoutResult(s -> email.sendBookingAcknowledgement(b, List.of("Rice", "Chicken")));
        var row = notifications.findByBookingIdOrderByCreatedAtDesc(b.getId()).getFirst();
        String text = NotificationQueue.unpack(cipher.decrypt(row.getEncryptedContent()))[2];
        assertThat(text).contains("PENDING", "awaiting admin review", "Guest count: 50", "Rice", "Chicken", "Custom menu")
                .doesNotContain("Your booking has been confirmed");
    }
    @Test void cannotSubmitPaymentForAnotherCustomer() {
        var b=booking();
        assertThatThrownBy(() -> payments.submitPayment(b.getBookingReference(), "another@gmail.com", request(3000,"OTHER"))).isInstanceOf(RuntimeException.class);
        assertThat(records.findByBookingIdOrderByCreatedAtAsc(b.getId())).isEmpty();
    }
    @Test void concurrentWorkersCannotSendTheSameClaimTwice() throws Exception {
        var b=booking(); tx.executeWithoutResult(s -> email.sendBookingConfirmationEmail(b));
        String id=queue.bookingStatus(b.getId()).getFirst().id();
        var sending=new java.util.concurrent.CountDownLatch(1); var release=new java.util.concurrent.CountDownLatch(1);
        doAnswer(call -> { sending.countDown(); if (!release.await(10, java.util.concurrent.TimeUnit.SECONDS)) throw new IllegalStateException("Test timeout"); return null; })
                .when(smtp).send(any(MimeMessage.class));
        try (var executor=java.util.concurrent.Executors.newSingleThreadExecutor()) {
            var first=executor.submit(() -> dispatcher.deliver(id));
            try { assertThat(sending.await(5,java.util.concurrent.TimeUnit.SECONDS)).isTrue(); dispatcher.deliver(id); }
            finally { release.countDown(); }
            first.get(10,java.util.concurrent.TimeUnit.SECONDS);
        }
        verify(smtp,times(1)).send(any(MimeMessage.class));
        assertThat(queue.bookingStatus(b.getId()).getFirst().status()).isEqualTo("SMTP_ACCEPTED");
        assertThat(notifications.findById(id).orElseThrow().getAttempts()).isEqualTo(1);
    }
    @Test void abandonedLeaseIsRecoveredAfterRestart() {
        var b=booking(); tx.executeWithoutResult(s -> email.sendBookingConfirmationEmail(b));
        String id=queue.bookingStatus(b.getId()).getFirst().id();
        tx.executeWithoutResult(s -> { var row=notifications.findById(id).orElseThrow(); row.setStatus("SENDING"); row.setLeaseToken(UUID.randomUUID().toString()); row.setNextAttemptAt(Instant.now().minusSeconds(1)); });
        dispatcher.deliver(id);
        assertThat(queue.bookingStatus(b.getId()).getFirst().status()).isEqualTo("SMTP_ACCEPTED");
        verify(smtp,times(1)).send(any(MimeMessage.class));
    }
    @Test void terminalFailureCanBeRetriedWithoutDuplicatingAcceptedMail() {
        var b=booking(); tx.executeWithoutResult(s -> email.sendBookingConfirmationEmail(b));
        String id=queue.bookingStatus(b.getId()).getFirst().id();
        doThrow(new org.springframework.mail.MailAuthenticationException("provider text omitted")).when(smtp).send(any(MimeMessage.class));
        for(int attempt=0;attempt<12;attempt++) {
            tx.executeWithoutResult(s -> notifications.findById(id).orElseThrow().setNextAttemptAt(Instant.now().minusSeconds(1)));
            dispatcher.deliver(id);
        }
        assertThat(queue.bookingStatus(b.getId()).getFirst().status()).isEqualTo("FAILED");
        dispatcher.deliver(id); verify(smtp,times(12)).send(any(MimeMessage.class));
        doNothing().when(smtp).send(any(MimeMessage.class)); queue.retry(id); dispatcher.deliver(id);
        queue.retry(id); dispatcher.deliver(id);
        assertThat(queue.bookingStatus(b.getId()).getFirst().status()).isEqualTo("SMTP_ACCEPTED");
        verify(smtp,times(13)).send(any(MimeMessage.class));
    }
    @Test void adminConfirmationEmailRetryRecoversFailedNotificationWithoutSendingAcceptedMailAgain() {
        var b = booking();
        tx.executeWithoutResult(s -> email.sendBookingConfirmationEmail(b));
        String id = queue.bookingStatus(b.getId()).getFirst().id();
        tx.executeWithoutResult(s -> {
            var n = notifications.findById(id).orElseThrow();
            n.setStatus("FAILED"); n.setAttempts(12);
        });
        assertThat(admin.sendConfirmationEmail(b.getId())).isFalse();
        assertThat(queue.bookingStatus(b.getId())).hasSize(1);
        assertThat(notifications.findById(id).orElseThrow().getStatus()).isEqualTo("QUEUED");
        dispatcher.deliver(id);
        assertThat(admin.sendConfirmationEmail(b.getId())).isTrue();
        dispatcher.deliver(id);
        assertThat(queue.bookingStatus(b.getId())).hasSize(1);
        verify(smtp, times(1)).send(any(MimeMessage.class));
    }
    @Test void rejectedSubmissionDoesNotChangeTotalsOrSendReceipt() {
        var b=booking(); var pending=payments.submitPayment(b.getBookingReference(), b.getEmail(), request(3000,"REJECT"));
        var response=payments.rejectSubmittedPayment(b.getId(), pending.getId(), "Funds not received");
        assertThat(response.getTotalPaid()).isZero(); assertThat(response.getPayments().getFirst().getVerificationStatus()).isEqualTo("REJECTED");
        assertThatThrownBy(() -> payments.verifyPayment(b.getId(), pending.getId())).isInstanceOf(RuntimeException.class);
        assertThat(queue.bookingStatus(b.getId())).isEmpty();
    }
    @Test void otpResendLimitPersistsAcrossRequestsWithoutCreatingAnotherCustomer() {
        var c = new Customer(); c.setFirstName("Limit"); c.setLastName("Test");
        c.setEmail(UUID.randomUUID()+"@example.invalid"); c.setPassword("hash");
        verification.register(c);
        for (int i=0; i<4; i++) {
            tx.executeWithoutResult(s -> customers.findById(c.getId()).orElseThrow().setVerificationSentAt(Instant.now().minusSeconds(61)));
            verification.resend(c.getEmail());
        }
        tx.executeWithoutResult(s -> customers.findById(c.getId()).orElseThrow().setVerificationSentAt(Instant.now().minusSeconds(61)));
        assertThatThrownBy(() -> verification.resend(c.getEmail()))
                .isInstanceOf(com.catering.Saneth.exception.RateLimitException.class);
        assertThat(notifications.countByCustomerIdAndKindAndCreatedAtAfter(c.getId(), "OTP", Instant.now().minusSeconds(900))).isEqualTo(5);
        assertThat(customers.findByEmailIgnoreCase(c.getEmail()).orElseThrow().getId()).isEqualTo(c.getId());
    }
    static String body(Part part, String type) throws Exception {
        if (part.isMimeType(type)) return part.getContent().toString();
        if (part.getContent() instanceof Multipart multipart) for (int i=0;i<multipart.getCount();i++) {
            String text=body(multipart.getBodyPart(i),type); if(!text.isEmpty()) return text;
        }
        return "";
    }
}
