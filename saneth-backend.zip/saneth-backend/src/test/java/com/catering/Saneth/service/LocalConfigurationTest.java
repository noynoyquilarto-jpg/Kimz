package com.catering.Saneth.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.ConfigDataApplicationContextInitializer;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

class LocalConfigurationTest {
    @Test void explicitlySelectedLocalFileResolvesWithoutMachineSpecificPaths() throws Exception {
        String config = java.nio.file.Path.of("src/main/resources/application.properties").toAbsolutePath().toUri().toString();
        var local = java.nio.file.Files.createTempFile("saneth-test-config-", ".properties");
        try {
            java.nio.file.Files.writeString(local, "saneth.jwt.secret=test-only-external-secret-longer-than-32-characters\nsaneth.admin.email=config@example.invalid\n");
            new ApplicationContextRunner()
                .withPropertyValues("spring.config.location=" + config, "SANETH_LOCAL_CONFIG=" + local.toAbsolutePath().toString().replace('\\', '/'))
                .withInitializer(new ConfigDataApplicationContextInitializer())
                .run(context -> {
                    var environment = context.getEnvironment();
                    String secret = environment.getProperty("saneth.jwt.secret");
                    assertTrue(secret != null && secret.length() >= 32);
                    assertEquals("config@example.invalid", environment.getProperty("saneth.admin.email"));
                });
        } finally { java.nio.file.Files.deleteIfExists(local); }
    }
}
