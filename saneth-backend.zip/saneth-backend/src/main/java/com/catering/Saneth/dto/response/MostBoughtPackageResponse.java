package com.catering.Saneth.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class MostBoughtPackageResponse {
    private Long packageId;
    private String packageName;
    private Long totalBookings;

}
