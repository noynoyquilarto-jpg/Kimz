package com.catering.Saneth.dto.response;

import lombok.*;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MenuItemResponse {

    private Long id;

    private String name;

    private String description;

    private String imageUrl;

    private Long categoryId;
    private String categoryName;

    private Long subCategoryId;
    private String subCategoryName;

    private Boolean available;
}


