import { apiRequest, safe, setResult, clearResult, assetUrl } from './customer-api.js';
import { initCustomerLayout } from './customer-layout.js';

initCustomerLayout();

const bookingForm = document.getElementById('bookingForm');
const eventPlaceInput = document.getElementById('eventPlace');
const mapStatus = document.getElementById('mapStatus');
const mapResults = document.getElementById('mapResults');
const eventLocationNote = document.getElementById('eventLocationNote');
const customMenuCategories = document.getElementById('customMenuCategories');
const bookingResult = document.getElementById('bookingResult');
const eventDateInput = document.getElementById('eventDate');
let submitting = false;
let availabilityVersion = 0;
let availabilityState = 'empty';
const dateAvailability = document.getElementById('dateAvailability');
const availabilitySimulation = document.getElementById('availabilitySimulation');
let latestAvailability = null;
let previewBooked = null;
let availabilityRequest = null;
let availabilityRetryAt = 0;
function updateSubmitAvailability() {
  const button = bookingForm?.querySelector('button[type="submit"]');
  if (button) button.disabled = submitting || availabilityState !== 'available';
  const continueButton = dateAvailability?.querySelector('[data-availability-action="continue"]');
  if (continueButton) continueButton.disabled = submitting || availabilityState !== 'available'
    || dateAvailability.dataset.displayState === 'full';
}
function renderDateAvailability(date, data, preview = false) {
  const capacity = Math.max(1, Number(data.capacity) || 3);
  const booked = Math.max(0, Number(data.booked) || 0);
  const remaining = Math.max(0, capacity - booked);
  const full = remaining === 0;
  const dateLabel = new Intl.DateTimeFormat('en-PH', { month: 'long', day: 'numeric', year: 'numeric' })
    .format(new Date(`${date}T00:00:00`));
  const calendar = (occupied) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="5" width="16" height="16" rx="2"/><path d="M16 3v4M8 3v4M4 11h16"/>${occupied ? '<path d="m9 16 2 2 4-4"/>' : '<path d="M12 14v5m-2.5-2.5h5"/>'}</svg>`;
  dateAvailability.innerHTML = `
    <div class="availability-heading"><strong>Saneth Catering &mdash; Booking Availability</strong><span class="availability-badge">${preview ? 'Preview: ' : ''}${full ? 'Fully Booked' : 'Available'}</span></div>
    <p class="availability-date">Event date: ${safe(dateLabel)}</p>
    <div class="availability-slots">${Array.from({ length: capacity }, (_, index) => {
      const occupied = index < booked;
      return `<div class="availability-slot${occupied ? ' is-booked' : ''}" aria-label="Slot ${index + 1}: ${occupied ? 'Booked' : 'Open'}">${calendar(occupied)}<span>${occupied ? 'Booked' : 'Open'}</span><small>Slot ${index + 1}</small></div>`;
    }).join('')}</div>
    <div class="availability-count"><span>Confirmed and completed bookings</span><strong>${booked} / ${capacity}</strong></div>
    <div class="availability-progress" role="progressbar" aria-label="Daily booking capacity used" aria-valuemin="0" aria-valuemax="${capacity}" aria-valuenow="${Math.min(booked, capacity)}"><span style="width:${Math.min(100, booked / capacity * 100)}%"></span></div>
    <p class="availability-remaining">${full ? 'Fully Booked. Please select another date.' : `${remaining} booking slot${remaining === 1 ? '' : 's'} remaining.`}</p>
    <small class="availability-note">Pending requests do not reserve a slot. Availability updates after admin confirmation.${preview ? ' Simulation only; actual availability is checked before submission.' : ''}</small>
    <div class="availability-footer"><span>${full ? 'Choose another available event date.' : 'You can continue to request a booking.'}</span><button type="button" data-availability-action="continue" ${full ? 'disabled' : ''}>Continue Booking</button></div>`;
  availabilitySimulation.hidden = false;
  availabilitySimulation.innerHTML = `<h3>Admin confirmation simulation</h3>
    <p>Preview how the indicator changes when the admin confirms or cancels a booking. This is a local demo only: it does not connect to your MySQL database.</p>
    <div class="simulation-actions">
      <button type="button" data-availability-action="confirm" ${booked >= capacity ? 'disabled' : ''}>+ Confirm Booking</button>
      <button type="button" data-availability-action="cancel" ${booked <= 0 ? 'disabled' : ''}>&minus; Cancel Confirmed Booking</button>
      <button type="button" data-availability-action="reset" ${preview ? '' : 'disabled'}>Reset This Date</button>
    </div>`;
  dateAvailability.dataset.date = date;
  dateAvailability.dataset.displayState = full ? 'full' : 'available';
}

document.getElementById('availabilitySection')?.addEventListener('click', event => {
  const button = event.target.closest('button[data-availability-action]');
  if (button?.dataset.availabilityAction === 'retry') {
    refreshDateAvailability();
    return;
  }
  if (!button || button.disabled || !latestAvailability) return;
  const { date, data } = latestAvailability;
  const action = button.dataset.availabilityAction;
  if (action === 'continue') {
    const target = selectedPackage ? bookingForm.querySelector('button[type="submit"]')
      : document.getElementById('customMenuSection');
    target?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    const focusTarget = selectedPackage ? target : target?.querySelector('input, button');
    focusTarget?.focus({ preventScroll: true });
    return;
  }
  if (action === 'reset') {
    previewBooked = null;
    renderDateAvailability(date, data);
  } else {
    previewBooked = Math.max(0, Math.min(data.capacity,
      (previewBooked ?? data.booked) + (action === 'confirm' ? 1 : -1)));
    renderDateAvailability(date, { ...data, booked: previewBooked, available: previewBooked < data.capacity }, true);
  }
  updateSubmitAvailability();
  const next = availabilitySimulation.querySelector(`[data-availability-action="${action}"]:not(:disabled)`)
    || availabilitySimulation.querySelector('button:not(:disabled)');
  next?.focus();
});

async function refreshDateAvailability({ background = false } = {}) {
  const date = eventDateInput?.value;
  const hasLiveData = latestAvailability?.date === date;
  if (Date.now() < availabilityRetryAt && hasLiveData && background) return false;
  // Share an active check instead of letting polling and window focus overlap.
  if (availabilityRequest?.date === date) return availabilityRequest.promise;
  availabilityRequest?.controller.abort();
  const controller = new AbortController();
  const version = ++availabilityVersion;
  if (!background || !hasLiveData) availabilityState = date ? 'checking' : 'empty';
  dateAvailability.dataset.state = availabilityState;
  if (!date || dateAvailability.dataset.date !== date) {
    dateAvailability.textContent = date ? 'Checking date availability...' : 'Select an event date to check availability.';
    dateAvailability.dataset.date = '';
    latestAvailability = null;
    previewBooked = null;
    availabilitySimulation.hidden = true;
  }
  updateSubmitAvailability();
  if (!date) {
    availabilityRequest = null;
    return false;
  }
  const request = { date, controller, promise: null };
  availabilityRequest = request;
  request.promise = (async () => {
  const timeout = setTimeout(() => controller.abort(), 12000);
  try {
    const data = await apiRequest(`/api/bookings/availability?date=${encodeURIComponent(date)}`, {
      cache: 'no-store', signal: controller.signal
    });
    if (version !== availabilityVersion) return false;
    availabilityState = Number(data.booked) < (Number(data.capacity) || 3) ? 'available' : 'full';
    latestAvailability = { date, data };
    availabilityRetryAt = 0;
    previewBooked = null;
    renderDateAvailability(date, data);
  } catch (error) {
    if (version !== availabilityVersion) return false;
    availabilityRetryAt = Date.now() + (error.retryAfterSeconds || 15) * 1000;
    const message = error.name === 'AbortError'
      ? 'The availability check took too long. Please try again. Your form details are saved on this page.'
      : `Unable to check availability. ${error.message}`;
    if (hasLiveData) {
      previewBooked = null;
      renderDateAvailability(date, latestAvailability.data);
      // Keep the last result visible while the customer finishes the form.
      // Submission still requires a successful fresh check.
      availabilityState = background
        ? (Number(latestAvailability.data.booked) < Number(latestAvailability.data.capacity) ? 'available' : 'full')
        : 'error';
      dateAvailability.insertAdjacentHTML('beforeend', `<p class="availability-note">${safe(message)} Last checked availability is shown.</p>`);
    } else {
      availabilityState = 'error';
      dateAvailability.textContent = message;
    }
    dateAvailability.insertAdjacentHTML('beforeend', '<button type="button" data-availability-action="retry">Retry availability</button>');
    return false;
  } finally {
    clearTimeout(timeout);
    if (availabilityRequest === request) availabilityRequest = null;
    if (version === availabilityVersion) {
      dateAvailability.dataset.state = availabilityState;
      updateSubmitAvailability();
    }
  }
  return availabilityState === 'available';
  })();
  return request.promise;
}
const requestedPackageId = new URLSearchParams(window.location.search).get('packageId');
let selectedPackage = null;
let packageReady = !requestedPackageId;

async function loadRequestedPackage() {
  if (!requestedPackageId) return;
  const summary = document.getElementById('bookingPackageSummary');
  summary.hidden = false;
  summary.textContent = 'Loading selected package...';
  try {
    const packages = await apiRequest('/api/menu-packages');
    selectedPackage = (packages || []).find(pack => String(pack.id) === requestedPackageId && pack.available !== false);
    if (!selectedPackage) throw new Error('This package is unavailable. Please choose another package.');
    summary.textContent = '';
    summary.hidden = true;
    document.getElementById('customMenuSection').closest('.field').hidden = true;
    const pax = document.getElementById('numberOfPax');
    pax.min = selectedPackage.goodForPax || 1;
    if (Number(pax.value) < Number(pax.min)) pax.value = pax.min;
    packageReady = true;
  } catch (error) {
    summary.textContent = error.message;
  }
}

function updateMinimumDate() {
  const date = new Date();
  date.setDate(date.getDate() + 3);
  eventDateInput.min = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

// ============================================================
// MAP SETUP
// ============================================================

const DEFAULT_CENTER = [10.3157, 123.8854]; // Cebu City
const DEFAULT_ZOOM = 12;

let map = null;
let marker = null;
let selectedLat = null;
let selectedLon = null;

function initMap() {
  const mapEl = document.getElementById('eventMap');

  if (!mapEl || typeof L === 'undefined') {
    showMapStatus('Map failed to load. You can still type your event place above.', 'error');
    return;
  }

  map = L.map(mapEl).setView(DEFAULT_CENTER, DEFAULT_ZOOM);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors',
    maxZoom: 19
  }).addTo(map);

  map.on('click', event => {
    setPin(event.latlng.lat, event.latlng.lng);
  });
}

function setPin(lat, lon) {
  selectedLat = lat;
  selectedLon = lon;

  if (!map) return;

  if (!marker) {
    marker = L.marker([lat, lon], { draggable: true }).addTo(map);

    marker.on('dragend', () => {
      const position = marker.getLatLng();
      selectedLat = position.lat;
      selectedLon = position.lng;
      showMapStatus(
        `Pin set at ${position.lat.toFixed(5)}, ${position.lng.toFixed(5)}. Drag to adjust.`,
        'success'
      );
    });
  } else {
    marker.setLatLng([lat, lon]);
  }

  map.setView([lat, lon], Math.max(map.getZoom(), 16));
  showMapStatus(
    `Pin set at ${lat.toFixed(5)}, ${lon.toFixed(5)}. Drag the marker to fine-tune, or tap elsewhere to move it.`,
    'success'
  );
}

function resetMapPin() {
  selectedLat = null;
  selectedLon = null;

  if (marker && map) {
    map.removeLayer(marker);
    marker = null;
  }

  if (map) {
    map.setView(DEFAULT_CENTER, DEFAULT_ZOOM);
  }

  showMapStatus('Type above to search, or manually tap the map to drop the pin.');

  if (mapResults) mapResults.innerHTML = '';
}

function showMapStatus(message, type = '') {
  if (!mapStatus) return;
  mapStatus.textContent = message;
  mapStatus.className = `map-status ${type}`.trim();
}

// ============================================================
// ADDRESS SEARCH (OpenStreetMap Nominatim)
// ============================================================

document.getElementById('searchPlaceBtn')?.addEventListener('click', () => {
  const query = eventPlaceInput.value.trim();

  if (query.length < 3) {
    if (mapResults) mapResults.innerHTML = '';
    return;
  }

  searchPlace(query);
});

async function searchPlace(query) {
  if (!mapResults) return;

  try {
    const url =
      'https://nominatim.openstreetmap.org/search' +
      `?format=json&addressdetails=0&limit=5&countrycodes=ph&q=${encodeURIComponent(query)}`;

    const response = await fetch(url);
    const results = await response.json();

    if (!results.length) {
      mapResults.innerHTML = '<p>No matches found. Try a different search or tap the map instead.</p>';
      return;
    }

    mapResults.innerHTML = `
      <p>Suggestions</p>
      <div class="map-result-list">
        ${results.map((result, index) => `
          <button type="button" class="map-result-btn" data-index="${index}">
            ${safe(result.display_name)}
          </button>
        `).join('')}
      </div>
    `;

    mapResults.querySelectorAll('.map-result-btn').forEach(button => {
      button.addEventListener('click', () => {
        const result = results[Number(button.dataset.index)];
        selectSearchResult(result);
      });
    });
  } catch (error) {
    mapResults.innerHTML = '<p>Search is unavailable right now. You can still tap the map to drop a pin.</p>';
  }
}

function selectSearchResult(result) {
  const lat = Number(result.lat);
  const lon = Number(result.lon);

  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return;

  setPin(lat, lon);
  if (mapResults) mapResults.innerHTML = '';
}

// ============================================================
// CUSTOM MENU BUILDER
// ============================================================

async function loadCustomMenu() {
  if (!customMenuCategories) return;

  customMenuCategories.innerHTML = '<div class="skeleton">Loading menu...</div>';

  try {
    const items = await apiRequest('/api/menu-items');
    const available = (items || []).filter(item => item.available !== false);

    if (!available.length) {
      customMenuCategories.innerHTML = '<div class="skeleton">No menu items available right now.</div>';
      return;
    }

    const categories = groupByCategory(available);
    customMenuCategories.innerHTML = categories.map(renderCategory).join('');

    wireCategoryToggles();
    wireCategorySearch();
    wireMenuCardSelection();
  } catch (error) {
    customMenuCategories.innerHTML = `<div class="skeleton">${safe(error.message)}</div>`;
  }
}

function groupByCategory(items) {
  const categoryMap = new Map();

  items.forEach(item => {
    const categoryName = item.categoryName || 'Other';

    if (!categoryMap.has(categoryName)) {
      categoryMap.set(categoryName, new Map());
    }

    const subMap = categoryMap.get(categoryName);
    const subCategoryName = item.subCategoryName || '';

    if (!subMap.has(subCategoryName)) {
      subMap.set(subCategoryName, []);
    }

    subMap.get(subCategoryName).push(item);
  });

  return Array.from(categoryMap.entries()).map(([categoryName, subMap]) => ({
    categoryName,
    subcategories: Array.from(subMap.entries()).map(([subCategoryName, subItems]) => ({
      subCategoryName,
      items: subItems
    }))
  }));
}

function renderCategory(category, index) {
  const isMainCourse = /^main\s+courses?$/i.test(category.categoryName.trim());
  const choiceCount = isMainCourse ? 4 : 1;
  return `
    <div class="menu-category" data-choice-limit="${choiceCount}">
      <button type="button" class="menu-category-title" data-category-index="${index}">
        <span>${safe(category.categoryName)} (Choose ${choiceCount})</span>
      </button>
      <div class="menu-category-content">
        ${isMainCourse ? `<label class="menu-category-search" for="menu-search-${index}">
          <span>Search ${safe(category.categoryName)}</span>
          <input type="search" id="menu-search-${index}" placeholder="Search dishes by name or description..." autocomplete="off">
        </label>` : ''}
        <p class="menu-selection-status" role="status" aria-live="polite">0 of ${choiceCount} selected.</p>
        ${category.subcategories.map(sub => `
          <div class="menu-subcategory">
          ${sub.subCategoryName ? `<h4 class="menu-subcategory-title">${safe(sub.subCategoryName)}</h4>` : ''}
          <div class="menu-grid">
            ${sub.items.map(renderMenuCard).join('')}
          </div>
          </div>
        `).join('')}
        <p class="menu-search-empty" role="status" aria-live="polite" hidden>No dishes match your search.</p>
      </div>
    </div>
  `;
}

function renderMenuCard(item) {
  const imageSrc = item.imageUrl ? assetUrl(item.imageUrl) : '';

  return `
    <div class="menu-card" data-item-id="${item.id}" role="button" tabindex="0" aria-pressed="false">
      ${imageSrc ? `<img src="${safe(imageSrc)}" alt="${safe(item.name)}" loading="lazy">` : ''}
      <div class="menu-card-body">
        <h4>${safe(item.name)}</h4>
        <p>${safe(item.description || '')}</p>
      </div>
    </div>
  `;
}

function wireCategoryToggles() {
  const titles = customMenuCategories.querySelectorAll('.menu-category-title');
  const setExpanded = (button, expanded) => {
    button.classList.toggle('open', expanded);
    button.setAttribute('aria-expanded', String(expanded));
    button.nextElementSibling?.classList.toggle('open', expanded);
  };

  titles.forEach((button, index) => {
    // Open the first category by default so the picker isn't empty-looking.
    setExpanded(button, index === 0);
    button.addEventListener('click', () => {
      const shouldOpen = !button.classList.contains('open');
      titles.forEach(title => setExpanded(title, title === button && shouldOpen));
    });
  });
}

function wireCategorySearch() {
  customMenuCategories.querySelectorAll('.menu-category').forEach(category => {
    const input = category.querySelector('input[type="search"]');
    if (!input) return;
    const filter = () => {
      const query = input.value.trim().toLocaleLowerCase();
      let matches = 0;
      category.querySelectorAll('.menu-subcategory').forEach(group => {
        let groupMatches = 0;
        group.querySelectorAll('.menu-card').forEach(card => {
          const text = card.querySelector('.menu-card-body').textContent.toLocaleLowerCase();
          card.hidden = !text.includes(query);
          if (!card.hidden) groupMatches++;
        });
        group.hidden = groupMatches === 0;
        matches += groupMatches;
      });
      category.querySelector('.menu-search-empty').hidden = matches > 0;
    };
    input.addEventListener('input', filter);
    // Prevent Enter in a search field from submitting the booking form.
    input.addEventListener('keydown', event => {
      if (event.key === 'Enter') event.preventDefault();
    });
    customMenuCategories.addEventListener('menu-selection-reset', () => {
      input.value = '';
      filter();
    });
  });
}

function wireMenuCardSelection() {
  // Keep selection order so a fifth main dish replaces the oldest choice.
  const selectionOrder = new Map();
  const toggleSelection = card => {
    const category = card.closest('.menu-category');
    const limit = Number(category.dataset.choiceLimit) || 1;
    const selected = selectionOrder.get(category) || [];
    const existingIndex = selected.indexOf(card);
    if (existingIndex >= 0) {
      selected.splice(existingIndex, 1);
      card.classList.remove('selected');
    } else {
      while (selected.length >= limit) selected.shift().classList.remove('selected');
      selected.push(card);
      card.classList.add('selected');
    }
    selectionOrder.set(category, selected);
    updateMenuSelectionState(category);
  };
  customMenuCategories.querySelectorAll('.menu-card').forEach(card => {
    card.addEventListener('click', () => toggleSelection(card));

    card.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        toggleSelection(card);
      }
    });
  });
  // A form reset must also clear the order used for automatic replacement.
  customMenuCategories.addEventListener('menu-selection-reset', () => selectionOrder.clear());
}

function updateMenuSelectionState(category) {
  const limit = Number(category.dataset.choiceLimit) || 1;
  const count = category.querySelectorAll('.menu-card.selected').length;
  const full = count >= limit;
  category.querySelectorAll('.menu-card').forEach(card => {
    const selected = card.classList.contains('selected');
    card.classList.toggle('selection-full', full && !selected);
    card.setAttribute('aria-pressed', String(selected));
    card.title = full && !selected
      ? (limit === 1 ? 'Choose this dish to replace your selection.' : 'Choose this dish to replace your earliest selected dish.')
      : '';
  });
  category.querySelector('.menu-selection-status').textContent = `${count} of ${limit} selected.${full
    ? (limit === 1 ? ' Choose another dish to replace your selection.' : ' Choose another dish to replace your earliest selected dish.')
    : ''}`;
}

function resetMenuSelection() {
  customMenuCategories
    ?.querySelectorAll('.menu-card.selected')
    .forEach(card => card.classList.remove('selected'));
  customMenuCategories?.dispatchEvent(new Event('menu-selection-reset'));
  customMenuCategories?.querySelectorAll('.menu-category').forEach(updateMenuSelectionState);
}

// ============================================================
// SUBMIT BOOKING
// ============================================================

async function submitBooking(event) {
  event.preventDefault();
  if (submitting) return;
  if (!packageReady) {
    setResult(bookingResult, 'The selected package is not ready. Reload the page or choose an available package.', 'error');
    return;
  }

  const selectedItemIds = Array.from(
    customMenuCategories?.querySelectorAll('.menu-card.selected') || []
  ).map(card => Number(card.dataset.itemId));

  if (!selectedPackage && !selectedItemIds.length) {
    setResult(bookingResult, 'Please select at least one menu item.', 'error');
    return;
  }

  const form = new FormData(bookingForm);

  const placeName = String(form.get('eventPlace') || '').trim();
  const locationNote = String(form.get('eventLocationNote') || '').trim();

  const eventPlaceParts = [
    placeName || 'Event place'
  ];
  if (selectedLat !== null && selectedLon !== null) eventPlaceParts.push(`pin:${selectedLat},${selectedLon}`);

  if (locationNote) {
    eventPlaceParts.push(`note:${locationNote}`);
  }

  const body = {
    customerName: form.get('customerName'),
    email: String(form.get('email') || '').trim(),
    phoneNumber: form.get('phoneNumber'),
    customerAddress: form.get('customerAddress'),
    eventPlace: eventPlaceParts.join(' | '),
    eventDate: form.get('eventDate'),
    eventTime: form.get('eventTime'),
    eventType: form.get('eventType'),
    numberOfPax: Number(form.get('numberOfPax')),
    bookingType: selectedPackage ? 'PACKAGE' : 'CUSTOM',
    menuPackageId: selectedPackage ? selectedPackage.id : null,
    menuItemIds: selectedPackage ? [] : selectedItemIds
  };

  const submitBtn = bookingForm.querySelector('button[type="submit"]');
  submitting = true;
  if (submitBtn) submitBtn.disabled = true;

  setResult(bookingResult, 'Submitting your booking...', 'success');

  try {
    if (!await refreshDateAvailability()) {
      setResult(bookingResult, availabilityState === 'full'
        ? 'This event date is fully booked. Please choose another date.'
        : 'Availability could not be verified. Your form is unchanged. Retry availability, then submit again.', 'error');
      return;
    }
    const data = await apiRequest('/api/bookings', {
      method: 'POST',
      body: JSON.stringify(body)
    });

    const trackingQuery = new URLSearchParams({ ref: data.bookingReference, email: body.email });
    setResult(
      bookingResult,
      `<strong>Booking submitted â€” awaiting confirmation</strong><br>Your reference is <strong>${safe(data.bookingReference)}</strong>. Save this to track your booking status.<br>Your booking is pending admin approval. After the admin confirms it, the system sends a confirmation to <strong>${safe(body.email)}</strong>. A payment receipt is sent after your payment is verified.<br>Use the tracking link below to check your current status, even if an email does not arrive.<br><a href="track-booking.html?${safe(trackingQuery.toString())}">Track your booking</a>`,
      'success'
    );

    bookingForm.reset();
    if (selectedPackage) document.getElementById('numberOfPax').value = selectedPackage.goodForPax;
    resetMenuSelection();
    resetMapPin();

    if (eventDateInput) {
      updateMinimumDate();
      refreshDateAvailability();
    }
  } catch (error) {
    setResult(bookingResult, safe(error.message), 'error');
  } finally {
    submitting = false;
    updateSubmitAvailability();
  }
}

// ============================================================
// INIT
// ============================================================

if (eventDateInput) {
  updateMinimumDate();
}

eventDateInput?.addEventListener('change', refreshDateAvailability);
window.addEventListener('focus', () => { if (!submitting) refreshDateAvailability({ background: true }); });
setInterval(() => {
  if (!document.hidden && !submitting && eventDateInput?.value) refreshDateAvailability({ background: true });
}, 15000);
refreshDateAvailability();
bookingForm?.addEventListener('submit', submitBooking);

initMap();
loadCustomMenu();
loadRequestedPackage();
