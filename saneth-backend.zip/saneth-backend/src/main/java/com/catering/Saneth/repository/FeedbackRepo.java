package com.catering.Saneth.repository;

import com.catering.Saneth.dto.response.MustTryPackageResponse;
import com.catering.Saneth.model.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeedbackRepo extends JpaRepository<Feedback, Long> {

    @Modifying
    @Query("UPDATE Feedback f SET f.menuPackage = null WHERE f.menuPackage.id = :packageId")
    int detachMenuPackage(@org.springframework.data.repository.query.Param("packageId") Long packageId);

    boolean existsByBookingId(Long bookingId);

    @Query("""
            SELECT new com.catering.Saneth.dto.response.MustTryPackageResponse(
                f.menuPackage.id,
                f.menuPackage.name,
                AVG(f.rating),
                COUNT(f.id)
            )
            FROM Feedback f
            GROUP BY f.menuPackage.id, f.menuPackage.name
            ORDER BY AVG(f.rating) DESC, COUNT(f.id) DESC
            """)
    List<MustTryPackageResponse> findMustTryPackages();
}
