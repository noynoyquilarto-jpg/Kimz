package com.catering.Saneth.dto.request;

import com.catering.Saneth.model.enums.BookingType;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Getter
@Setter
public class BookingRequest {

    @NotBlank(message = "Customer name is required")
    private String customerName;

    @Email(message = "Email must be valid")
    @NotBlank(message = "Email is required")
    private String email;

    @NotBlank(message = "Phone number is required")
    @Pattern(
            regexp = "^(09|\\+639)\\d{9}$",
            message = "Phone number must be a valid PH mobile number"
    )
    private String phoneNumber;

    @NotBlank(message = "Customer address is required")
    private String customerAddress;

    @NotBlank(message = "Event place is required")
    @Size(max = 1000, message = "Event place must be at most 1000 characters")
    private String eventPlace;

    @NotNull(message = "Event date is required")
    private LocalDate eventDate;

    @NotNull(message = "Event time is required")
    private LocalTime eventTime;

    @NotBlank(message = "Event type is required")
    private String eventType;

    @NotNull(message = "Number of pax is required")
    @Positive(message = "Number of pax must be greater than zero")
    @Max(value = 500, message = "Number of pax cannot exceed 500")
    private Integer numberOfPax;

    @NotNull(message = "Booking type is required")
    private BookingType bookingType;

    // Used only when bookingType = PACKAGE
    private Long menuPackageId;

    // Used only when bookingType = CUSTOM
    private List<Long> menuItemIds;

    private Boolean projector;

    private Boolean videoke;

    private Boolean lechon;

    private Boolean cake;

    @Size(max = 500)
    private String specialRequest;

    private BigDecimal quotedPrice;

    private BigDecimal downPayment;

}
