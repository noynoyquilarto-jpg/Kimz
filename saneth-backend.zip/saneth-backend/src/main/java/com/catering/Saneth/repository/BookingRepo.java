package com.catering.Saneth.repository;

import com.catering.Saneth.dto.response.MostBoughtPackageResponse;
import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.model.enums.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookingRepo extends JpaRepository<Booking, Long> {
    @Modifying
    @Query("UPDATE Booking b SET b.menuPackage = null WHERE b.menuPackage.id = :packageId")
    int detachMenuPackage(@org.springframework.data.repository.query.Param("packageId") Long packageId);

    @Query("""
            SELECT b FROM Booking b
            WHERE LOWER(TRIM(b.bookingReference)) = LOWER(TRIM(:reference))
              AND LOWER(TRIM(b.email)) = LOWER(TRIM(:email))
            """)
    Optional<Booking> findByBookingReferenceAndEmail(
            @org.springframework.data.repository.query.Param("reference") String reference,
            @org.springframework.data.repository.query.Param("email") String email);

    @org.springframework.data.jpa.repository.Lock(jakarta.persistence.LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT b FROM Booking b WHERE b.id = :id")
    Optional<Booking> findForUpdateById(@org.springframework.data.repository.query.Param("id") Long id);

    @Query("""
            SELECT new com.catering.Saneth.dto.response.MostBoughtPackageResponse(
                p.id,
                p.name,
                COUNT(b.id)
            )
            FROM Booking b JOIN b.menuPackage p
            GROUP BY p.id, p.name
            ORDER BY COUNT(b.id) DESC, p.name ASC, p.id ASC
            """)
    List<MostBoughtPackageResponse> findMostBoughtPackages();

    @Query(value = "SELECT id FROM booking_capacity_lock WHERE id = 1 FOR UPDATE", nativeQuery = true)
    Integer lockDailyCapacity();
    @Query("""
            SELECT COUNT(b) FROM Booking b WHERE b.eventDate = :date
            AND (b.bookingStatus IN :statuses OR
                (b.bookingStatus = com.catering.Saneth.model.enums.BookingStatus.ARCHIVED
                 AND b.statusBeforeArchive = com.catering.Saneth.model.enums.BookingStatus.COMPLETED))
            """)
    long countByEventDateAndBookingStatusIn(@org.springframework.data.repository.query.Param("date") LocalDate date,
            @org.springframework.data.repository.query.Param("statuses") List<BookingStatus> statuses);

    @Query("""
            SELECT COUNT(b) FROM Booking b WHERE b.eventDate = :date AND b.id <> :id
            AND (b.bookingStatus IN :statuses OR
                (b.bookingStatus = com.catering.Saneth.model.enums.BookingStatus.ARCHIVED
                 AND b.statusBeforeArchive = com.catering.Saneth.model.enums.BookingStatus.COMPLETED))
            """)
    long countByEventDateAndBookingStatusInAndIdNot(@org.springframework.data.repository.query.Param("date") LocalDate date,
            @org.springframework.data.repository.query.Param("statuses") List<BookingStatus> statuses,
            @org.springframework.data.repository.query.Param("id") Long id);

    Long countByBookingStatus(com.catering.Saneth.model.enums.BookingStatus status);

    @Query("""
    SELECT COALESCE(SUM(b.downPaymentAmount), 0)
    FROM Booking b
    WHERE b.paymentStatus = com.catering.Saneth.model.enums.PaymentStatus.DOWN_PAYMENT_CONFIRMED
       OR b.paymentStatus = com.catering.Saneth.model.enums.PaymentStatus.FULLY_PAID
    """)
    Double getTotalSales();

    List<Booking> findByBookingStatus(BookingStatus status);

    List<Booking> findByPaymentStatusIn(List<PaymentStatus> statuses);

    List<Booking> findByBookingStatusNot(BookingStatus status);

    List<Booking> findByBookingStatusNotOrderByCreatedAtDesc(BookingStatus status);

    Long countByBookingStatusNot(BookingStatus status);

    boolean existsByEventDateAndBookingStatusInAndEmailIgnoreCaseOrEventDateAndBookingStatusInAndPhoneNumber(
            LocalDate eventDateForEmail,
            List<BookingStatus> bookingStatusesForEmail,
            String email,
            LocalDate eventDateForPhone,
            List<BookingStatus> bookingStatusesForPhone,
            String phoneNumber
    );

    boolean existsByEventDateAndEventTimeAndBookingStatusAndIdNot(
            LocalDate eventDate,
            LocalTime eventTime,
            BookingStatus bookingStatus,
            Long id
    );

}
