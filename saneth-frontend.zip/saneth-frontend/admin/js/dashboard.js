import { apiRequest, requireAuth, peso, badge, safe } from './api.js';
import { initLayout } from './layout.js';
import { createPackageRankingLoader } from './most-bought-packages.js';

requireAuth();
initLayout();

const totalBookings = document.getElementById('totalBookings');
const pendingBookings = document.getElementById('pendingBookings');
const confirmedBookings = document.getElementById('confirmedBookings');
const completedBookings = document.getElementById('completedBookings');
const cancelledBookings = document.getElementById('cancelledBookings');
const totalSales = document.getElementById('totalSales');

const latestBookingsTable = document.getElementById('latestBookingsTable');
const mostBoughtList = document.getElementById('mostBoughtList');
const loadMostBoughtPackages = createPackageRankingLoader(
  mostBoughtList, document.getElementById('refreshPackagesBtn'), false
);

loadDashboard();

async function loadDashboard() {
  await Promise.all([
    loadAnalytics(),
    loadLatestBookings(),
    loadMostBoughtPackages()
  ]);
}

async function loadAnalytics() {
  try {
    const data = await apiRequest('/api/admin/analytics/dashboard');

    totalBookings.textContent = data.totalBookings || 0;
    pendingBookings.textContent = data.pendingBookings || 0;
    confirmedBookings.textContent = data.confirmedBookings || 0;
    completedBookings.textContent = data.completedBookings || 0;
    cancelledBookings.textContent = data.cancelledBookings || 0;
    totalSales.textContent = peso(data.totalSales || 0);
  } catch (error) {
    console.error(error);
  }
}

async function loadLatestBookings() {
  latestBookingsTable.innerHTML = '<tr><td colspan="5">Loading latest bookings...</td></tr>';

  try {
    const bookings = await apiRequest('/api/admin/bookings');

    const latest = (bookings || []).slice(0, 5);

    if (!latest.length) {
      latestBookingsTable.innerHTML = '<tr><td colspan="5">No bookings found.</td></tr>';
      return;
    }

    latestBookingsTable.innerHTML = latest.map(booking => `
      <tr>
        <td><strong>${safe(booking.bookingReference)}</strong></td>

        <td>
          ${safe(booking.customerName)}<br>
          <span class="muted">${safe(booking.email)}</span>
        </td>

        <td>
          ${safe(booking.eventType)}<br>
          <span class="muted">${safe(booking.eventDate)} ${safe(booking.eventTime)}</span>
        </td>

        <td>${badge(booking.bookingStatus)}</td>
        <td>${badge(booking.paymentStatus)}</td>
      </tr>
    `).join('');
  } catch (error) {
    latestBookingsTable.innerHTML = `<tr><td colspan="5">${safe(error.message)}</td></tr>`;
  }
}
