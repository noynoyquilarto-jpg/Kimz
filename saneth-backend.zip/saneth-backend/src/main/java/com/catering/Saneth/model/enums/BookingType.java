package com.catering.Saneth.model.enums;

public enum BookingType {
    PACKAGE,
    CUSTOM
}