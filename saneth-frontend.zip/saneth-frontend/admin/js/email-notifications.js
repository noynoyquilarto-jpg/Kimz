import { apiRequest, safe } from './api.js';

export function emailNotices(notifications = []) {
  return notifications.map(n => `<p class="muted">${safe(n.message)}</p>`).join('');
}
export async function watchEmail(bookingId, kind, report) {
  for (let attempt = 0; attempt < 12; attempt++) {
    await new Promise(resolve => setTimeout(resolve, 5000));
    try {
      const notifications = await apiRequest(`/api/admin/mail/booking/${bookingId}`, { redirectOnAuthFailure: false });
      const notification = notifications.find(n => n.kind === kind);
      if (!notification) return;
      report(notification.message);
      if (['SMTP_ACCEPTED', 'FAILED', 'DISABLED', 'EXPIRED', 'CANCELLED'].includes(notification.status)) return;
    } catch { report('Email status is unavailable. Refresh to check; the saved transaction remains valid.'); return; }
  }
}
