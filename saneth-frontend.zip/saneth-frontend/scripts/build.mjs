import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { check } from './check.mjs';

export const root = fileURLToPath(new URL('../', import.meta.url));

export function publicConfig(env = process.env) {
  const raw = (env.SANETH_API_BASE_URL || '').trim();
  const production = env.VERCEL === '1' || env.NODE_ENV === 'production';
  if (!raw && production) throw new Error('Set SANETH_API_BASE_URL to your backend HTTPS origin before deploying.');
  if (!raw) return { apiBaseUrl: '' };
  const url = new URL(raw);
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash ||
      !['', '/', '/api', '/api/'].includes(url.pathname)) {
    throw new Error('SANETH_API_BASE_URL must be an HTTP(S) backend origin, optionally ending with /api.');
  }
  if (production && (url.protocol !== 'https:' || /^(localhost|127\.|\[::1\])/.test(url.hostname))) {
    throw new Error('Production SANETH_API_BASE_URL must use a public HTTPS backend.');
  }
  return { apiBaseUrl: url.origin };
}

export async function build(env = process.env) {
  const settings = publicConfig(env);
  await check();
  const output = path.join(root, 'dist');
  if (path.dirname(output) !== path.resolve(root)) throw new Error('Build output must stay inside this repository.');
  // This fixed generated directory always stays inside this frontend repository.
  await fs.rm(output, { recursive: true, force: true });
  await fs.mkdir(output, { recursive: true });
  for (const name of ['index.html', 'admin', 'customer', 'css', 'js']) {
    await fs.cp(path.join(root, name), path.join(output, name), {
      recursive: true,
      filter: async source => {
        const relative = path.relative(root, source).replaceAll('\\', '/');
        if (relative.split('/').some(part => part.startsWith('.') || ['tests', 'node_modules', 'coverage'].includes(part))) return false;
        return (await fs.stat(source)).isDirectory() || /\.(?:html|css|js|mjs|jpe?g|png|gif|webp|svg|ico|avif|woff2?|ttf|otf|mp4|webm)$/i.test(source);
      }
    });
  }
  await fs.writeFile(path.join(output, 'js/runtime-config.js'),
    `window.SANETH_CONFIG = Object.freeze(${JSON.stringify(settings)});\n`);
  console.log('Frontend build complete: dist/');
  return output;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  await build();
}
