package com.catering.Saneth.repository;

import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.BookingMenuItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookingMenuItemRepo extends JpaRepository<BookingMenuItem, Long> {

    List<BookingMenuItem> findByBooking(Booking booking);

    void deleteByBooking(Booking booking);

}