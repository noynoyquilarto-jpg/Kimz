package com.catering.Saneth.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class MenuSubCategoryResponse {

    private Long id;

    private String name;

    private Long categoryId;

    private String categoryName;
}