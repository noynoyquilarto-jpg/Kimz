package com.catering.Saneth;

import com.catering.Saneth.model.*;
import com.catering.Saneth.repository.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import tools.jackson.databind.ObjectMapper;
import java.time.LocalDate;
import java.util.Map;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class BookingLifecycleTest {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;
    @Autowired MenuCategoryRepo categories;
    @Autowired MenuRepo items;
    @Autowired BookingRepo bookings;

    @Test
    void customBookingCanBeQuotedPaidTrackedReviewedArchivedAndDeleted() throws Exception {
        String login = mvc.perform(post("/api/admin/auth/login").contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"admin@example.invalid\",\"password\":\"TestAdminPassword123\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String auth = "Bearer " + json.readTree(login).get("token").asText();
        var category = categories.save(MenuCategory.builder().name("Lifecycle mains").build());
        var item = items.save(MenuItem.builder().name("Chicken").category(category)
                .available(true).imageUrl("/test.jpg").build());
        String body = bookingBody(item.getId(), "lifecycle+test@example.invalid");
        String created = mvc.perform(post("/api/bookings").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().is2xxSuccessful()).andExpect(jsonPath("$.customMenuItems[0].name").value("Chicken"))
                .andReturn().getResponse().getContentAsString();
        long id = json.readTree(created).get("id").asLong();
        String reference = json.readTree(created).get("bookingReference").asText();
        mvc.perform(put("/api/admin/bookings/" + id + "/confirm").header("Authorization", auth)
                .contentType(MediaType.APPLICATION_JSON).content("{\"quotedPrice\":1000,\"downPayment\":300}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.balance").value(1000));
        mvc.perform(put("/api/admin/bookings/" + id + "/confirm").header("Authorization", auth)
                .contentType(MediaType.APPLICATION_JSON).content("{\"quotedPrice\":1000,\"downPayment\":300}"))
                .andExpect(status().isBadRequest());
        mvc.perform(post("/api/admin/payments/booking/" + id + "/payments").header("Authorization", auth)
                .contentType(MediaType.APPLICATION_JSON).content("{\"amount\":300,\"paymentMethod\":\"CASH\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.remainingBalance").value(700));
        mvc.perform(put("/api/admin/bookings/" + id + "/complete").header("Authorization", auth))
                .andExpect(status().isBadRequest());
        mvc.perform(post("/api/admin/payments/booking/" + id + "/payments").header("Authorization", auth)
                .contentType(MediaType.APPLICATION_JSON).content("{\"amount\":701,\"paymentMethod\":\"CASH\"}"))
                .andExpect(status().isBadRequest());
        mvc.perform(post("/api/admin/payments/booking/" + id + "/payments").header("Authorization", auth)
                .contentType(MediaType.APPLICATION_JSON).content("{\"amount\":700,\"paymentMethod\":\"CASH\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.paymentStatus").value("FULLY_PAID"))
                .andExpect(jsonPath("$.totalPaid").value(1000));
        mvc.perform(post("/api/bookings/track").contentType(MediaType.APPLICATION_JSON)
                .content(json.writeValueAsString(Map.of("bookingReference", reference.toLowerCase(),
                        "email", "LIFECYCLE+TEST@example.invalid"))))
                .andExpect(status().isOk()).andExpect(jsonPath("$.balance").value(0))
                .andExpect(jsonPath("$.requiredDownPayment").value(300));
        // Completion requires the event to have taken place; advance this fixture to a past date.
        Booking pastEvent = bookings.findById(id).orElseThrow();
        pastEvent.setEventDate(LocalDate.now(java.time.ZoneId.of("Asia/Manila")).minusDays(1));
        bookings.saveAndFlush(pastEvent);
        mvc.perform(put("/api/admin/bookings/" + id + "/complete").header("Authorization", auth))
                .andExpect(status().isOk()).andExpect(jsonPath("$.bookingStatus").value("COMPLETED"));
        String feedback = json.writeValueAsString(Map.of("bookingReference", reference,
                "email", "lifecycle+test@example.invalid", "rating", 5, "comment", "Great service"));
        mvc.perform(post("/api/feedbacks").contentType(MediaType.APPLICATION_JSON).content(feedback))
                .andExpect(status().is2xxSuccessful());
        mvc.perform(post("/api/feedbacks").contentType(MediaType.APPLICATION_JSON).content(feedback))
                .andExpect(status().isBadRequest());
        mvc.perform(put("/api/admin/archives/bookings/" + id).header("Authorization", auth)
                .contentType(MediaType.APPLICATION_JSON).content("{\"reason\":\"Completed test\"}"))
                .andExpect(status().isOk());
        mvc.perform(delete("/api/admin/archives/bookings/" + id).header("Authorization", auth))
                .andExpect(status().isNoContent());
        assertThat(bookings.findById(id)).isEmpty();
    }

    @Test
    void archivedBookingCanBeRestoredAndOnlyArchivedRecordsCanBeDeleted() throws Exception {
        String login = mvc.perform(post("/api/admin/auth/login").contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"admin@example.invalid\",\"password\":\"TestAdminPassword123\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String auth = "Bearer " + json.readTree(login).get("token").asText();
        var booking = bookings.save(Booking.builder().customerName("Archive test")
                .customerAddress("Test address")
                .email("archive@example.invalid").phoneNumber("09123456789")
                .eventPlace("Test venue").eventDate(LocalDate.now().plusDays(20))
                .eventTime(java.time.LocalTime.NOON).eventType("Birthday").numberOfPax(50)
                .bookingType(com.catering.Saneth.model.enums.BookingType.CUSTOM)
                .bookingStatus(com.catering.Saneth.model.enums.BookingStatus.ARCHIVED)
                .paymentStatus(com.catering.Saneth.model.enums.PaymentStatus.FULLY_PAID)
                .archiveReason("Test archive").build());
        long id = booking.getId();
        String restore = "/api/admin/archives/bookings/" + id + "/unarchive";
        mvc.perform(put(restore).contentType(MediaType.APPLICATION_JSON).content("{\"status\":\"COMPLETED\"}"))
                .andExpect(status().is4xxClientError());
        mvc.perform(put(restore).header("Authorization", auth).contentType(MediaType.APPLICATION_JSON)
                .content("{\"status\":\"PENDING\"}"))
                .andExpect(status().isBadRequest());
        mvc.perform(put(restore).header("Authorization", auth).contentType(MediaType.APPLICATION_JSON)
                .content("{\"status\":\"COMPLETED\"}"))
                .andExpect(status().isNoContent());
        assertThat(bookings.findById(id).orElseThrow().getBookingStatus())
                .isEqualTo(com.catering.Saneth.model.enums.BookingStatus.COMPLETED);
        assertThat(bookings.findById(id).orElseThrow().getArchiveReason()).isNull();
        mvc.perform(delete("/api/admin/archives/bookings/" + id).header("Authorization", auth))
                .andExpect(status().isConflict());
        mvc.perform(put("/api/admin/archives/bookings/" + id).header("Authorization", auth)
                .contentType(MediaType.APPLICATION_JSON).content("{\"reason\":\"Test again\"}"))
                .andExpect(status().isOk());
        mvc.perform(put(restore).header("Authorization", auth).contentType(MediaType.APPLICATION_JSON)
                .content("{\"status\":\"CANCELLED\"}"))
                .andExpect(status().isBadRequest());
        assertThat(bookings.findById(id).orElseThrow().getBookingStatus())
                .isEqualTo(com.catering.Saneth.model.enums.BookingStatus.ARCHIVED);
        mvc.perform(delete("/api/admin/archives/bookings/" + id).header("Authorization", auth))
                .andExpect(status().isNoContent());
        assertThat(bookings.findById(id)).isEmpty();
    }

    @Test
    void invalidCustomMenuRollsBackBookingAndAdminEndpointsRequireLogin() throws Exception {
        long before = bookings.count();
        mvc.perform(post("/api/bookings").contentType(MediaType.APPLICATION_JSON)
                .content(bookingBody(999999L, "invalid@example.invalid"))).andExpect(status().isBadRequest());
        assertThat(bookings.count()).isEqualTo(before);
        mvc.perform(get("/api/admin/bookings")).andExpect(status().is4xxClientError());
        mvc.perform(get("/api/admin/bookings").header("Authorization", "Bearer invalid"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    void packageItemsPersistWithIndependentlyHostedFrontend() throws Exception {
        String login = mvc.perform(post("/api/admin/auth/login").contentType(MediaType.APPLICATION_JSON)
                .content("{\"email\":\"admin@example.invalid\",\"password\":\"TestAdminPassword123\"}"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String auth = "Bearer " + json.readTree(login).get("token").asText();
        var category = categories.save(MenuCategory.builder().name("Package mains").build());
        var item = items.save(MenuItem.builder().name("Rice").category(category).available(true).build());
        String body = json.writeValueAsString(Map.of("name", "Test Package", "packagePrice", 1000,
                "goodForPax", 50, "imageUrl", "/test.jpg", "menuItemIds", java.util.List.of(item.getId())));
        String created = mvc.perform(post("/api/admin/menu-packages").header("Authorization", auth)
                .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().is2xxSuccessful()).andExpect(jsonPath("$.items[0].name").value("Rice"))
                .andReturn().getResponse().getContentAsString();
        long id = json.readTree(created).get("id").asLong();
        mvc.perform(get("/api/menu-packages/" + id)).andExpect(status().isOk())
                .andExpect(jsonPath("$.items[0].id").value(item.getId()));
        String packageBooking = bookingBody(item.getId(), "package-snapshot@example.invalid")
                .replace(LocalDate.now().plusDays(10).toString(), LocalDate.now().plusDays(20).toString())
                .replace("\"bookingType\":\"CUSTOM\",\"menuItemIds\":[" + item.getId() + "]",
                        "\"bookingType\":\"PACKAGE\",\"menuPackageId\":" + id);
        String booked = mvc.perform(post("/api/bookings").contentType(MediaType.APPLICATION_JSON)
                .content(packageBooking)).andExpect(status().is2xxSuccessful())
                .andExpect(jsonPath("$.packageMenuItems[0].name").value("Rice"))
                .andReturn().getResponse().getContentAsString();
        String packageReference = json.readTree(booked).get("bookingReference").asText();
        mvc.perform(get("/api/admin/menu-packages/" + id + "/items").header("Authorization", auth))
                .andExpect(status().isOk()).andExpect(jsonPath("$[0].name").value("Rice"));
        mvc.perform(put("/api/admin/menu-packages/" + id).header("Authorization", auth)
                .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk()).andExpect(jsonPath("$.items[0].name").value("Rice"));
        var replacement = items.save(MenuItem.builder().name("Replacement").category(category).available(true).build());
        String changedPackage = json.writeValueAsString(Map.of("name", "Test Package", "packagePrice", 1000,
                "goodForPax", 50, "imageUrl", "/test.jpg", "menuItemIds", java.util.List.of(replacement.getId())));
        mvc.perform(put("/api/admin/menu-packages/" + id).header("Authorization", auth)
                .contentType(MediaType.APPLICATION_JSON).content(changedPackage)).andExpect(status().isOk());
        mvc.perform(post("/api/bookings/track").contentType(MediaType.APPLICATION_JSON)
                .content(json.writeValueAsString(Map.of("bookingReference", packageReference,
                        "email", "package-snapshot@example.invalid"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.menuPackageName").value("Test Package"))
                .andExpect(jsonPath("$.packageMenuItems[0].name").value("Rice"))
                .andExpect(jsonPath("$.packageMenuItems[0].categoryName").value("Package mains"))
                .andExpect(jsonPath("$.customMenuItems").isEmpty())
                .andExpect(jsonPath("$.bookingStatus").value("PENDING"))
                .andExpect(jsonPath("$.paymentStatus").value("NOT_REQUIRED_YET"));
        // Static customer/admin pages now belong to the independent Vercel project.
        mvc.perform(get("/customer/customer-booking.html")).andExpect(status().isNotFound());
        mvc.perform(get("/admin/menu-packages.html")).andExpect(status().isNotFound());
    }

    @Test
    void availabilityEndpointReturnsCapacityAndRemainingSlots() throws Exception {
        mvc.perform(get("/api/bookings/availability").param("date", LocalDate.now().plusDays(90).toString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.capacity").value(3))
                .andExpect(jsonPath("$.remainingSlots").value(3))
                .andExpect(jsonPath("$.available").value(true));
    }

    private String bookingBody(long itemId, String email) {
        return """
            {"customerName":"Test Customer","email":"%s","phoneNumber":"09123456789",
             "customerAddress":"Test address","eventPlace":"Test venue","eventDate":"%s",
             "eventTime":"12:00","eventType":"Birthday","numberOfPax":50,
             "bookingType":"CUSTOM","menuItemIds":[%d]}
            """.formatted(email, LocalDate.now().plusDays(10), itemId);
    }
}
