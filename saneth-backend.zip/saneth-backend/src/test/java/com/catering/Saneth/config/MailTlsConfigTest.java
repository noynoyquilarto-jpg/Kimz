package com.catering.Saneth.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.io.IOException;
import java.security.KeyStore;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MailTlsConfigTest {
    @Test
    @EnabledOnOs(OS.WINDOWS)
    void inaccessibleWindowsRootsUseDefaultTrustWithoutDisablingVerification() throws Exception {
        KeyStore roots = mock(KeyStore.class);
        doThrow(new IOException("Access is denied")).when(roots).load(null, null);
        try (var stores = mockStatic(KeyStore.class)) {
            stores.when(() -> KeyStore.getInstance("Windows-ROOT")).thenReturn(roots);
            var mail = new JavaMailSenderImpl();
            assertSame(mail, MailTlsConfig.mailTlsCustomizer(true)
                    .postProcessBeforeInitialization(mail, "mailSender"));
            assertEquals("true", mail.getJavaMailProperties().get("mail.smtp.ssl.checkserveridentity"));
            assertFalse(mail.getJavaMailProperties().containsKey("mail.smtp.ssl.socketFactory"));
            assertFalse(mail.getJavaMailProperties().containsKey("mail.smtp.ssl.trust"));
            verify(roots).load(null, null);
        }
    }
}
