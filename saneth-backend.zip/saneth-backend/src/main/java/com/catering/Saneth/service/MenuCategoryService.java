package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.CategoryRequest;
import com.catering.Saneth.dto.response.CategoryResponse;
import com.catering.Saneth.model.MenuCategory;
import com.catering.Saneth.repository.MenuCategoryRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MenuCategoryService {

    private final MenuCategoryRepo menuCategoryRepo;

    public CategoryResponse create(CategoryRequest request){

        MenuCategory category = MenuCategory.builder()
                .name(request.getName())
                .build();

        return map(menuCategoryRepo.save(category));
    }

    public List<CategoryResponse> getAll(){

        return menuCategoryRepo.findAll()
                .stream()
                .map(this::map)
                .toList();
    }

    public CategoryResponse update(Long id, CategoryRequest request){

        MenuCategory category = menuCategoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found."));

        category.setName(request.getName());

        return map(menuCategoryRepo.save(category));
    }

    public void delete(Long id){

        menuCategoryRepo.deleteById(id);

    }

    private CategoryResponse map(MenuCategory category){

        return CategoryResponse.builder()
                .id(category.getId())
                .name(category.getName())
                .build();

    }

}