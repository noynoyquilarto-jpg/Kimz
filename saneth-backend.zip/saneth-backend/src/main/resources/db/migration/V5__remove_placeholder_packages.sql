-- Remove the three requested placeholder packages while retaining historical
-- bookings and feedback without package associations.
UPDATE bookings
SET menu_package_id = NULL
WHERE menu_package_id IN (
    SELECT id FROM menu_packages
    WHERE BINARY name IN ('Package A', 'Package B', 'Package C')
);

UPDATE feedbacks
SET menu_package_id = NULL
WHERE menu_package_id IN (
    SELECT id FROM menu_packages
    WHERE BINARY name IN ('Package A', 'Package B', 'Package C')
);

DELETE package_item
FROM menu_package_items package_item
INNER JOIN menu_packages package ON package.id = package_item.menu_package_id
WHERE BINARY package.name IN ('Package A', 'Package B', 'Package C');

DELETE FROM menu_packages
WHERE BINARY name IN ('Package A', 'Package B', 'Package C');
