package com.catering.Saneth.service;
import com.catering.Saneth.model.*;
import com.catering.Saneth.model.enums.*;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;
import java.math.BigDecimal;
import java.time.*;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class ReceiptEmailServiceTest {
    @Test void emailedTrackingLinksRequirePublicHttpsHost() {
        assertThat(EmailService.isPublicTrackingUrl("https://saneth.example.com/customer/track-booking.html")).isTrue();
        for (String url : java.util.List.of("http://localhost:8080/track", "https://localhost/track", "https://192.168.1.5/track", "https://127.0.0.1/track", "http://saneth.example.com/track", "https://backend.local/track", "https://user:secret@saneth.example.com/track")) {
            assertThat(EmailService.isPublicTrackingUrl(url)).as(url).isFalse();
        }
        var service = service();
        ReflectionTestUtils.setField(service, "trackingUrl", "http://localhost:8080/customer/track-booking.html");
        assertThat(service.renderReceipt(booking(), payment())).contains("Track Booking page", "TEST-1").doesNotContain("localhost");
    }
    EmailService service() {
        var service = new EmailService(mock(NotificationQueue.class));
        ReflectionTestUtils.setField(service, "trackingUrl", "https://example.invalid/track");
        return service;
    }
    Booking booking() {
        return Booking.builder().id(1L).bookingReference("TEST-1").customerName("<script>Customer</script>")
                .email("customer+tag@gmail.com").quotedPrice(new BigDecimal("10000"))
                .downPaymentAmount(3000.0).bookingStatus(BookingStatus.CONFIRMED)
                .paymentStatus(PaymentStatus.DOWN_PAYMENT_CONFIRMED).eventDate(LocalDate.of(2027,1,1)).build();
    }
    BookingPayment payment() {
        return BookingPayment.builder().id(5L).amount(3000.0).paymentMethod(PaymentMethod.GCASH)
                .createdAt(LocalDateTime.of(2026,11,12,10,0)).verifiedAt(LocalDateTime.of(2026,11,12,11,0))
                .paymentReferenceNumber("GCASH-REF").build();
    }
    @Test void receiptContainsVerifiedTransactionAndAccuratePartialBalanceWithEscapedHtml() {
        var service = service(); var b = booking();
        String text = service.renderReceipt(b, payment());
        assertThat(text).contains("Payment successfully verified", "SANETH-PAY-5", "GCASH-REF", "Customer email: customer+tag@gmail.com",
                "Reference: TEST-1", "Package: Custom menu", "2027-01-01", "Payment method: GCASH",
                "Verified payment amount: PHP 3000.00", "Verification date: 2026-11-12T11:00",
                "Total price: PHP 10000.00", "Total payment received: PHP 3000.00", "Remaining balance: PHP 7000.00",
                "DOWN_PAYMENT_CONFIRMED", "partial payment receipt", "customer%2Btag%40gmail.com")
                .startsWith("Payment Receipt\n\nDear ")
                .contains("Your payment has been verified.")
                .doesNotContain("Booking Confirmed!", "Your booking has been confirmed.");
        assertThat(service.renderHtml("payment-receipt", text)).contains("&lt;script&gt;", "Saneth Catering").doesNotContain("<script>");
    }
    @Test void finalReceiptShowsFullyPaidAndZeroBalance() {
        var b = booking(); b.setDownPaymentAmount(10000.0); b.setPaymentStatus(PaymentStatus.FULLY_PAID);
        assertThat(service().renderReceipt(b, payment())).contains("FULLY_PAID", "PHP 0.00", "fully paid").doesNotContain("partial payment receipt");
    }
    @Test void unverifiedPaymentCannotProduceReceipt() {
        var payment = payment(); payment.setVerificationStatus("PENDING_VERIFICATION");
        assertThatThrownBy(() -> service().sendPaymentReceipt(booking(), payment)).isInstanceOf(IllegalArgumentException.class);
    }
    @Test void confirmationAndReceiptHaveSeparateSubjectsAndWordingWithSimpleHtml() {
        var queue = mock(NotificationQueue.class);
        var service = new EmailService(queue);
        ReflectionTestUtils.setField(service, "trackingUrl", "https://example.invalid/track");
        var booking = booking(); booking.setDownPayment(new BigDecimal("3000"));
        booking.setBookingReference("saneth-2026-0062");
        service.sendBookingConfirmationEmail(booking);
        service.sendPaymentReceipt(booking, payment());
        var text = org.mockito.ArgumentCaptor.forClass(String.class);
        var html = org.mockito.ArgumentCaptor.forClass(String.class);
        verify(queue).enqueue(eq("CONFIRMATION:1"), eq("CONFIRMATION"), eq(1L), isNull(), isNull(),
                eq(booking.getEmail()), eq("Saneth Catering - Booking Confirmation - saneth-2026-0062"), text.capture(), html.capture());
        verify(queue).enqueue(eq("PAYMENT_RECEIPT:5"), eq("PAYMENT_RECEIPT"), eq(1L), isNull(), isNull(),
                eq(booking.getEmail()), eq("Saneth Catering - Payment Receipt - saneth-2026-0062"), text.capture(), html.capture());
        assertThat(text.getAllValues().get(0)).startsWith("Booking Confirmed!\n\nDear ")
                .contains("Thank you for choosing Saneth Catering! Your booking has been confirmed.");
        assertThat(text.getAllValues().get(1)).startsWith("Payment Receipt\n\nDear ")
                .contains("Your payment has been verified.").doesNotContain("Booking Confirmed!", "Your booking has been confirmed.");
        for (String body : text.getAllValues()) assertThat(body).contains("Reference: saneth-2026-0062",
                        "Event:", "Package:", "Total payment received: PHP 3000.00", "Remaining balance: PHP 7000.00");
        for (String body : html.getAllValues()) assertThat(body)
                .contains("<h1>SANETH CATERING</h1>", "white-space:pre-wrap", "&lt;script&gt;")
                .doesNotContain("<script>", "<table", "<img", "#244334");
    }
}
