package com.catering.Saneth;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(properties = {
        "spring.datasource.url=jdbc:h2:mem:saneth-cors-tests;DB_CLOSE_DELAY=-1",
        "saneth.cors.allowed-origins=https://saneth-catering.example,http://localhost:5500"
})
@AutoConfigureMockMvc
class DeploymentCorsTest {
    @Autowired MockMvc mvc;

    @Test void customerAndAdminPreflightAcceptOnlyConfiguredFrontend() throws Exception {
        for (String endpoint : new String[]{"/api/customer/auth/register", "/api/admin/bookings"}) {
            mvc.perform(options(endpoint)
                            .header("Origin", "https://saneth-catering.example")
                            .header("Access-Control-Request-Method", "POST")
                            .header("Access-Control-Request-Headers", "authorization,content-type"))
                    .andExpect(status().isOk())
                    .andExpect(header().string("Access-Control-Allow-Origin", "https://saneth-catering.example"));
            mvc.perform(options(endpoint)
                            .header("Origin", "https://untrusted.example")
                            .header("Access-Control-Request-Method", "POST"))
                    .andExpect(status().isForbidden())
                    .andExpect(header().doesNotExist("Access-Control-Allow-Origin"));
        }
    }

    @Test void crossOriginRequestsKeepAdminAuthenticationRequired() throws Exception {
        mvc.perform(get("/api/admin/bookings").header("Origin", "https://saneth-catering.example"))
                .andExpect(status().isUnauthorized())
                .andExpect(header().string("Access-Control-Allow-Origin", "https://saneth-catering.example"));
        mvc.perform(get("/api/menu-packages").header("Origin", "https://saneth-catering.example"))
                .andExpect(status().isOk())
                .andExpect(header().string("Access-Control-Allow-Origin", "https://saneth-catering.example"));
    }
}
