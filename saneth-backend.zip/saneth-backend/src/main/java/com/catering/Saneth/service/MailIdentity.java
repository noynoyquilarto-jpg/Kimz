package com.catering.Saneth.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.InternetAddress;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;

/** The visible sender always uses the authenticated SMTP account. */
@Component
public record MailIdentity(
        @Value("${spring.mail.username:}") String from,
        @Value("${saneth.mail.reply-to:${spring.mail.username:}}") String replyTo,
        @Value("${saneth.mail.from-name:${saneth.mail.sender-name:Saneth Catering}}") String senderName) {

    public void apply(SimpleMailMessage message) {
        try {
            message.setFrom(new InternetAddress(from, senderName, StandardCharsets.UTF_8.name()).toString());
            message.setReplyTo(replyTo);
        } catch (UnsupportedEncodingException error) {
            throw new IllegalStateException("UTF-8 is unavailable", error);
        }
    }

    public void apply(MimeMessageHelper message) throws MessagingException, UnsupportedEncodingException {
        message.setFrom(from, senderName);
        message.setReplyTo(replyTo);
    }
}
