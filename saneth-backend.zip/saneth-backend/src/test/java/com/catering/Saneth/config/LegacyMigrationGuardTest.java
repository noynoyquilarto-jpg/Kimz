package com.catering.Saneth.config;

import org.flywaydb.core.api.FlywayException;
import org.flywaydb.core.api.MigrationInfo;
import org.flywaydb.core.api.MigrationVersion;
import org.flywaydb.core.api.callback.Context;
import org.flywaydb.core.api.callback.Event;
import org.junit.jupiter.api.Test;

import java.sql.DriverManager;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LegacyMigrationGuardTest {
    @Test void onlyRunsBeforeLegacyDeletion() {
        var context = mock(Context.class);
        var info = mock(MigrationInfo.class);
        when(context.getMigrationInfo()).thenReturn(info);
        when(info.getVersion()).thenReturn(MigrationVersion.fromVersion("5"));
        var guard = new LegacyMigrationGuard();
        assertTrue(guard.supports(Event.BEFORE_EACH_MIGRATE, context));
        assertFalse(guard.supports(Event.AFTER_EACH_MIGRATE, context));
        when(info.getVersion()).thenReturn(MigrationVersion.fromVersion("10"));
        assertFalse(guard.supports(Event.BEFORE_EACH_MIGRATE, context));
    }

    @Test void blocksDeletionWithoutChangingRecordsAndAllowsEmptyCatalog() throws Exception {
        try (var connection = DriverManager.getConnection("jdbc:h2:mem:migration-guard")) {
            connection.createStatement().execute("CREATE TABLE menu_packages (name VARCHAR(255))");
            var context = mock(Context.class);
            when(context.getConnection()).thenReturn(connection);
            var guard = new LegacyMigrationGuard();
            assertDoesNotThrow(() -> guard.handle(Event.BEFORE_EACH_MIGRATE, context));
            connection.createStatement().execute("INSERT INTO menu_packages VALUES ('Package A')");
            assertThrows(FlywayException.class, () -> guard.handle(Event.BEFORE_EACH_MIGRATE, context));
            try (var rows = connection.createStatement().executeQuery("SELECT COUNT(*) FROM menu_packages")) {
                assertTrue(rows.next()); assertEquals(1, rows.getLong(1));
            }
        }
    }
}
