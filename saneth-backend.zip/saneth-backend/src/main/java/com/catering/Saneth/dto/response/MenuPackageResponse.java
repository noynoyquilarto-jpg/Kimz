package com.catering.Saneth.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
@Builder
public class MenuPackageResponse {
    private Long id;
    private String name;
    private String description;
    private Double packagePrice;
    private Integer goodForPax;
    private String imageUrl;
    private Boolean available;
    private List<MenuItemResponse> items;
}
