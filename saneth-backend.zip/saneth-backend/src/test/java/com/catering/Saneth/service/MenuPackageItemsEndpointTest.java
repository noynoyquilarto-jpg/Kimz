package com.catering.Saneth.service;

import com.catering.Saneth.controller.MenuPackageController;
import com.catering.Saneth.exception.GlobalExceptionHandler;
import com.catering.Saneth.model.*;
import com.catering.Saneth.repository.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@ExtendWith(MockitoExtension.class)
class MenuPackageItemsEndpointTest {
    @Mock MenuRepo menuRepo;
    @Mock MenuPackageRepo packageRepo;
    @Mock BookingRepo bookingRepo;
    @Mock FeedbackRepo feedbackRepo;
    @InjectMocks MenuPackageService service;

    private org.springframework.test.web.servlet.MockMvc mvc() {
        return MockMvcBuilders.standaloneSetup(new MenuPackageController(service, mock(AdminAuditLogService.class)))
                .setControllerAdvice(new GlobalExceptionHandler()).build();
    }

    @Test void adminEndpointReturnsPackageMenuItems() throws Exception {
        var category = MenuCategory.builder().id(3L).name("Main course").build();
        var item = MenuItem.builder().id(7L).name("Chicken").category(category).available(true).build();
        when(packageRepo.findById(2L)).thenReturn(Optional.of(MenuPackage.builder().id(2L).items(List.of(item)).build()));
        mvc().perform(get("/api/admin/menu-packages/2/items"))
                .andExpect(status().isOk()).andExpect(jsonPath("$[0].id").value(7))
                .andExpect(jsonPath("$[0].name").value("Chicken"))
                .andExpect(jsonPath("$[0].categoryName").value("Main course"));
    }

    @Test void emptyPackageReturnsEmptyArray() throws Exception {
        when(packageRepo.findById(2L)).thenReturn(Optional.of(MenuPackage.builder().id(2L).items(List.of()).build()));
        mvc().perform(get("/api/admin/menu-packages/2/items")).andExpect(status().isOk()).andExpect(content().json("[]"));
    }

    @Test void missingPackageReturns404() throws Exception {
        when(packageRepo.findById(2L)).thenReturn(Optional.empty());
        mvc().perform(get("/api/admin/menu-packages/2/items")).andExpect(status().isNotFound());
    }

    @Test void unknownEndpointReturns404() throws Exception {
        mvc().perform(get("/api/admin/not-a-real-endpoint")).andExpect(status().isNotFound());
    }
}
