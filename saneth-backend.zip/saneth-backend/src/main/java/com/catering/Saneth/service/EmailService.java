package com.catering.Saneth.service;

import com.catering.Saneth.model.*;
import com.catering.Saneth.model.enums.BookingStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.util.*;
import java.math.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Renders snapshots and queues them in the caller's database transaction. */
@Service @RequiredArgsConstructor @Transactional
public class EmailService {
    private final NotificationQueue queue;
    @Value("${saneth.gcash.name}") private String gcashName;
    @Value("${saneth.gcash.number}") private String gcashNumber;
    @Value("${saneth.facebook.messenger}") private String messengerLink;
    @Value("${saneth.tracking.url}") private String trackingUrl;
    @Value("${saneth.mail.reply-to:${spring.mail.username:}}") private String replyTo;

    public String sendOtp(Customer customer, String code) {
        String text = "Dear " + value(customer.getFirstName())
                + ",\n\nWelcome to Saneth Catering!\n\nThank you for creating an account.\n\n"
                + "To complete your registration, please enter the following One-Time Password (OTP):\n\n"
                + "Your Verification Code:\n" + code + "\n\nThis OTP expires in 5 minutes.\n\n"
                + "If you did not create this account, please ignore this message.\n\n"
                + "For questions or assistance, you may reply to this email at " + value(replyTo)
                + ".\n\nBest regards,\nSaneth Catering Team";
        return queue.enqueue("OTP:" + UUID.randomUUID(), "OTP", null, customer.getId(), customer.getVerificationExpiresAt(),
                customer.getEmail(), "Saneth Catering \u2013 Verify Your Email", text, renderHtml("otp", text));
    }
    public void sendBookingAcknowledgement(Booking booking, List<String> names) {
        String text = "Dear " + value(booking.getCustomerName()) + ",\n\nYour booking request has been received and is awaiting admin review.\n"
                + "This is a PENDING request; it is not a booking confirmation.\n\n" + bookingDetails(booking, names)
                + "\nPayment instructions will follow after approval.\n\nTrack your booking:\n" + trackingLink(booking);
        enqueue(booking, "ACKNOWLEDGEMENT", "Booking request received", text, "booking-acknowledgement");
    }
    public void sendBookingConfirmationEmail(Booking booking) { sendBookingConfirmationEmail(booking, List.of()); }
    public void sendBookingConfirmationEmail(Booking booking, List<String> names) {
        if (booking.getBookingStatus() != BookingStatus.CONFIRMED || booking.getQuotedPrice() == null || booking.getDownPayment() == null)
            throw new IllegalArgumentException("Confirmation requires a confirmed booking, approved quote and required down payment.");
        String text = renderBookingEmail(booking, false, names)
                + "\n\nPayment instructions\nGCash name: " + value(gcashName) + "\nGCash number: " + value(gcashNumber)
                + "\nSubmit your transaction details using the booking tracking page, or send your proof and booking reference through Messenger:\n"
                + value(messengerLink) + "\nAdmin will verify your payment before issuing a receipt. If you have already paid, do not pay again."
                + "\n\nTrack your booking and payment status:\n" + trackingLink(booking);
        queue.enqueue("CONFIRMATION:" + booking.getId(), "CONFIRMATION", booking.getId(), null, null,
                booking.getEmail(), "Saneth Catering - Booking Confirmation - " + booking.getBookingReference(),
                text, renderHtml("booking-confirmation", text));
    }
    /** An explicit admin retry reuses the saved notification instead of making another email. */
    public void retryBookingConfirmationEmail(Booking booking, List<String> names) {
        sendBookingConfirmationEmail(booking, names);
        queue.retryBookingConfirmation(booking.getId());
    }
    public void sendPaymentReceipt(Booking booking, BookingPayment record) {
        if (record == null || record.getId() == null || !"VERIFIED".equals(record.getVerificationStatus()))
            throw new IllegalArgumentException("A saved, verified payment transaction is required for a receipt.");
        String text = renderReceipt(booking, record);
        queue.enqueue("PAYMENT_RECEIPT:" + record.getId(), "PAYMENT_RECEIPT", booking.getId(), null, null,
                booking.getEmail(), "Saneth Catering - Payment Receipt - " + booking.getBookingReference(),
                text, renderHtml("payment-receipt", text));
    }
    String renderReceipt(Booking booking, BookingPayment record) {
        BigDecimal paid = booking.getDownPaymentAmount() == null ? BigDecimal.ZERO : BigDecimal.valueOf(booking.getDownPaymentAmount());
        BigDecimal price = booking.getQuotedPrice() != null ? booking.getQuotedPrice() : BigDecimal.ZERO;
        return renderBookingEmail(booking, true, List.of())
                + "\n\nVerified payment details\nPayment successfully verified\n\n"
                + "Receipt reference: SANETH-PAY-" + record.getId()
                + "\nTransaction reference: " + value(record.getPaymentReferenceNumber())
                + "\nCustomer name: " + value(booking.getCustomerName()) + "\nCustomer email: " + value(booking.getEmail())
                + "\nPayment method: " + value(record.getPaymentMethod())
                + "\nVerified payment amount: " + money(BigDecimal.valueOf(record.getAmount()))
                + "\nPayment date: " + value(record.getCreatedAt())
                + "\nVerification date: " + value(record.getVerifiedAt()) + " (server local time)"
                + "\n\n" + (price.subtract(paid).signum() <= 0 ? "Your booking is fully paid." : "This is a partial payment receipt; the remaining balance is still due.")
                + "\n\nTrack your booking:\n" + trackingLink(booking) + "\n\nThank you for choosing Saneth Catering.";
    }
    /** Confirmation and verified-payment messages share booking details, with distinct wording. */
    String renderBookingEmail(Booking b, boolean payment, List<String> names) {
        BigDecimal total = b.getQuotedPrice() != null ? b.getQuotedPrice()
                : b.getMenuPackage() != null && b.getMenuPackage().getPackagePrice() != null
                ? BigDecimal.valueOf(b.getMenuPackage().getPackagePrice()) : BigDecimal.ZERO;
        BigDecimal paid = b.getDownPaymentAmount() == null ? BigDecimal.ZERO : BigDecimal.valueOf(b.getDownPaymentAmount());
        return (payment ? "Payment Receipt" : "Booking Confirmed!")
                + "\n\nDear " + value(b.getCustomerName()) + ",\n\n"
                + (payment ? "Your payment has been verified. Thank you for your payment.\n\n"
                : "Thank you for choosing Saneth Catering! Your booking has been confirmed.\n\n")
                + "Reference: " + value(b.getBookingReference())
                + "\nEvent: " + value(b.getEventType())
                + "\nPackage: " + (b.getMenuPackage() == null ? "Custom menu" : value(b.getMenuPackage().getName()))
                + (names == null || names.isEmpty() ? "" : "\nSelected menu: " + String.join(", ", names))
                + "\nEvent date: " + value(b.getEventDate())
                + "\nEvent time: " + value(b.getEventTime())
                + "\nEvent place: " + value(b.getEventPlace())
                + "\nGuest count: " + value(b.getNumberOfPax())
                + "\nTotal price: " + money(total)
                + (payment ? "" : "\nRequired down payment: " + money(b.getDownPayment()))
                + "\nTotal payment received: " + money(paid)
                + "\nRemaining balance: " + money(total.subtract(paid).max(BigDecimal.ZERO))
                + "\nBooking status: " + value(b.getBookingStatus())
                + "\nPayment status: " + value(b.getPaymentStatus())
                + "\n\n" + (payment
                ? "This email acknowledges your verified payment."
                : "This email confirms your booking. A payment receipt is sent after admin verifies a payment.")
                + "\n\nThank you for trusting Saneth Catering!";
    }
    private void enqueue(Booking booking, String kind, String title, String text, String template) {
        queue.enqueue(kind + ":" + booking.getId(), kind, booking.getId(), null, null, booking.getEmail(),
                "Saneth Catering - " + title + " - " + booking.getBookingReference(), text, renderHtml(template, text));
    }
    private String bookingDetails(Booking b, List<String> names) {
        return "Booking reference: " + value(b.getBookingReference())
                + "\nSelected package: " + (b.getMenuPackage() == null ? "Custom menu" : value(b.getMenuPackage().getName()))
                + (names == null || names.isEmpty() ? "" : "\nSelected menu: " + String.join(", ", names))
                + "\nEvent date: " + value(b.getEventDate()) + "\nEvent time: " + value(b.getEventTime())
                + "\nEvent type: " + value(b.getEventType()) + "\nEvent place: " + value(b.getEventPlace())
                + "\nGuest count: " + value(b.getNumberOfPax()) + "\nBooking status: " + value(b.getBookingStatus()) + "\n";
    }
    private String trackingLink(Booking b) {
        if (!isPublicTrackingUrl(trackingUrl)) {
            return "Open the Saneth Catering website's Track Booking page and enter booking reference "
                    + b.getBookingReference() + " and the email address used for your booking.";
        }
        return UriComponentsBuilder.fromUriString(trackingUrl).replaceQueryParam("ref", "{ref}")
                .replaceQueryParam("email", "{email}").encode().buildAndExpand(Map.of("ref", b.getBookingReference(), "email", b.getEmail())).toUriString();
    }
    // Development addresses cannot be reached from a customer's inbox. Keep them out of email.
    static boolean isPublicTrackingUrl(String url) {
        try {
            var uri = java.net.URI.create(url);
            String host = uri.getHost();
            if (!"https".equalsIgnoreCase(uri.getScheme()) || host == null || uri.getUserInfo() != null) return false;
            host = host.toLowerCase(Locale.ROOT);
            return host.contains(".") && !host.matches("[0-9.]+") && !host.contains(":")
                    && !host.endsWith(".localhost") && !host.endsWith(".local") && !host.endsWith(".internal");
        } catch (IllegalArgumentException | NullPointerException ex) { return false; }
    }
    String renderHtml(String template, String text) {
        try {
            return new ClassPathResource("templates/email/" + template + ".html").getContentAsString(StandardCharsets.UTF_8)
                    .replace("{{content}}", HtmlUtils.htmlEscape(text));
        } catch (java.io.IOException ex) { throw new IllegalStateException("Email template is unavailable"); }
    }
    private String value(Object value) { return value == null ? "Not specified" : value.toString().replace('\r', ' ').replace('\n', ' '); }
    private String money(BigDecimal value) { return "PHP " + value.setScale(2, RoundingMode.HALF_UP).toPlainString(); }
}
