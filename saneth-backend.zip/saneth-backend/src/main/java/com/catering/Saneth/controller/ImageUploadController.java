package com.catering.Saneth.controller;

import com.catering.Saneth.dto.response.ImageUploadResponse;
import com.catering.Saneth.service.AdminAuditLogService;
import com.catering.Saneth.service.ImageStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/admin/uploads")
@RequiredArgsConstructor
public class ImageUploadController {

    private final ImageStorageService imageStorageService;
    private final AdminAuditLogService adminAuditLogService;

    @PostMapping("/images")
    public ImageUploadResponse uploadImage(@RequestParam("file") MultipartFile file) {
        String imageUrl = imageStorageService.storeImage(file);
        adminAuditLogService.record("IMAGE_UPLOADED", "IMAGE", imageUrl, file.getOriginalFilename());
        return new ImageUploadResponse(imageUrl);
    }
}
