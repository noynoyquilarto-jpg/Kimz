package com.catering.Saneth.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.security.KeyStore;
import java.util.Locale;

@Configuration
public class MailTlsConfig {
    private static final Logger log = LoggerFactory.getLogger(MailTlsConfig.class);
    @Bean
    static BeanPostProcessor mailTlsCustomizer(
            @Value("${saneth.mail.windows-trust-store:true}") boolean windowsRoots) {
        return new BeanPostProcessor() {
            @Override public Object postProcessBeforeInitialization(Object bean, String name) {
                if (bean instanceof JavaMailSenderImpl mail) {
                    var properties = mail.getJavaMailProperties();
                    properties.put("mail.smtp.ssl.checkserveridentity", "true");
                    properties.putIfAbsent("mail.smtp.connectiontimeout", "10000");
                    properties.putIfAbsent("mail.smtp.timeout", "10000");
                    properties.putIfAbsent("mail.smtp.writetimeout", "10000");
                    if (windowsRoots && System.getProperty("os.name", "").toLowerCase(Locale.ROOT).startsWith("windows")) {
                        try {
                            KeyStore roots = KeyStore.getInstance("Windows-ROOT");
                            roots.load(null, null);
                            var managers = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
                            managers.init(roots);
                            var context = SSLContext.getInstance("TLS");
                            context.init(null, managers.getTrustManagers(), null);
                            properties.put("mail.smtp.ssl.socketFactory", context.getSocketFactory());
                            properties.put("mail.smtp.ssl.socketFactory.fallback", "false");
                        } catch (Exception error) {
                            log.warn("Cannot load Windows trusted roots for SMTP TLS; using the default Java trust store: {}",
                                    error.toString());
                        }
                    }
                }
                return bean;
            }
        };
    }
}
