package com.catering.Saneth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@org.springframework.scheduling.annotation.EnableScheduling
public class SanethApplication {

	public static void main(String[] args) {
		SpringApplication.run(SanethApplication.class, args);
	}

}
