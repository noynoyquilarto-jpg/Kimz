package com.catering.Saneth.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "menu_packages")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MenuPackage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    private String description;

    private String imageUrl;

    @Column(nullable = false)
    private Double packagePrice;

    @Column(nullable = false)
    private Integer goodForPax;

    private Boolean available;


    @ManyToMany
    @JoinTable(
            name = "menu_package_items",
            joinColumns = @JoinColumn(name = "menu_package_id"),
            inverseJoinColumns = @JoinColumn(name = "menu_item_id")
    )
    @Builder.Default
    private List<MenuItem> items = new java.util.ArrayList<>();

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();

        if (available == null) {
            available = true;
        }
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
