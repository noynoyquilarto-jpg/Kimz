package com.catering.Saneth.repository;

import com.catering.Saneth.model.BookingPayment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookingPaymentRepo extends JpaRepository<BookingPayment, Long> {
    List<BookingPayment> findByBookingIdOrderByCreatedAtAsc(Long bookingId);
}
