import { apiRequest, setToken } from './api.js';

const form = document.getElementById('loginForm');
const message = document.getElementById('loginMessage');

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  message.textContent = 'Logging in...';

  const body = {
    email: document.getElementById('email').value.trim(),
    password: document.getElementById('password').value
  };

  try {
    const data = await apiRequest('/api/admin/auth/login', {
      method: 'POST',
      body: JSON.stringify(body)
    });

    setToken(data.token);
    localStorage.setItem('saneth_admin_role', data.role || 'ADMIN');
    window.location.href = 'dashboard.html';
  } catch (error) {
    message.textContent = error.message;
  }
});
