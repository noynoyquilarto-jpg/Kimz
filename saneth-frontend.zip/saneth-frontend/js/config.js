// This public configuration contains only the backend address. Never put secrets here.
export function resolveApiOrigin(settings = window.SANETH_CONFIG, location = window.location) {
  const configured = settings?.apiBaseUrl?.trim() || window.SANETH_API_BASE?.trim();
  if (configured) {
    const url = new URL(configured);
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password ||
        url.search || url.hash || !['', '/', '/api', '/api/'].includes(url.pathname)) {
      throw new Error('Configure SANETH_API_BASE_URL with the backend HTTP(S) origin.');
    }
    if (location.protocol === 'https:' && url.protocol !== 'https:') {
      throw new Error('The booking server must use HTTPS for this website.');
    }
    return url.origin;
  }
  const host = location.hostname || 'localhost';
  const local = /^(localhost|127(?:\.\d{1,3}){3}|\[?::1\]?|10(?:\.\d{1,3}){3}|192\.168(?:\.\d{1,3}){2}|172\.(?:1[6-9]|2\d|3[01])(?:\.\d{1,3}){2})$/i.test(host);
  if (local) return `${location.protocol === 'https:' ? 'https:' : 'http:'}//${host.includes(':') && !host.startsWith('[') ? '[' + host + ']' : host}:8080`;
  // A same-origin reverse proxy remains supported. Vercel builds require an explicit URL.
  return location.origin;
}

export const API_ORIGIN = resolveApiOrigin();
