package com.catering.Saneth.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdatePaymentRequest {
    private com.catering.Saneth.model.enums.PaymentMethod paymentMethod;

    @NotNull(message = "Down payment amount is required.")
    private Double downPaymentAmount;
}
