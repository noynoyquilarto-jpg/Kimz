package com.catering.Saneth.security;
import com.catering.Saneth.repository.AdminRepo;
import com.catering.Saneth.repository.CustomerRepo;
import jakarta.servlet.*;import jakarta.servlet.http.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;import java.util.List;
@Component @RequiredArgsConstructor
public class JwtFilter extends OncePerRequestFilter {
 private final JwtService jwtService;private final AdminRepo adminRepo;private final CustomerRepo customerRepo;
 @Override protected void doFilterInternal(HttpServletRequest request,HttpServletResponse response,FilterChain chain)throws ServletException,IOException {
  String header=request.getHeader("Authorization");
  if(header!=null && header.startsWith("Bearer ") && SecurityContextHolder.getContext().getAuthentication()==null){
   try{
    String token=header.substring(7),email=jwtService.extractEmail(token),role=jwtService.extractRole(token);
    if(email!=null && jwtService.isTokenValid(token,email)){
     boolean exists="ADMIN".equals(role) ? adminRepo.findByEmail(email).map(a->"ADMIN".equals(a.getRole())).orElse(false) :
       "CUSTOMER".equals(role) && customerRepo.findByEmailIgnoreCase(email).isPresent();
     if(exists)SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(email,null,List.of(new SimpleGrantedAuthority("ROLE_"+role))));
    }
   }catch(io.jsonwebtoken.JwtException | IllegalArgumentException ex){ /* invalid token: continue unauthenticated */ }
  }
  chain.doFilter(request,response);
 }
}
