package com.catering.Saneth.model;
import jakarta.persistence.*;
import lombok.Getter;import lombok.Setter;
import java.time.LocalDateTime;
@Entity @Table(name="customers") @Getter @Setter
public class Customer {
 @Column(nullable=false) private boolean emailVerified;
 private String verificationHash;
 private java.time.Instant verificationExpiresAt;
 private java.time.Instant verificationSentAt;
 @Column(nullable=false) private int verificationAttempts;
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false,length=100) private String firstName;
 @Column(nullable=false,length=100) private String lastName;
 @Column(nullable=false,unique=true,length=255) private String email;
 @Column(nullable=false) private String password;
 @Column(nullable=false) private LocalDateTime createdAt=LocalDateTime.now();
}
