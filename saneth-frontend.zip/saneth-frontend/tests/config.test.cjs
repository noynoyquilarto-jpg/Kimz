const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function browser(hostname = 'localhost', protocol = 'http:', settings) {
  const source = fs.readFileSync(path.join(__dirname, '../js/config.js'), 'utf8').replace(/^export /gm, '');
  const context = vm.createContext({ URL, window: { SANETH_CONFIG: settings, location: {
    hostname, protocol, origin: `${protocol}//${hostname}`
  } } });
  vm.runInContext(source, context);
  return context;
}

test('local desktop and phone hostnames use the local backend', () => {
  for (const host of ['localhost', '127.0.0.1', '192.168.1.11', '10.0.0.2', '172.16.0.2', '[::1]']) {
    assert.equal(browser(host).resolveApiOrigin(), `http://${host}:8080`);
  }
});

test('production config normalizes /api once and refuses unsafe addresses', () => {
  assert.equal(browser('saneth.vercel.app', 'https:', { apiBaseUrl: 'https://api.example.com/api/' }).resolveApiOrigin(), 'https://api.example.com');
  for (const bad of ['http://api.example.com', 'https://user:password@api.example.com', 'https://api.example.com/other', 'https://api.example.com?token=secret']) {
    assert.throws(() => browser('saneth.vercel.app', 'https:', { apiBaseUrl: bad }));
  }
});

test('production build requires a public HTTPS backend and exports only its origin', async () => {
  const { publicConfig } = await import('../scripts/build.mjs');
  assert.throws(() => publicConfig({ VERCEL: '1' }), /Set SANETH_API_BASE_URL/);
  assert.throws(() => publicConfig({ VERCEL: '1', SANETH_API_BASE_URL: 'http://localhost:8080' }), /public HTTPS/);
  assert.deepEqual(publicConfig({ VERCEL: '1', SANETH_API_BASE_URL: 'https://api.example.com/api', SANETH_DB_PASSWORD: 'must-never-be-exported' }), { apiBaseUrl: 'https://api.example.com' });
});
