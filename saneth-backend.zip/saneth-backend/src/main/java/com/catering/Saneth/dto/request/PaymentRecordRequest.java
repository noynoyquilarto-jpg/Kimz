package com.catering.Saneth.dto.request;

import com.catering.Saneth.model.enums.PaymentMethod;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentRecordRequest {

    @NotNull(message = "Payment method is required")
    private PaymentMethod paymentMethod;

    @NotNull(message = "Payment amount is required")
    @Positive(message = "Payment amount must be greater than 0")
    @jakarta.validation.constraints.Digits(integer = 10, fraction = 2, message = "Use no more than two decimal places")
    private Double amount;

    @jakarta.validation.constraints.Size(max = 255)
    private String paymentReferenceNumber;

    @jakarta.validation.constraints.Size(max = 255)
    private String note;

    @jakarta.validation.constraints.Pattern(regexp = "[0-9a-fA-F-]{36}", message = "Use a UUID submission key")
    private String submissionKey;
}
