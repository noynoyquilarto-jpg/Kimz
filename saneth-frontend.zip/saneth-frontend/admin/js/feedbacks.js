import { apiRequest, requireAuth, safe } from './api.js';
import { initLayout } from './layout.js';

requireAuth();
initLayout();

const list = document.getElementById('feedbackList');
const chart = document.getElementById('feedbackChart');
const details = document.getElementById('feedbackDetails');
const refreshBtn = document.getElementById('refreshBtn');

refreshBtn.addEventListener('click', loadFeedbacks);
loadFeedbacks();

async function loadFeedbacks() {
  refreshBtn.disabled = true;
  chart.setAttribute('aria-busy', 'true');
  chart.innerHTML = '<div class="empty-state">Loading feedback graph...</div>';
  details.hidden = true;
  list.innerHTML = '';
  try {
    const feedbacks = await apiRequest('/api/admin/feedbacks');
    if (feedbacks !== null && !Array.isArray(feedbacks)) {
      throw new Error('Unable to read feedback data. Please try refreshing.');
    }
    renderFeedbackChart(feedbacks || []);
    renderFeedbacks(feedbacks || []);
    details.hidden = !feedbacks?.length;
  } catch (error) {
    chart.innerHTML = `<div class="empty-state">${safe(error.message)}</div>`;
  } finally {
    refreshBtn.disabled = false;
    chart.setAttribute('aria-busy', 'false');
  }
}

function renderFeedbackChart(feedbacks) {
  if (!feedbacks.length) {
    chart.innerHTML = '<div class="empty-state">No feedback yet. The rating graph will appear when customers submit feedback.</div>';
    return;
  }

  const counts = [0, 0, 0, 0, 0];
  let totalScore = 0;
  let ratedCount = 0;
  feedbacks.forEach(feedback => {
    const rating = Number(feedback.rating);
    if (Number.isInteger(rating) && rating >= 1 && rating <= 5) {
      counts[rating - 1] += 1;
      totalScore += rating;
      ratedCount += 1;
    }
  });
  const positiveCount = counts[3] + counts[4];
  const unratedCount = feedbacks.length - ratedCount;

  chart.innerHTML = `
    <div class="feedback-stats">
      <div class="feedback-stat"><span>Total feedback</span><strong>${feedbacks.length}</strong></div>
      <div class="feedback-stat"><span>Average rating</span><strong>${ratedCount ? `${(totalScore / ratedCount).toFixed(1)} / 5` : 'N/A'}</strong></div>
      <div class="feedback-stat"><span>Positive ratings (4–5 stars)</span><strong>${ratedCount ? `${Math.round(positiveCount / ratedCount * 100)}%` : 'N/A'}</strong></div>
    </div>
    <figure class="feedback-distribution" aria-labelledby="ratingGraphTitle">
      <figcaption>
        <h3 id="ratingGraphTitle">Rating distribution</h3>
        <p class="muted">Share of ${ratedCount} rated feedback entries. Each bar shows the count and percentage.</p>
      </figcaption>
      <div class="feedback-bars">
        ${[5, 4, 3, 2, 1].map(rating => {
          const count = counts[rating - 1];
          const percentage = ratedCount ? count / ratedCount * 100 : 0;
          return `
            <div class="feedback-bar-row">
              <span>${rating} ${rating === 1 ? 'star' : 'stars'}</span>
              <div class="feedback-bar-track" aria-hidden="true"><div class="feedback-bar-fill" style="width: ${percentage}%"></div></div>
              <span class="feedback-bar-value">${count} (${Math.round(percentage)}%)</span>
            </div>`;
        }).join('')}
      </div>
      ${unratedCount ? `<p class="muted">${unratedCount} feedback entries without a valid 1–5 star rating are excluded from rating statistics.</p>` : ''}
    </figure>`;
}

function renderFeedbacks(feedbacks) {
  if (!feedbacks.length) {
    list.innerHTML = '<div class="empty-state">No feedbacks yet.</div>';
    return;
  }

  list.innerHTML = feedbacks.map(feedback => `
    <article class="item-card">
      <div class="card-placeholder">${safe(feedback.rating || 0)}★</div>
      <div>
        <h3>${safe(feedback.customerName)}</h3>
        <div class="card-meta">
          <span class="badge dark">${safe(feedback.bookingReference)}</span>
          <span class="badge">${safe(feedback.menuPackageName)}</span>
          <span class="badge">${safe(feedback.rating)} / 5</span>
        </div>
        <p>${safe(feedback.comment || 'No comment')}</p>
        <p class="muted">${safe(feedback.email)} • ${safe(feedback.createdAt || '')}</p>
      </div>
    </article>
  `).join('');
}
