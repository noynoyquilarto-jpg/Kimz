package com.catering.Saneth.service;

import com.catering.Saneth.dto.request.AdminLoginRequest;
import com.catering.Saneth.dto.response.AdminLoginResponse;
import com.catering.Saneth.dto.response.AdminResponse;
import com.catering.Saneth.model.Admin;
import com.catering.Saneth.repository.AdminRepo;
import com.catering.Saneth.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AdminAuthService {

    private final AdminRepo adminRepo;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AdminLoginResponse login(AdminLoginRequest request) {
        Admin admin = adminRepo.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid email or password"));

        boolean passwordMatches = passwordEncoder.matches(
                request.getPassword(),
                admin.getPassword()
        );

        if (!passwordMatches) {
            throw new RuntimeException("Invalid email or password");
        }

        String token = jwtService.generateToken(admin.getEmail(), admin.getRole());

        return AdminLoginResponse.builder()
                .message("Login successful")
                .token(token)
                .role(admin.getRole())
                .build();
    }

    public AdminResponse getAdminProfile(String email) {
        Admin admin = adminRepo.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Admin not found"));

        return AdminResponse.builder()
                .id(admin.getId())
                .name(admin.getName())
                .email(admin.getEmail())
                .role(admin.getRole())
                .build();
    }
}