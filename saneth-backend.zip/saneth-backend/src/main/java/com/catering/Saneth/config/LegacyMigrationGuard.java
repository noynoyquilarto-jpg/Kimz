package com.catering.Saneth.config;

import org.flywaydb.core.api.FlywayException;
import org.flywaydb.core.api.MigrationVersion;
import org.flywaydb.core.api.callback.Callback;
import org.flywaydb.core.api.callback.Context;
import org.flywaydb.core.api.callback.Event;
import org.springframework.stereotype.Component;

import java.sql.SQLException;

/** Keeps the original Flyway checksum while protecting existing package records. */
@Component
public class LegacyMigrationGuard implements Callback {
    @Override
    public boolean supports(Event event, Context context) {
        return event == Event.BEFORE_EACH_MIGRATE && context.getMigrationInfo() != null
                && MigrationVersion.fromVersion("5").equals(context.getMigrationInfo().getVersion());
    }

    @Override public boolean canHandleInTransaction(Event event, Context context) { return true; }
    @Override public String getCallbackName() { return "preserve-existing-packages"; }

    @Override
    public void handle(Event event, Context context) {
        try (var statement = context.getConnection().prepareStatement(
                "SELECT COUNT(*) FROM menu_packages WHERE name IN ('Package A', 'Package B', 'Package C')");
             var rows = statement.executeQuery()) {
            if (rows.next() && rows.getLong(1) > 0) {
                throw new FlywayException("Legacy migration V5 would delete existing packages and detach booking history. "
                        + "Migration stopped to preserve records. Review the existing schema and migration history on a database copy.");
            }
        } catch (SQLException error) {
            throw new FlywayException("Cannot check existing records before legacy migration V5", error);
        }
    }
}
