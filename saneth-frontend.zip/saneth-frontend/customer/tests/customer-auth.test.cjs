const assert = require('node:assert/strict');
const { test } = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../js/customer-auth.js'), 'utf8').replace(/^import[^\n]+\n/, '');
const html = fs.readFileSync(path.join(__dirname, '../customer-login.html'), 'utf8');

function page({ saved, search = '', request } = {}) {
  let now = 1000000, nextTimer = 0;
  const timers = new Map(), storage = new Map(), calls = [], navigations = [];
  if (saved) storage.set('saneth_pending_registration', saved);
  class Element {
    value = ''; hidden = false; disabled = false; readOnly = false; textContent = '';
    listeners = new Map(); attributes = new Map();
    classList = { toggle() {} };
    addEventListener(type, callback) { this.listeners.set(type, callback); }
    setAttribute(key, value) { this.attributes.set(key, value); }
    querySelector() { return this.button ||= new Element(); }
    reportValidity() { return true; }
    async fire(type = 'click') { await this.listeners.get(type)?.({preventDefault() {}, currentTarget: this}); }
  }
  const elements = Object.fromEntries([...html.matchAll(/\bid="([^"]+)"/g)].map(match => [match[1], new Element()]));
  for (const id of ['registerForm', 'verifyForm', 'verifiedStep', 'message']) elements[id].hidden = true;
  elements.heading.textContent = 'Welcome Back';
  const setTimer = (callback, delay, interval = false) => {
    const id = ++nextTimer;
    timers.set(id, {callback, at: now + delay, interval: interval ? delay : 0});
    return id;
  };
  vm.runInNewContext(source, {
    document: {getElementById: id => elements[id], querySelectorAll: () => []},
    sessionStorage: {getItem: key => storage.get(key) || null, setItem: (key, value) => storage.set(key, value), removeItem: key => storage.delete(key)},
    window: {location: {search, replace: url => navigations.push(['replace', url]), assign: url => navigations.push(['assign', url])}},
    Date: class extends Date { static now() { return now; } }, URLSearchParams,
    setTimeout: (callback, delay) => setTimer(callback, delay), clearTimeout: id => timers.delete(id),
    setInterval: (callback, delay) => setTimer(callback, delay, true), clearInterval: id => timers.delete(id),
    apiRequest: async (url, options) => {
      calls.push({url, body: options?.body && JSON.parse(options.body)});
      if (request) return request(url, options);
      if (url.endsWith('/register')) return {notificationId: 'notification-1'};
      if (url.endsWith('/resend')) return {notificationId: 'notification-2', message: 'New code queued.'};
      if (url.endsWith('/verify')) return {verificationStatus: 'VERIFIED'};
      return {status: 'SMTP_ACCEPTED', message: 'Email accepted by SMTP.'};
    }
  });
  return {
    elements, calls, navigations, storage,
    async signup() {
      Object.assign(elements.firstName, {value: 'Test'}); elements.lastName.value = 'Customer';
      elements.registerEmail.value = 'Customer@gmail.com';
      elements.registerPassword.value = elements.confirmPassword.value = 'SecretPassword123';
      await elements.registerForm.fire('submit');
    },
    async advance(ms) {
      const end = now + ms;
      while (true) {
        const entry = [...timers].filter(([, timer]) => timer.at <= end).sort((a, b) => a[1].at - b[1].at)[0];
        if (!entry) break;
        const [id, timer] = entry; now = timer.at;
        if (timer.interval) timer.at += timer.interval; else timers.delete(id);
        timer.callback();
        for (let i = 0; i < 5; i++) await Promise.resolve();
      }
      now = end;
    }
  };
}

test('signup advances to OTP once, retains names/email and recovers progress after refresh without credentials', async () => {
  const p = page(); await p.signup();
  assert.equal(p.elements.verifyForm.hidden, false);
  assert.equal(p.elements.registerForm.hidden, true);
  assert.equal(p.elements.verifyEmail.value, 'customer@gmail.com');
  assert.equal(p.elements.verifyEmail.readOnly, true);
  assert.equal(p.elements.registerTab.attributes.get('aria-pressed'), 'true');
  assert.equal(p.elements.loginTab.attributes.get('aria-pressed'), 'false');
  assert.match(p.elements.verificationInstructions.textContent, /customer@gmail.com/);
  assert.match(p.elements.message.textContent, /Registration successful!/);
  assert.equal(p.elements.firstName.value, 'Test');
  assert.equal(p.elements.lastName.value, 'Customer');
  assert.equal(p.elements.registerPassword.value, '');
  const saved = p.storage.get('saneth_pending_registration');
  assert.doesNotMatch(saved, /SecretPassword|password|verificationCode/);
  const refreshed = page({saved});
  assert.equal(refreshed.elements.verifyForm.hidden, false);
  assert.equal(refreshed.elements.firstName.value, 'Test');
  assert.equal(refreshed.elements.registerEmail.value, 'customer@gmail.com');
  assert.equal(refreshed.elements.resendCode.disabled, true);
  assert.equal(refreshed.elements.registerTab.attributes.get('aria-pressed'), 'true');
  await refreshed.elements.loginTab.fire();
  assert.equal(refreshed.elements.loginTab.attributes.get('aria-pressed'), 'true');
  await refreshed.elements.registerTab.fire();
  assert.equal(refreshed.elements.verifyForm.hidden, false);
  assert.equal(refreshed.elements.registerTab.attributes.get('aria-pressed'), 'true');
  assert.equal(refreshed.calls.filter(call => call.url.endsWith('/register')).length, 0);
});

test('invalid or expired OTP stays on verification, with no success redirect or login', async () => {
  const p = page({request: async url => {
    if (url.endsWith('/register')) return {notificationId: 'notification-1'};
    if (url.endsWith('/verify')) throw new Error('Invalid or expired code.');
    return {status: 'SMTP_ACCEPTED', message: 'Accepted'};
  }});
  await p.signup(); p.elements.verificationCode.value = '999999';
  await p.elements.verifyForm.fire('submit');
  assert.equal(p.elements.verifyForm.hidden, false);
  assert.equal(p.elements.verifiedStep.hidden, true);
  assert.match(p.elements.message.textContent, /Invalid or expired/);
  await p.advance(3000);
  assert.deepEqual(p.navigations, []);
  assert.equal(p.storage.has('saneth_customer_token'), false);
});

test('successful OTP displays Step 3 for three seconds then redirects once to Sign In without automatic login', async () => {
  const p = page(); await p.signup(); p.elements.verificationCode.value = '123456';
  await p.elements.verifyForm.fire('submit');
  assert.equal(p.elements.verifiedStep.hidden, false);
  assert.equal(p.elements.verifyForm.hidden, true);
  assert.equal(p.elements.heading.textContent, 'Email Verified Successfully!');
  assert.equal(p.elements.registerTab.attributes.get('aria-pressed'), 'true');
  assert.equal(p.elements.verificationCode.value, '');
  assert.equal(p.storage.has('saneth_customer_token'), false);
  assert.equal(p.calls.filter(call => call.url.endsWith('/login')).length, 0);
  await p.advance(2999); assert.deepEqual(p.navigations, []);
  await p.advance(1);
  assert.deepEqual(p.navigations, [['replace', 'customer-login.html?verified=1']]);
  await p.elements.proceedToSignIn.fire();
  assert.equal(p.navigations.length, 1);
  const login = page({saved: p.storage.get('saneth_pending_registration'), search: '?verified=1'});
  assert.equal(login.elements.loginForm.hidden, false);
  assert.equal(login.elements.registerForm.hidden, true);
  assert.equal(login.elements.verifiedStep.hidden, true);
  assert.equal(login.elements.loginEmail.value, 'customer@gmail.com');
  assert.equal(login.storage.has('saneth_pending_registration'), false);
});

test('Proceed to Sign In works immediately and cancels the scheduled redirect', async () => {
  const p = page(); await p.signup(); p.elements.verificationCode.value = '123456';
  await p.elements.verifyForm.fire('submit');
  await p.elements.proceedToSignIn.fire(); await p.advance(5000);
  assert.equal(p.navigations.length, 1);
});

test('resend follows server cooldown, preserves the account and never re-registers', async () => {
  let resends = 0;
  const p = page({request: async url => {
    if (url.endsWith('/register')) return {notificationId: 'notification-1'};
    if (url.endsWith('/resend')) {
      if (++resends === 1) throw Object.assign(new Error('Too many requests.'), {retryAfterSeconds: 900});
      return {notificationId: 'notification-2', message: 'New code queued.'};
    }
    return {status: 'SMTP_ACCEPTED', message: 'Accepted'};
  }});
  await p.signup(); await p.advance(60000);
  assert.equal(p.elements.resendCode.disabled, false);
  await p.elements.resendCode.fire();
  assert.equal(p.elements.resendCode.disabled, true);
  assert.match(p.elements.resendCode.textContent, /900s/);
  await p.advance(900000);
  assert.equal(p.elements.resendCode.disabled, false);
  await p.elements.resendCode.fire();
  assert.equal(JSON.parse(p.storage.get('saneth_pending_registration')).notificationId, 'notification-2');
  assert.equal(p.calls.filter(call => call.url.endsWith('/register')).length, 1);
});

test('normal Sign In still stores the returned token and opens the existing customer homepage', async () => {
  const p = page({request: async () => ({token: 'customer-test-token', firstName: 'Test'})});
  p.elements.loginEmail.value = 'customer@gmail.com'; p.elements.loginPassword.value = 'SecretPassword123';
  await p.elements.loginForm.fire('submit');
  assert.equal(p.storage.get('saneth_customer_token'), 'customer-test-token');
  assert.deepEqual(p.navigations, [['assign', 'customer-home.html']]);
});
