package com.catering.Saneth.service;

import com.catering.Saneth.model.EmailNotification;
import com.catering.Saneth.repository.EmailNotificationRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import java.time.Instant;
import java.util.*;

@Service @RequiredArgsConstructor
public class NotificationQueue {
    private final EmailNotificationRepo repo;
    private final NotificationCipher cipher;
    private final org.springframework.context.ApplicationEventPublisher events;
    @Value("${saneth.mail.enabled:true}") private boolean enabled;
    public record Status(String id, String kind, String status, int attempts, Instant acceptedAt, String message) {}

    /** Enqueue in the business transaction: rollback removes both record and notification. */
    @Transactional(propagation = Propagation.MANDATORY)
    public String enqueue(String key, String kind, Long bookingId, Long customerId, Instant expiry,
                          String recipient, String subject, String text, String html) {
        var existing = repo.findByEventKey(key);
        if (existing.isPresent()) return existing.get().getId();
        EmailNotification n = new EmailNotification();
        n.setId(UUID.randomUUID().toString()); n.setEventKey(key); n.setKind(kind);
        n.setBookingId(bookingId); n.setCustomerId(customerId); n.setExpiresAt(expiry);
        n.setEncryptedContent(cipher.encrypt(pack(recipient, subject, text, html)));
        repo.save(n);
        events.publishEvent(new NotificationDeliveryListener.Ready(n.getId()));
        return n.getId();
    }
    // Length-prefixed Base64 fields avoid delimiter ambiguity in user-supplied text.
    static String pack(String... fields) {
        return Arrays.stream(fields).map(s -> Base64.getEncoder().encodeToString(s.getBytes(java.nio.charset.StandardCharsets.UTF_8)))
                .collect(java.util.stream.Collectors.joining("."));
    }
    static String[] unpack(String content) {
        return Arrays.stream(content.split("\\.", -1)).map(s -> new String(Base64.getDecoder().decode(s), java.nio.charset.StandardCharsets.UTF_8)).toArray(String[]::new);
    }
    @Transactional(propagation = Propagation.MANDATORY)
    public void cancelOtp(Long customerId) {
        for (var n : repo.findByCustomerIdAndStatusIn(customerId, List.of("QUEUED", "RETRY_PENDING", "SENDING"))) {
            if ("OTP".equals(n.getKind())) { n.setStatus("CANCELLED"); n.setEncryptedContent(null); n.setLeaseToken(null); }
        }
    }
    @Transactional(readOnly = true)
    public Status otpStatus(String id) {
        return view(repo.findById(id).filter(n -> "OTP".equals(n.getKind()))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Notification not found")));
    }
    @Transactional(propagation = Propagation.MANDATORY)
    public void checkOtpLimit(Long customerId) {
        if (repo.countByCustomerIdAndKindAndCreatedAtAfter(customerId, "OTP", Instant.now().minusSeconds(900)) >= 5)
            throw new com.catering.Saneth.exception.RateLimitException(
                    "Too many verification emails. Please try again in 15 minutes.", 900);
    }
    @Transactional(readOnly = true)
    public List<Status> bookingStatus(Long id) { return repo.findByBookingIdOrderByCreatedAtDesc(id).stream().map(this::view).toList(); }
    @Transactional(readOnly = true)
    public boolean accepted(String key) { return repo.findByEventKey(key).map(n -> "SMTP_ACCEPTED".equals(n.getStatus())).orElse(false); }
    @Transactional
    public void retryBookingConfirmation(Long bookingId) {
        repo.findByEventKey("CONFIRMATION:" + bookingId).ifPresent(n -> retry(n.getId()));
    }
    @Transactional
    public Status retry(String id) {
        var n = repo.lock(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Notification not found"));
        if ("OTP".equals(n.getKind())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Request a new verification code through the registration page.");
        if (List.of("FAILED", "RETRY_PENDING").contains(n.getStatus())) {
            n.setStatus("QUEUED"); n.setAttempts(0); n.setLastError(null); n.setNextAttemptAt(Instant.now());
            events.publishEvent(new NotificationDeliveryListener.Ready(n.getId()));
        }
        return view(n);
    }
    private Status view(EmailNotification n) {
        String status = !enabled && List.of("QUEUED", "RETRY_PENDING").contains(n.getStatus()) ? "DISABLED" : n.getStatus();
        String message = switch (status) {
            case "SMTP_ACCEPTED" -> switch (n.getKind()) {
                case "OTP" -> "Registration OTP sent successfully; accepted by Gmail SMTP. Inbox delivery is not confirmed.";
                case "CONFIRMATION" -> "Booking confirmation email sent; accepted by Gmail SMTP. Inbox delivery is not confirmed.";
                case "PAYMENT_RECEIPT" -> "Payment receipt sent to email; accepted by Gmail SMTP. Inbox delivery is not confirmed.";
                default -> "Booking acknowledgement accepted by Gmail SMTP. Inbox delivery is not confirmed.";
            };
            case "RETRY_PENDING" -> "Email delivery failed and is pending automatic retry. Your saved information is safe.";
            case "FAILED" -> "Email delivery failed after repeated attempts. Contact Saneth Catering.";
            case "EXPIRED", "CANCELLED" -> "Verification email expired or was replaced. Request another code.";
            case "DISABLED" -> "Email delivery is disabled; notification remains queued.";
            default -> "Email is queued for sending. SMTP acceptance is pending.";
        };
        return new Status(n.getId(), n.getKind(), status, n.getAttempts(), n.getAcceptedAt(), message);
    }
}
