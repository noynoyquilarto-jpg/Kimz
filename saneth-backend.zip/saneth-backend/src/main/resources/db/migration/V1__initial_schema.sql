CREATE TABLE IF NOT EXISTS admins (
    id BIGINT NOT NULL AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(255),
    created_at DATETIME(6),
    updated_at DATETIME(6),
    PRIMARY KEY (id),
    UNIQUE KEY uk_admins_email (email)
);

CREATE TABLE IF NOT EXISTS menu_items (
    id BIGINT NOT NULL AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(255),
    description VARCHAR(255),
    image_url VARCHAR(255),
    available BIT,
    created_at DATETIME(6),
    updated_at DATETIME(6),
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS menu_packages (
    id BIGINT NOT NULL AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    description VARCHAR(255),
    image_url VARCHAR(255),
    package_price DOUBLE NOT NULL,
    good_for_pax INT NOT NULL,
    available BIT,
    created_at DATETIME(6),
    updated_at DATETIME(6),
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS menu_package_items (
    menu_package_id BIGINT NOT NULL,
    menu_item_id BIGINT NOT NULL,
    KEY idx_menu_package_items_package (menu_package_id),
    KEY idx_menu_package_items_item (menu_item_id),
    CONSTRAINT fk_menu_package_items_package FOREIGN KEY (menu_package_id) REFERENCES menu_packages (id),
    CONSTRAINT fk_menu_package_items_item FOREIGN KEY (menu_item_id) REFERENCES menu_items (id)
);

CREATE TABLE IF NOT EXISTS bookings (
    id BIGINT NOT NULL AUTO_INCREMENT,
    booking_reference VARCHAR(255),
    customer_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone_number VARCHAR(255) NOT NULL,
    customer_address VARCHAR(255) NOT NULL,
    event_place VARCHAR(255) NOT NULL,
    event_date DATE NOT NULL,
    event_time TIME(6) NOT NULL,
    event_type VARCHAR(255) NOT NULL,
    number_of_pax INT NOT NULL,
    menu_package_id BIGINT NOT NULL,
    payment_method ENUM('CASH','GCASH','BANK_TRANSFER'),
    down_payment_amount DOUBLE,
    payment_reference_number VARCHAR(255),
    payment_note VARCHAR(255),
    booking_status ENUM('PENDING','CONFIRMED','COMPLETED','CANCELLED','ARCHIVED'),
    payment_status ENUM('NOT_REQUIRED_YET','AWAITING_PAYMENT','DOWN_PAYMENT_CONFIRMED','REJECTED','FULLY_PAID'),
    payment_rejection_reason VARCHAR(255),
    cancellation_reason VARCHAR(255),
    archive_reason VARCHAR(255),
    created_at DATETIME(6),
    updated_at DATETIME(6),
    PRIMARY KEY (id),
    KEY idx_bookings_package (menu_package_id),
    KEY idx_bookings_reference_email (booking_reference, email),
    KEY idx_bookings_event_status (event_date, event_time, booking_status),
    CONSTRAINT fk_bookings_menu_package FOREIGN KEY (menu_package_id) REFERENCES menu_packages (id)
);

CREATE TABLE IF NOT EXISTS feedbacks (
    id BIGINT NOT NULL AUTO_INCREMENT,
    booking_id BIGINT,
    menu_package_id BIGINT,
    customer_name VARCHAR(255),
    email VARCHAR(255),
    rating INT,
    comment VARCHAR(255),
    created_at DATETIME(6),
    PRIMARY KEY (id),
    KEY idx_feedbacks_booking (booking_id),
    KEY idx_feedbacks_package (menu_package_id),
    CONSTRAINT fk_feedbacks_booking FOREIGN KEY (booking_id) REFERENCES bookings (id),
    CONSTRAINT fk_feedbacks_menu_package FOREIGN KEY (menu_package_id) REFERENCES menu_packages (id)
);

CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id BIGINT NOT NULL AUTO_INCREMENT,
    admin_email VARCHAR(255) NOT NULL,
    action VARCHAR(255) NOT NULL,
    target_type VARCHAR(255) NOT NULL,
    target_id VARCHAR(255),
    details VARCHAR(1000),
    created_at DATETIME(6) NOT NULL,
    PRIMARY KEY (id),
    KEY idx_admin_audit_logs_created_at (created_at),
    KEY idx_admin_audit_logs_admin_email (admin_email)
);

