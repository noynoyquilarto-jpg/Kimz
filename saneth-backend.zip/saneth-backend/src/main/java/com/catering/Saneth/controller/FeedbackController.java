package com.catering.Saneth.controller;

import com.catering.Saneth.dto.request.FeedbackRequest;
import com.catering.Saneth.dto.response.FeedbackResponse;
import com.catering.Saneth.service.FeedbackService;
import com.catering.Saneth.service.RateLimitService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class FeedbackController {

    private final FeedbackService feedbackService;
    private final RateLimitService rateLimitService;
    private final com.catering.Saneth.service.AdminAuditLogService auditLogService;

    @org.springframework.transaction.annotation.Transactional
    @PostMapping("/api/feedbacks")
    public FeedbackResponse submitFeedback(@Valid @RequestBody FeedbackRequest request, HttpServletRequest httpRequest) {
        rateLimitService.check(httpRequest, "submit-feedback", 5, java.time.Duration.ofMinutes(10));
        rateLimitService.checkKey("submit-feedback:email:" + request.getEmail(), 3, java.time.Duration.ofHours(1));
        rateLimitService.checkKey("submit-feedback:reference:" + request.getBookingReference(), 3, java.time.Duration.ofHours(1));
        FeedbackResponse response = feedbackService.submitFeedback(request);
        auditLogService.recordForActor(response.getEmail(), "CUSTOMER_FEEDBACK_SUBMITTED", "FEEDBACK", response.getId(),
                "Feedback for booking " + response.getBookingReference() + "; rating: " + response.getRating());
        return response;
    }

    @GetMapping("/api/admin/feedbacks")
    public List<FeedbackResponse> getAllFeedback() {
        return feedbackService.getAllFeedback();
    }

    @GetMapping("/api/admin/feedbacks/{id}")
    public FeedbackResponse getFeedbackById(@PathVariable Long id) {
        return feedbackService.getFeedbackById(id);
    }
}
