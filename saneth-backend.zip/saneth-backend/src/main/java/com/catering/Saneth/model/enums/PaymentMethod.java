package com.catering.Saneth.model.enums;

public enum PaymentMethod {
    CASH,
    GCASH,
    BANK_TRANSFER
}
