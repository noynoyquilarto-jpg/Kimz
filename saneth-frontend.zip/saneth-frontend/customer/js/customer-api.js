import { API_ORIGIN } from '../../js/config.js';
export const API_BASE = API_ORIGIN;
const requestCooldowns = new Map();
function cooldownError(seconds) {
  const error = new Error(`Too many requests. Please wait ${seconds} seconds before trying again.`);
  error.retryAfterSeconds = seconds;
  return error;
}

export async function apiRequest(path, options = {}) {
  const key = `${options.method || 'GET'}:${path}`;
  const remaining = Math.ceil(((requestCooldowns.get(key) || 0) - Date.now()) / 1000);
  if (remaining > 0) throw cooldownError(remaining);
  let response;
  try {
    response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      }
    });
  } catch (error) {
    if (error.name === 'AbortError') throw error;
    throw new Error('Cannot connect to the booking server. Check your connection and try again shortly.');
  }

  let data = null;
  const text = await response.text();

  if (text) {
    try { data = JSON.parse(text); }
    catch { data = text; }
  }

  if (!response.ok) {
    if (response.status === 403 && path.startsWith('/api/customer/auth/') && !data?.message) {
      throw new Error('Customer sign-in is unavailable on the running server. Restart the updated backend and try again.');
    }
    if (response.status === 429) {
      const seconds = Math.max(1, Number(data?.retryAfterSeconds) || Number(response.headers.get('Retry-After')) || 60);
      requestCooldowns.set(key, Date.now() + seconds * 1000);
      throw cooldownError(seconds);
    }
    const message = typeof data === 'string'
      ? data
      : data?.message || (data?.messages ? Object.values(data.messages).join(' ') : '') || data?.error || 'Request failed. Please try again.';
    throw new Error(message);
  }

  return data;
}

export function peso(value) {
  return new Intl.NumberFormat('en-PH', {
    style: 'currency',
    currency: 'PHP'
  }).format(Number(value || 0));
}

export function safe(value) {
  if (value === null || value === undefined || value === '') return 'N/A';
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

export function titleStatus(value) {
  if (!value) return 'N/A';
  return String(value)
    .toLowerCase()
    .replaceAll('_', ' ')
    .replace(/\b\w/g, char => char.toUpperCase());
}

export function badge(value) {
  const text = titleStatus(value);
  let className = 'badge-muted';

  if (['CONFIRMED', 'COMPLETED', 'DOWN_PAYMENT_CONFIRMED', 'FULLY_PAID'].includes(value)) {
    className = 'badge-success';
  }

  if (['PENDING', 'AWAITING_PAYMENT', 'NOT_REQUIRED_YET'].includes(value)) {
    className = 'badge-warning';
  }

  if (['CANCELLED', 'REJECTED'].includes(value)) {
    className = 'badge-danger';
  }

  return `<span class="badge ${className}">${safe(text)}</span>`;
}

export function getQueryParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

export function setResult(element, message, type = 'success') {
  element.className = `result-box show ${type}`;
  element.innerHTML = message;
}

export function clearResult(element) {
  element.className = 'result-box';
  element.innerHTML = '';
}

export function assetUrl(url) {
  if (!url) return '';
  const path = String(url).trim().replace(/\\/g, '/');
  if (path.startsWith('blob:')) return path;
  const upload = path.match(/(?:^|\/)uploads\/(.+)$/i);
  if (upload) return new URL('/uploads/' + upload[1], API_BASE).href;
  if (/^https?:\/\//i.test(path)) return path;
  return new URL(path.startsWith('/') ? path : '/' + path, API_BASE).href;
}
