package com.catering.Saneth.security;

import com.catering.Saneth.model.Admin;
import com.catering.Saneth.repository.AdminRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AdminSeeder implements CommandLineRunner {

    private final AdminRepo adminRepo;
    private final PasswordEncoder passwordEncoder;

    @Value("${saneth.admin.email}")
    private String adminEmail;

    @Value("${saneth.admin.password}")
    private String adminPassword;

    @Value("${saneth.admin.password.min-length}")
    private int adminPasswordMinLength;

    @Override
    public void run(String... args) {
        validateSeedAdminConfig();

        if (adminRepo.findByEmail(adminEmail).isPresent()) {
            return;
        }

        Admin admin = Admin.builder()
                .name("System admin")
                .email(adminEmail)
                .password(passwordEncoder.encode(adminPassword))
                .role("ADMIN")
                .build();

        adminRepo.save(admin);
    }

    private void validateSeedAdminConfig() {
        if (adminEmail == null || adminEmail.isBlank()) {
            throw new IllegalStateException("SANETH_ADMIN_EMAIL is required.");
        }

        if (adminPassword == null || adminPassword.length() < adminPasswordMinLength) {
            throw new IllegalStateException("SANETH_ADMIN_PASSWORD must be at least " + adminPasswordMinLength + " characters.");
        }

        boolean hasLetter = adminPassword.chars().anyMatch(Character::isLetter);
        boolean hasDigit = adminPassword.chars().anyMatch(Character::isDigit);

        if (!hasLetter || !hasDigit) {
            throw new IllegalStateException("SANETH_ADMIN_PASSWORD must contain letters and numbers.");
        }
    }
}
