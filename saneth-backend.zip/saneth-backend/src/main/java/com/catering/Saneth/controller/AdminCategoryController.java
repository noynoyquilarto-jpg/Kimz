package com.catering.Saneth.controller;

import com.catering.Saneth.dto.request.CategoryRequest;
import com.catering.Saneth.dto.response.CategoryResponse;
import com.catering.Saneth.service.MenuCategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/categories")
@RequiredArgsConstructor
public class AdminCategoryController {

    private final MenuCategoryService menuCategoryService;

    @PostMapping
    public CategoryResponse create(@jakarta.validation.Valid @RequestBody CategoryRequest request){
        return menuCategoryService.create(request);
    }

    @GetMapping
    public List<CategoryResponse> getAll(){
        return menuCategoryService.getAll();
    }

    @PutMapping("/{id}")
    public CategoryResponse update(
            @PathVariable Long id,
            @jakarta.validation.Valid @RequestBody CategoryRequest request){

        return menuCategoryService.update(id, request);

    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id){
        menuCategoryService.delete(id);
    }

}