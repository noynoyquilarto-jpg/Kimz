package com.catering.Saneth.controller;

import com.catering.Saneth.dto.request.AdminUpdateBookingRequest;
import com.catering.Saneth.dto.request.CancelBookingRequest;
import com.catering.Saneth.dto.request.ConfirmBookingRequest;
import com.catering.Saneth.dto.request.UpdateBookingStatusRequest;
import com.catering.Saneth.dto.request.UpdatePaymentRequest;
import com.catering.Saneth.dto.response.BookingResponse;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.service.AdminAuditLogService;
import com.catering.Saneth.service.AdminBookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@org.springframework.transaction.annotation.Transactional
@RestController
@RequestMapping("/api/admin/bookings")
@RequiredArgsConstructor
public class AdminBookingController {

    private final AdminBookingService adminBookingService;
    private final AdminAuditLogService adminAuditLogService;

    @GetMapping
    public List<BookingResponse> getAllBookings() {
        return adminBookingService.getAllBookings();
    }

    @GetMapping("/{id}")
    public BookingResponse getBookingById(
            @PathVariable Long id
    ) {
        return adminBookingService.getBookingById(id);
    }

    @PutMapping("/{id}/status")
    public BookingResponse updateBookingStatus(
            @PathVariable Long id,
            @Valid @RequestBody UpdateBookingStatusRequest request
    ) {

        BookingResponse response =
                adminBookingService.updateBookingStatus(
                        id,
                        request.getStatus()
                );

        adminAuditLogService.record(
                "BOOKING_STATUS_UPDATED",
                "BOOKING",
                id,
                "Status set to " + request.getStatus()
        );

        return response;
    }

    // =========================================================
    // CONFIRM
    // =========================================================

    @PostMapping("/{id}/confirmation-email")
    public java.util.Map<String, Object> sendConfirmationEmail(@PathVariable Long id) {
        boolean sent = adminBookingService.sendConfirmationEmail(id);
        if (sent) adminAuditLogService.record("BOOKING_CONFIRMATION_EMAIL_SENT", "BOOKING", id,
                "Confirmation email accepted by configured SMTP server");
        return java.util.Map.of("sent", sent, "message", sent
                ? "Confirmation email accepted by Gmail SMTP. Check the customer's inbox or spam folder."
                : "Confirmation email is queued or pending retry. SMTP acceptance has not been reported. Check notification status before retrying.");
    }

    @PutMapping("/{id}/confirm")
    public BookingResponse confirmBooking(
            @PathVariable Long id,
            @Valid @RequestBody ConfirmBookingRequest request
    ) {

        BookingResponse response =
                adminBookingService.confirmBooking(
                        id,
                        request
                );

        adminAuditLogService.record(
                "BOOKING_CONFIRMED",
                "BOOKING",
                id,
                "Booking confirmed. Quoted price: "
                        + request.getQuotedPrice()
                        + ", required downpayment: "
                        + request.getDownPayment()
        );

        return response;
    }

    // =========================================================
    // ACTUAL PAYMENT
    // =========================================================

    @PutMapping("/{id}/payment")
    public BookingResponse updatePayment(
            @PathVariable Long id,
            @Valid @RequestBody UpdatePaymentRequest request
    ) {

        BookingResponse response =
                adminBookingService.updatePayment(
                        id,
                        request
                );

        adminAuditLogService.record(
                "BOOKING_PAYMENT_UPDATED",
                "BOOKING",
                id,
                "Actual downpayment paid updated to "
                        + request.getDownPaymentAmount()
        );

        return response;
    }

    // =========================================================
    // COMPLETE
    // =========================================================

    @PutMapping("/{id}/complete")
    public BookingResponse completeBooking(
            @PathVariable Long id
    ) {

        BookingResponse response =
                adminBookingService.completeBooking(id);

        adminAuditLogService.record(
                "BOOKING_COMPLETED",
                "BOOKING",
                id,
                "Booking completed"
        );

        return response;
    }

    // =========================================================
    // CANCEL
    // =========================================================

    @PutMapping("/{id}/cancel")
    public BookingResponse cancelBooking(
            @PathVariable Long id,
            @Valid @RequestBody CancelBookingRequest request
    ) {

        BookingResponse response =
                adminBookingService.cancelBooking(
                        id,
                        request.getReason()
                );

        adminAuditLogService.record(
                "BOOKING_CANCELLED",
                "BOOKING",
                id,
                request.getReason()
        );

        return response;
    }

    // =========================================================
    // EDIT BOOKING DETAILS
    // =========================================================

    @PutMapping("/{bookingId}")
    public BookingResponse updateBooking(
            @PathVariable Long bookingId,
            @Valid @RequestBody AdminUpdateBookingRequest request
    ) {

        BookingResponse response =
                adminBookingService.updateBooking(
                        bookingId,
                        request
                );

        adminAuditLogService.record(
                "BOOKING_UPDATED",
                "BOOKING",
                bookingId,
                request.getAdminNote()
        );

        return response;
    }
}
