package com.catering.Saneth.service;


import com.catering.Saneth.dto.request.RecommendationRequest;
import com.catering.Saneth.dto.response.MostBoughtPackageResponse;
import com.catering.Saneth.dto.response.MustTryPackageResponse;
import com.catering.Saneth.dto.response.RecommendationResponse;
import com.catering.Saneth.model.MenuPackage;
import com.catering.Saneth.repository.BookingRepo;
import com.catering.Saneth.repository.FeedbackRepo;
import com.catering.Saneth.repository.MenuPackageRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class RecommendationService {
    private final MenuPackageRepo menuPackageRepo;
    private final BookingRepo bookingRepo;
    private final FeedbackRepo feedbackRepo;


    public List<RecommendationResponse> generateRecommendation(RecommendationRequest request){
        List<MenuPackage> packages = menuPackageRepo
                .findByAvailableTrueAndPackagePriceLessThanEqualAndGoodForPaxGreaterThanEqual(
                        request.getBudget(), request.getNumberOfPax()
                );

        return packages.stream()
                .sorted(Comparator.comparing(MenuPackage::getPackagePrice))
                .map(menuPackage -> RecommendationResponse.builder()
                        .packageId(menuPackage.getId())
                        .packageName(menuPackage.getName())
                        .description(menuPackage.getDescription())
                        .packagePrice(menuPackage.getPackagePrice())
                        .goodForPax(menuPackage.getGoodForPax())
                        .reason("This package fits the customer's pax and budget.")
                        .build())
                .toList();

    }


    public List<RecommendationResponse> getAvailablePackages(){
        return menuPackageRepo.findAll()
                .stream()
                .filter(menuPackage -> Boolean.TRUE.equals(menuPackage.getAvailable()))
                .map(menuPackage -> RecommendationResponse.builder()
                        .packageId(menuPackage.getId())
                        .packageName(menuPackage.getName())
                        .description(menuPackage.getDescription())
                        .packagePrice(menuPackage.getPackagePrice())
                        .goodForPax(menuPackage.getGoodForPax())
                        .reason("This package is currently available.")
                        .build())
                .toList();

    }

    public List<MostBoughtPackageResponse> getMostBoughtPackages() {
        return bookingRepo.findMostBoughtPackages();
    }

    public List<MustTryPackageResponse> getMustTryPackages() {
        return feedbackRepo.findMustTryPackages();
    }

}
