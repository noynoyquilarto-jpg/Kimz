package com.catering.Saneth.service;

import jakarta.mail.Session;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.MimeMessageHelper;

import java.util.Properties;

import static org.assertj.core.api.Assertions.assertThat;

class MailIdentityTest {
    @Test void restoredSenderReplyToAndFromNameAreAppliedToCustomerEmails() {
        new ApplicationContextRunner().withUserConfiguration(MailIdentity.class)
                .withPropertyValues("SANETH_MAIL_USERNAME=rerazo@usa.edu.ph",
                        "spring.mail.username=${SANETH_MAIL_USERNAME}", "saneth.mail.from=${SANETH_MAIL_USERNAME}",
                        "saneth.mail.reply-to=rerazo@usa.edu.ph", "saneth.mail.from-name=Saneth Catering",
                        "saneth.mail.sender-name=Legacy name")
                .run(context -> {
                    var identity = context.getBean(MailIdentity.class);
                    var message = new MimeMessage(Session.getInstance(new Properties()));
                    var helper = new MimeMessageHelper(message, "UTF-8");
                    helper.setTo("customer@example.invalid"); identity.apply(helper);
                    var from = (InternetAddress) message.getFrom()[0];
                    assertThat(from.getAddress()).isEqualTo("rerazo@usa.edu.ph");
                    assertThat(from.getPersonal()).isEqualTo("Saneth Catering");
                    assertThat(message.getReplyTo()[0].toString()).isEqualTo("rerazo@usa.edu.ph");
                    assertThat(message.getAllRecipients()[0].toString()).isEqualTo("customer@example.invalid");
                });
    }
    @Test void defaultReplyToUsesConfiguredSmtpAccount() {
        new ApplicationContextRunner().withUserConfiguration(MailIdentity.class)
                .withPropertyValues("spring.mail.username=authenticated@gmail.com")
                .run(context -> {
                    var identity = context.getBean(MailIdentity.class);
                    assertThat(identity.from()).isEqualTo("authenticated@gmail.com");
                    assertThat(identity.replyTo()).isEqualTo("authenticated@gmail.com");
                });
    }
    @Test void senderAlwaysUsesAuthenticatedSmtpLoginForBothMessageTypes() {
        new ApplicationContextRunner().withUserConfiguration(MailIdentity.class)
                .withPropertyValues("spring.mail.username=smtp@example.invalid",
                        "saneth.mail.from=sanethcatering@gmail.com",
                        "saneth.mail.reply-to=replies@example.invalid",
                        "saneth.mail.sender-name=Saneth Catering")
                .run(context -> {
                    assertThat(context).hasNotFailed();
                    var identity = context.getBean(MailIdentity.class);
                    var simple = new SimpleMailMessage();
                    simple.setTo("customer@example.invalid");
                    identity.apply(simple);
                    var from = new InternetAddress(simple.getFrom());
                    assertThat(from.getAddress()).isEqualTo("smtp@example.invalid");
                    assertThat(from.getPersonal()).isEqualTo("Saneth Catering");
                    assertThat(simple.getReplyTo()).isEqualTo("replies@example.invalid");
                    assertThat(simple.getTo()).containsExactly("customer@example.invalid");

                    var mime = new MimeMessage(Session.getInstance(new Properties()));
                    var helper = new MimeMessageHelper(mime, "UTF-8");
                    helper.setTo("customer@example.invalid");
                    identity.apply(helper);
                    var mimeFrom = (InternetAddress) mime.getFrom()[0];
                    assertThat(mimeFrom.getAddress()).isEqualTo(from.getAddress());
                    assertThat(mimeFrom.getPersonal()).isEqualTo(from.getPersonal());
                    assertThat(mime.getReplyTo()[0].toString()).isEqualTo(simple.getReplyTo());
                    assertThat(mime.getAllRecipients()[0].toString()).isEqualTo("customer@example.invalid");
                });
    }
}
