package com.catering.Saneth.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class RecommendationResponse {

    private Long packageId;
    private String packageName;
    private String description;
    private Double packagePrice;
    private Integer goodForPax;
    private String reason;
}