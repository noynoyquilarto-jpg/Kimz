import { safe } from './customer-api.js';

export function bookingNotifications(booking) {
  const status = booking.bookingStatus;
  const bookingMessage = booking.bookingStatus === 'PENDING'
    ? 'Your booking has been received and is awaiting admin review.'
    : 'Your current booking details are shown below.';
  const confirmation = status === 'CONFIRMED' || status === 'COMPLETED'
    ? 'Your booking is confirmed. Check your email for the confirmation details.'
    : status === 'CANCELLED' ? 'This booking is cancelled and is no longer active.'
    : status === 'ARCHIVED' ? 'This booking has been archived. Contact the admin for assistance.'
    : 'Your booking is awaiting admin confirmation.';
  const payment = {
    NOT_REQUIRED_YET: 'Payment is not required yet. Wait for confirmation and payment instructions.',
    AWAITING_PAYMENT: 'Follow the emailed payment instructions and submit your proof for verification.',
    DOWN_PAYMENT_CONFIRMED: 'Your down payment has been verified. Review your remaining balance below.',
    PARTIALLY_PAID: 'Your partial payment has been recorded. Review your remaining balance below.',
    REJECTED: 'Your payment was rejected. Contact the admin to check the details.',
    FULLY_PAID: 'Your full payment has been recorded.'
  }[booking.paymentStatus] || 'Contact the admin for your payment status.';
  return `<section class="booking-notifications" aria-label="Customer booking notifications">
    <h3>Alert notifications</h3><p>For: Customer · ${safe(booking.bookingReference)}</p>
    <p><strong>Booking update:</strong> ${safe(bookingMessage)}</p>
    <p><strong>Payment update:</strong> ${safe(status === 'CANCELLED' ? 'Do not send further payment for this cancelled booking. Contact the admin about any recorded payment or refund.' : payment)}</p>
    <p><strong>Confirmation update:</strong> ${safe(confirmation)}</p>
    ${(booking.emailNotifications || []).map(n => `<p><strong>Email update:</strong> ${safe(n.message)}</p>`).join('')}
    ${status === 'CANCELLED' ? '<p><strong>Cancellation update:</strong> Your booking has been cancelled. Contact the admin for assistance.</p>' : ''}
    <p>Track your booking again to refresh.</p>
  </section>`;
}
