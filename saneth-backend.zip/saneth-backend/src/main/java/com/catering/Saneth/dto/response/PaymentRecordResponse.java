package com.catering.Saneth.dto.response;

import com.catering.Saneth.model.enums.PaymentMethod;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
public class PaymentRecordResponse {
    private Long id;
    private Double amount;
    private PaymentMethod paymentMethod;
    private String paymentReferenceNumber;
    private String note;
    private LocalDateTime createdAt;
    private String verificationStatus;
    private LocalDateTime verifiedAt;
}
