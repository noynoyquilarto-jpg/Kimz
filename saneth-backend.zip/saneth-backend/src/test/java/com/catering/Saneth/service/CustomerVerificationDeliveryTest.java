package com.catering.Saneth.service;
import com.catering.Saneth.model.Customer;
import com.catering.Saneth.repository.CustomerRepo;
import org.junit.jupiter.api.Test;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import java.time.Instant;
import static org.assertj.core.api.Assertions.*;
import static org.mockito.Mockito.*;

class CustomerVerificationDeliveryTest {
    @Test void debugRequestDescriptionsDoNotExposeOtpOrPasswords() {
        var request = new com.catering.Saneth.controller.CustomerAuthController.VerifyRequest("customer@example.invalid", "123456");
        assertThat(request.toString()).doesNotContain("123456");
        assertThat(new com.catering.Saneth.controller.CustomerAuthController.LoginRequest("customer@example.invalid", "Secret123").toString()).doesNotContain("Secret123");
    }
    @Test void otpIsSixDigitsHashedAndExpiresInFiveMinutes() {
        var repo = mock(CustomerRepo.class); var email = mock(EmailService.class); var queue = mock(NotificationQueue.class);
        var encoder = new BCryptPasswordEncoder();
        var service = new CustomerVerificationService(repo, encoder, email, queue);
        var customer = new Customer(); customer.setId(1L); customer.setEmail("customer@example.invalid");
        var before = Instant.now();
        service.register(customer);
        var code = org.mockito.ArgumentCaptor.forClass(String.class);
        verify(email).sendOtp(eq(customer), code.capture());
        assertThat(code.getValue()).matches("[0-9]{6}");
        assertThat(encoder.matches(code.getValue(), customer.getVerificationHash())).isTrue();
        assertThat(customer.getVerificationExpiresAt()).isBetween(before.plusSeconds(300), Instant.now().plusSeconds(300));
        assertThat(customer.getVerificationAttempts()).isZero();
        verify(queue).cancelOtp(1L);
    }
}
