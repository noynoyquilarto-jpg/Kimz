// Keep dialogs in order when several requests fail at once.
let pending = Promise.resolve();
let decisionPending = false;

function showDialog(message, { kind = 'alert', title = 'Saneth Catering' } = {}) {
  const next = pending.then(() => new Promise(resolve => {
    const previousFocus = document.activeElement;
    const dialog = document.createElement('dialog');
    dialog.className = 'saneth-dialog';
    dialog.setAttribute('aria-labelledby', 'sanethDialogTitle');
    dialog.setAttribute('aria-describedby', 'sanethDialogMessage');
    dialog.innerHTML = `<form method="dialog">
      <h2 id="sanethDialogTitle"></h2><p id="sanethDialogMessage"></p>
      ${kind === 'prompt' ? '<label for="sanethDialogInput">Reason</label><textarea id="sanethDialogInput" rows="3" maxlength="500" required></textarea>' : ''}
      <div class="saneth-dialog-actions">
        ${kind === 'alert' ? '' : '<button type="button" data-cancel>Cancel</button>'}
        <button type="submit" value="accept">${kind === 'alert' ? 'OK' : 'Continue'}</button>
      </div></form>`;
    dialog.querySelector('h2').textContent = title;
    dialog.querySelector('p').textContent = String(message ?? '');
    const input = dialog.querySelector('textarea');
    dialog.querySelector('[data-cancel]')?.addEventListener('click', () => dialog.close('cancel'));
    dialog.querySelector('form').addEventListener('submit', event => {
      if (input && !input.value.trim()) { event.preventDefault(); input.focus(); }
    });
    dialog.addEventListener('close', () => {
      const accepted = dialog.returnValue === 'accept';
      const result = kind === 'prompt' ? (accepted ? input.value.trim() : null) : accepted;
      dialog.remove();
      previousFocus?.focus();
      resolve(result);
    }, { once: true });
    document.body.append(dialog);
    dialog.showModal();
    // Focus Cancel for decisions, so pressing Enter never accepts accidentally.
    (input || dialog.querySelector('[data-cancel]') || dialog.querySelector('button')).focus();
  }));
  pending = next.catch(() => {});
  return next;
}

export function showAlert(message) { return showDialog(message); }
async function decide(message, kind, title) {
  // Native browser dialogs blocked repeated clicks; preserve that protection.
  if (decisionPending) return kind === 'prompt' ? null : false;
  decisionPending = true;
  try { return await showDialog(message, { kind, title }); }
  finally { decisionPending = false; }
}
export function showConfirm(message) { return decide(message, 'confirm', 'Please confirm'); }
export function showPrompt(message) { return decide(message, 'prompt', 'Please provide a reason'); }
