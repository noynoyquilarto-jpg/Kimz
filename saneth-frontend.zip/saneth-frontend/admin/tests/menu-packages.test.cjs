// Run with: node saneth-admin-frontend/tests/menu-packages.test.cjs
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../js/menu-packages.js'), 'utf8')
  .replace(/^import .*;\r?\n/gm, '').replace(/^loadPage\(\);/m, '');
const elements = new Map();
function element(id) {
  if (!elements.has(id)) elements.set(id, {
    value: '', textContent: '', innerHTML: '', disabled: false, files: [],
    addEventListener() {}, querySelectorAll: () => [], reset() {}
  });
  return elements.get(id);
}
const requests = [];
const record = { id: 1, name: 'Package A', imageUrl: '/a.jpg', packagePrice: 35000, goodForPax: 100 };
let failure = false;
let confirmed = true;
let missingItems = false;
const storage = new Map();
const context = vm.createContext({
  API_BASE_URL: 'http://test.invalid',
  localStorage: {
    getItem: key => storage.get(key) ?? null,
    setItem: (key, value) => storage.set(key, value),
    removeItem: key => storage.delete(key)
  },
  document: { getElementById: element, querySelectorAll: () => [] },
  requireAuth() {}, initLayout() {}, safe: String, peso: String, badge: String,
  assetUrl: value => value, window: { scrollTo() {} }, confirm: () => confirmed,
  apiRequest: async (url, options) => {
    requests.push({ url, options });
    if (options?.method === 'DELETE' && failure) throw Error('Delete rejected');
    if (url.endsWith('/items')) {
      if (missingItems) throw Error('Endpoint unavailable');
      return [{ id: 7, name: 'Rice' }];
    }
    return url === '/api/menu-packages' ? [record] : record;
  }
});
vm.runInContext(source, context);
vm.runInContext('menuItemsLoaded = true; menuItems = [{id:7,name:"Rice"}];', context);
const button = { disabled: false, closest: () => ({ querySelector: () => element('cardStatus') }) };
(async () => {
  assert.equal(context.packageMenuCategory({ name: 'KBL' }), 'Soup');
  assert.equal(context.packageMenuCategory({ name: 'Chicken Macaroni Salad' }), 'Salad and Appetizer');
  assert.equal(context.packageMenuCategory({ name: 'Fruit Macaroni Salad' }), 'Dessert');
  assert.equal(context.packageMenuCategory({ name: 'Pancit Canton' }), 'Pasta and Noodles');
  assert.equal(context.packageMenuCategory({ name: 'Chicken Cordon Bleu' }), 'Main Courses');
  assert.equal(context.packageMenuCategory({ name: 'Four Seasons' }), 'Drinks');
  assert.equal(context.packageMenuCategory({ name: 'Rice' }), 'Rice');
  assert.equal(context.packageMenuCategory({ name: 'Special', categoryName: 'Dessert' }), 'Dessert');
  await context.editPackage(1, button);
  assert.equal(element('packageId').value, 1);
  assert.match(element('formMessage').textContent, /Select the menu items/);
  record.items = [{ id: 7, name: 'Rice' }];
  assert.match(context.packageItemsText(record), /<strong>Rice<\/strong>/);
  assert.match(context.packageItemsText(record), /<li>Rice<\/li>/);
  await context.editPackage(1, button);
  assert.match(element('menuItemsCheckboxes').innerHTML, /checked/);
  failure = true;
  await context.deletePackage(1, button);
  assert.equal(element('cardStatus').textContent, 'Delete rejected');
  assert.equal(button.disabled, false);
  confirmed = false;
  const count = requests.length;
  await context.deletePackage(1, button);
  assert.equal(requests.length, count);
  confirmed = true;
  failure = false;
  await context.deletePackage(1, button);
  assert.equal(element('packageId').value, '');
  assert.match(element('formMessage').textContent, /Package deleted/);
  delete record.items;
  await context.loadPackages();
  assert.match(element('packagesList').innerHTML, /<li>Rice<\/li>/);
  missingItems = true;
  await context.loadPackages();
  assert.match(element('packagesList').innerHTML, /Available menu options/);
  assert.match(element('packagesList').innerHTML, /<li>Rice<\/li>/);
  context.rememberPackageItems(1, [7]);
  await context.loadPackages();
  assert.match(element('packagesList').innerHTML, /Last saved selections on this browser/);
  assert.doesNotMatch(element('packagesList').innerHTML, /Available menu options/);
  vm.runInContext('packagesById = new Map();', context);
  await context.loadPackages();
  assert.match(element('packagesList').innerHTML, /Last saved selections on this browser/);
  console.log('Package edit and delete checks passed.');
})().catch(error => { console.error(error); process.exitCode = 1; });
