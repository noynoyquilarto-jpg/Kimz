import { apiRequest, safe } from './api.js';

export function initNotifications() {
  if (window.location.pathname.split('/').pop() !== 'bookings.html') return;
  const topbar = document.querySelector('.topbar');
  if (!topbar || document.getElementById('adminNotifications')) return;
  const panel = document.createElement('details');
  panel.id = 'adminNotifications';
  panel.className = 'alert-notifications';
  panel.innerHTML = `<summary>Alert notifications</summary>
    <div class="alert-notifications-body">
      <h2>Booking updates</h2>
      <p>For: Admin · Booking, payment, confirmation, and cancellation updates for bookings. Refresh to see current status.</p>
      <button type="button" class="btn btn-light">Refresh updates</button>
      <div class="alert-notifications-list" role="status" aria-live="polite"></div>
    </div>`;
  topbar.after(panel);
  const list = panel.querySelector('[role="status"]');
  const refresh = panel.querySelector('button');
  let loading = false;
  async function load() {
    if (loading) return;
    loading = true;
    refresh.disabled = true;
    list.textContent = 'Loading updates…';
    try {
      const bookings = await apiRequest('/api/admin/bookings');
      if (!Array.isArray(bookings)) throw new Error('Unable to read booking updates.');
      list.innerHTML = bookings.filter(b => b.bookingStatus !== 'ARCHIVED').map(b => {
        const status = b.bookingStatus;
        const payment = {
          NOT_REQUIRED_YET: 'Payment is not required yet.',
          AWAITING_PAYMENT: 'Awaiting customer payment. Verify proof before recording payment.',
          DOWN_PAYMENT_CONFIRMED: 'Down payment verified. Review the remaining balance.',
          PARTIALLY_PAID: 'Partial payment recorded. A balance remains.',
          REJECTED: 'Payment rejected. Follow up with the customer.',
          FULLY_PAID: 'Full payment recorded.'
        }[b.paymentStatus] || 'Payment status unavailable.';
        const confirmation = status === 'CONFIRMED' || status === 'COMPLETED'
          ? 'Booking confirmed.' : status === 'CANCELLED'
          ? 'This booking is cancelled and is no longer active.' : 'Awaiting your review and confirmation.';
        return `<article><h3>Booking update · ${safe(b.bookingReference)}</h3>
          <p>${safe(b.customerName)} — ${safe(b.bookingStatus === 'PENDING'
            ? 'New booking awaiting your review.'
            : 'View this booking for its current details.')}</p>
          <p><strong>Payment update:</strong> ${safe(status === 'CANCELLED' ? 'Review any recorded payments and refund follow-up for this cancelled booking.' : payment)}</p>
          <p><strong>Confirmation update:</strong> ${safe(confirmation)}</p>
          ${status === 'CANCELLED' ? '<p><strong>Cancellation update:</strong> Booking cancelled. Follow up with the customer if needed.</p>' : ''}
          </article>`;
      }).join('') || '<p>No booking updates available.</p>';
    } catch (error) {
      list.textContent = error.message || 'Unable to load updates. Please try again.';
    } finally {
      loading = false;
      refresh.disabled = false;
    }
  }
  panel.addEventListener('toggle', () => { if (panel.open) load(); });
  refresh.addEventListener('click', load);
}
