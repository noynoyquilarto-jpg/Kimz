package com.catering.Saneth;

import com.catering.Saneth.model.Booking;
import com.catering.Saneth.model.MenuPackage;
import com.catering.Saneth.model.enums.BookingStatus;
import com.catering.Saneth.model.enums.BookingType;
import com.catering.Saneth.repository.BookingRepo;
import com.catering.Saneth.repository.MenuPackageRepo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.LocalTime;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@Transactional
class PackageBookingCountTest {
    @Autowired BookingRepo bookings;
    @Autowired MenuPackageRepo packages;

    @Test
    void countsEveryStatusOnceAndExcludesCustomBookings() {
        var pack = packages.save(MenuPackage.builder().name("Count test package")
                .packagePrice(20000.0).goodForPax(100).available(true).build());
        for (var status : BookingStatus.values()) {
            bookings.save(booking(pack, status));
        }
        bookings.save(booking(null, BookingStatus.PENDING));
        bookings.flush();
        var result = bookings.findMostBoughtPackages().stream()
                .filter(row -> row.getPackageId().equals(pack.getId())).findFirst().orElseThrow();
        assertThat(result.getTotalBookings()).isEqualTo(BookingStatus.values().length);
        bookings.saveAndFlush(booking(pack, BookingStatus.PENDING));
        var updated = bookings.findMostBoughtPackages().stream()
                .filter(row -> row.getPackageId().equals(pack.getId())).findFirst().orElseThrow();
        assertThat(updated.getTotalBookings()).isEqualTo(BookingStatus.values().length + 1);
        assertThat(bookings.findMostBoughtPackages()).allMatch(row -> row.getPackageId() != null);
    }

    private Booking booking(MenuPackage pack, BookingStatus status) {
        return Booking.builder().customerName("Test Customer").email("count@example.invalid")
                .phoneNumber("09123456789").customerAddress("Test address").eventPlace("Test venue")
                .eventDate(LocalDate.now().plusDays(30)).eventTime(LocalTime.NOON).eventType("Birthday")
                .numberOfPax(100).menuPackage(pack).bookingStatus(status)
                .bookingType(pack == null ? BookingType.CUSTOM : BookingType.PACKAGE).build();
    }
}
