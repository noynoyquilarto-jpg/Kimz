package com.catering.Saneth.service;

import com.catering.Saneth.model.Customer;
import com.catering.Saneth.repository.CustomerRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Locale;

@Service @RequiredArgsConstructor
public class CustomerVerificationService {
 private final CustomerRepo repo;
 private final PasswordEncoder encoder;
 private final EmailService emailService;
 private final NotificationQueue notifications;
 private final SecureRandom random = new SecureRandom();



 @Transactional
 public String register(Customer customer) {
  repo.saveAndFlush(customer);
  return send(customer);
 }
 @Transactional
 public String resend(String email) {
  Customer c = repo.lockByEmail(email).orElse(null);
  if(c == null || c.isEmailVerified()) return null;
  if(c.getVerificationSentAt() != null && c.getVerificationSentAt().plusSeconds(60).isAfter(Instant.now()))
   throw new com.catering.Saneth.exception.RateLimitException("Please wait before requesting another code",
     Math.max(1, java.time.Duration.between(Instant.now(), c.getVerificationSentAt().plusSeconds(60)).toSeconds() + 1));
  return send(c);
 }
 private String send(Customer c) {
  notifications.checkOtpLimit(c.getId());
  notifications.cancelOtp(c.getId());
  String code = String.format(Locale.ROOT,"%06d",random.nextInt(1000000));
  c.setVerificationHash(encoder.encode(code));
  c.setVerificationExpiresAt(Instant.now().plusSeconds(300));
  c.setVerificationSentAt(Instant.now());
  c.setVerificationAttempts(0);
  return emailService.sendOtp(c, code);
 }
 @Transactional
 public boolean verify(String email, String code) {
  Customer c = repo.lockByEmail(email).orElse(null);
  if(c == null || c.isEmailVerified() || c.getVerificationHash() == null || c.getVerificationExpiresAt() == null
    || !c.getVerificationExpiresAt().isAfter(Instant.now()) || c.getVerificationAttempts() >= 5) return false;
  c.setVerificationAttempts(c.getVerificationAttempts()+1);
  if(!encoder.matches(code,c.getVerificationHash())) return false;
  c.setEmailVerified(true); c.setVerificationHash(null); c.setVerificationExpiresAt(null);
  notifications.cancelOtp(c.getId());
  return true;
 }
}
