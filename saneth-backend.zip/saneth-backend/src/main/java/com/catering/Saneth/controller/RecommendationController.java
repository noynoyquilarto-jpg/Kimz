package com.catering.Saneth.controller;

import com.catering.Saneth.dto.request.RecommendationRequest;
import com.catering.Saneth.dto.response.RecommendationResponse;
import com.catering.Saneth.service.RateLimitService;
import com.catering.Saneth.service.RecommendationService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/recommendations")
@RequiredArgsConstructor
public class RecommendationController {

    private final RecommendationService recommendationService;
    private final RateLimitService rateLimitService;

    @PostMapping("/generate")
    public List<RecommendationResponse> generateRecommendation(
            @Valid @RequestBody RecommendationRequest request,
            HttpServletRequest httpRequest
    ) {
        rateLimitService.check(httpRequest, "generate-recommendations", 10, java.time.Duration.ofMinutes(10));
        return recommendationService.generateRecommendation(request);
    }

    @GetMapping("/available")
    public List<RecommendationResponse> getAvailablePackages() {
        return recommendationService.getAvailablePackages();
    }

}
