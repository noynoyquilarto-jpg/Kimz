package com.catering.Saneth.service;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

/** Wake the durable queue only after the entire business transaction commits. */
@Component
public class NotificationDeliveryListener {
    public record Ready(String id) {}
    private final NotificationDispatcher dispatcher;
    private final TaskExecutor executor;
    private final boolean immediate;

    public NotificationDeliveryListener(NotificationDispatcher dispatcher,
            @Qualifier("notificationExecutor") TaskExecutor executor,
            @Value("${saneth.mail.immediate:true}") boolean immediate) {
        this.dispatcher = dispatcher;
        this.executor = executor;
        this.immediate = immediate;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void committed(Ready event) {
        if (!immediate) return;
        try {
            executor.execute(() -> {
                try { dispatcher.deliver(event.id()); }
                catch (RuntimeException error) { deferred(event.id(), error); }
            });
        } catch (RuntimeException error) {
            // A full executor or shutdown must never turn a committed booking into an API failure.
            deferred(event.id(), error);
        }
    }

    private void deferred(String id, RuntimeException error) {
        LoggerFactory.getLogger(getClass()).warn(
                "Notification {} immediate dispatch deferred to scheduled worker ({})",
                id, error.getClass().getSimpleName());
    }
}
