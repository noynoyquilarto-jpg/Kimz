package com.catering.Saneth.dto.request;

import com.catering.Saneth.model.enums.PaymentMethod;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentConfirmRequest {

    @NotNull(message = "Payment method is required")
    private PaymentMethod paymentMethod;

    @NotNull(message = "Down payment amount is required")
    @Positive(message = "Down payment amount must be greater than 0")
    private Double downPaymentAmount;

    @NotBlank(message = "Payment reference number is required")
    private String paymentReferenceNumber;

    private String paymentNote;
}
