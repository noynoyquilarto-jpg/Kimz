package com.catering.Saneth.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.Base64;

/** Protects queued OTPs and customer details at rest; use a stable secret across restarts. */
@Component
public class NotificationCipher {
    private final SecretKeySpec key;
    private final SecureRandom random = new SecureRandom();
    public NotificationCipher(@Value("${saneth.mail.queue-secret:${saneth.jwt.secret}}") String secret) {
        if (secret == null || secret.length() < 32) throw new IllegalStateException("Notification queue secret must contain at least 32 characters");
        try {
            key = new SecretKeySpec(MessageDigest.getInstance("SHA-256").digest(
                    ("saneth-email-v1:" + secret).getBytes(StandardCharsets.UTF_8)), "AES");
        } catch (GeneralSecurityException ex) { throw new IllegalStateException("Notification encryption unavailable"); }
    }
    public String encrypt(String text) {
        try {
            byte[] iv = new byte[12]; random.nextBytes(iv);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, iv));
            return Base64.getEncoder().encodeToString(iv) + "." + Base64.getEncoder().encodeToString(cipher.doFinal(text.getBytes(StandardCharsets.UTF_8)));
        } catch (GeneralSecurityException ex) { throw new IllegalStateException("Cannot encrypt notification"); }
    }
    public String decrypt(String text) {
        try {
            String[] parts = text.split("\\.", 2);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, Base64.getDecoder().decode(parts[0])));
            return new String(cipher.doFinal(Base64.getDecoder().decode(parts[1])), StandardCharsets.UTF_8);
        } catch (GeneralSecurityException | RuntimeException ex) { throw new IllegalStateException("Cannot decrypt notification"); }
    }
}
