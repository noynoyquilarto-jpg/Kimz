package com.catering.Saneth.repository;

import com.catering.Saneth.model.MenuSubCategory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MenuSubCategoryRepo extends JpaRepository<MenuSubCategory, Long> {

    List<MenuSubCategory> findByCategoryId(Long categoryId);

}