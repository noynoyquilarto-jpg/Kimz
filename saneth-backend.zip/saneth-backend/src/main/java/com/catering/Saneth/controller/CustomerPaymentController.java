package com.catering.Saneth.controller;
import com.catering.Saneth.dto.request.PaymentRecordRequest;
import com.catering.Saneth.service.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import java.security.Principal;
import java.util.Map;

@RestController @RequestMapping("/api/customer/bookings") @RequiredArgsConstructor
public class CustomerPaymentController {
    private final PaymentService payments;
    private final RateLimitService limits;
    private final AdminAuditLogService audit;
    @PostMapping("/{reference}/payments") @org.springframework.transaction.annotation.Transactional
    public Map<String, Object> submit(@PathVariable String reference, @Valid @RequestBody PaymentRecordRequest request,
            Principal principal, jakarta.servlet.http.HttpServletRequest http) {
        limits.check(http, "customer-payment", 10, java.time.Duration.ofMinutes(15));
        var record = payments.submitPayment(reference, principal.getName(), request);
        audit.recordForActor(principal.getName(), "PAYMENT_SUBMITTED", "PAYMENT", record.getId(), "Payment details submitted for admin verification");
        return Map.of("message", "Payment submitted for admin verification. A receipt will be emailed after verification.", "payment", record);
    }
}
