package com.catering.Saneth.service;


import com.catering.Saneth.dto.request.MenuPackageRequest;
import com.catering.Saneth.dto.response.MenuItemResponse;
import com.catering.Saneth.dto.response.MenuPackageResponse;
import com.catering.Saneth.model.MenuItem;
import com.catering.Saneth.model.MenuPackage;
import com.catering.Saneth.repository.BookingRepo;
import com.catering.Saneth.repository.FeedbackRepo;
import com.catering.Saneth.repository.MenuPackageRepo;
import com.catering.Saneth.repository.MenuRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@org.springframework.transaction.annotation.Transactional
@RequiredArgsConstructor
public class MenuPackageService {

    private final MenuRepo menuRepo;
    private final MenuPackageRepo packageRepo;
    private final BookingRepo bookingRepo;
    private final FeedbackRepo feedbackRepo;

    @org.springframework.transaction.annotation.Transactional(readOnly = true)
    public List<MenuItemResponse> getPackageItems(Long id) {
        MenuPackage menuPackage = packageRepo.findById(id).orElseThrow(() ->
                new org.springframework.web.server.ResponseStatusException(
                        org.springframework.http.HttpStatus.NOT_FOUND, "Menu package not found."));
        return menuPackage.getItems().stream().map(this::mapMenuItemToResponse).toList();
    }

    public MenuPackageResponse createMenuPackage(MenuPackageRequest request){
        validateImageUrl(request.getImageUrl());

        List<MenuItem> menuItems = menuRepo.findAllById(request.getMenuItemIds());

        if(menuItems.size() != request.getMenuItemIds().size()){
            throw new RuntimeException("One or more menu items were not found!");
        }

        MenuPackage menuPackage = MenuPackage.builder()
                .name(request.getName())
                .description(request.getDescription())
                .imageUrl(request.getImageUrl().trim())
                .packagePrice(request.getPackagePrice())
                .goodForPax(request.getGoodForPax())
                .available(request.getAvailable() != null ? request.getAvailable() : true)
                .items(menuItems)
                .build();

        MenuPackage savedPackage = packageRepo.save(menuPackage);

        return mapToResponse(savedPackage);

    }

    public List<MenuPackageResponse> getAllMenuPackages() {
        return packageRepo.findAllWithItems()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public MenuPackageResponse getMenuPackageById(Long id){
        MenuPackage menuPackage = packageRepo.findWithItemsById(id)
                .orElseThrow(() -> new RuntimeException("Menu Package not found!"));

        return mapToResponse(menuPackage);
    }

    public MenuPackageResponse updateMenuPackage(Long id, MenuPackageRequest request){
        MenuPackage menuPackage = packageRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Menu Package Not Found!"));

        validateImageUrl(request.getImageUrl());

        List<MenuItem> menuItems = menuRepo.findAllById(request.getMenuItemIds());

        if(menuItems.size() != request.getMenuItemIds().size()){
            throw  new RuntimeException("One or more menu items were not found");
        }

        menuPackage.setName(request.getName());
        menuPackage.setDescription(request.getDescription());
        menuPackage.setImageUrl(request.getImageUrl().trim());
        menuPackage.setPackagePrice(request.getPackagePrice());
        menuPackage.setGoodForPax(request.getGoodForPax());
        menuPackage.setAvailable(request.getAvailable() != null ? request.getAvailable() : menuPackage.getAvailable());
        menuPackage.setItems(menuItems);

        MenuPackage updatedPackage = packageRepo.save(menuPackage);

        return mapToResponse(updatedPackage);
    }

    public void deleteMenuPackage(Long id){
        MenuPackage menuPackage = packageRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Menu package not found"));
        bookingRepo.detachMenuPackage(id);
        feedbackRepo.detachMenuPackage(id);
        packageRepo.delete(menuPackage);
    }

    private MenuPackageResponse mapToResponse(MenuPackage menuPackage) {
        return MenuPackageResponse.builder()
                .id(menuPackage.getId())
                .name(menuPackage.getName())
                .description(menuPackage.getDescription())
                .imageUrl(menuPackage.getImageUrl())
                .packagePrice(menuPackage.getPackagePrice())
                .goodForPax(menuPackage.getGoodForPax())
                .available(menuPackage.getAvailable())
                .items(menuPackage.getItems()
                        .stream()
                        .map(this::mapMenuItemToResponse)
                        .toList())
                .build();



    }

    private MenuItemResponse mapMenuItemToResponse(MenuItem item) {
        return MenuItemResponse.builder()
                .id(item.getId())
                .name(item.getName())
                .description(item.getDescription())
                .imageUrl(item.getImageUrl())
                .available(item.getAvailable())
                .categoryId(item.getCategory().getId())
                .categoryName(item.getCategory().getName())
                .subCategoryId(
                        item.getSubCategory() != null
                                ? item.getSubCategory().getId()
                                : null
                )
                .subCategoryName(
                        item.getSubCategory() != null
                                ? item.getSubCategory().getName()
                                : null
                )
                .build();
    }

    private void validateImageUrl(String imageUrl) {
        if (imageUrl == null || imageUrl.isBlank()) {
            throw new RuntimeException("Package image is required.");
        }
    }


}
