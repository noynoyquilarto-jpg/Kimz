package com.catering.Saneth.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class MonthlySalesResponse {
    private String month;
    private Double totalCollected;
}