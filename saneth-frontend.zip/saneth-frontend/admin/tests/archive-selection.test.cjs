const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

function setup(file) {
  const elements = new Map();
  const element = id => {
    if (!elements.has(id)) elements.set(id, {
      innerHTML: '', textContent: '', value: '', disabled: false, dataset: {},
      classList: { contains: () => true, add() {}, remove() {}, toggle() {} },
      listeners: {}, addEventListener(name, handler) { this.listeners[name] = handler; },
      querySelectorAll: () => [],
      showModal() { this.open = true; },
      close() { this.open = false; this.listeners.close?.(); },
      focus() {}, reset() {}
    });
    return elements.get(id);
  };
  const calls = [];
  const context = vm.createContext({
    document: { getElementById: element, querySelectorAll: () => [] },
    requireAuth() {}, initLayout() {}, setInterval() {},
    safe: value => String(value ?? ''), peso: String, badge: String,
    confirm: () => true, prompt: () => 'Finished event',
    apiRequest: async (url, options) => {
      calls.push({ url, options });
      if (url.endsWith('/2') && options) throw new Error('Rejected');
      return [];
    }
  });
  const source = fs.readFileSync(path.join(__dirname, '../js', file), 'utf8')
    .replace(/import\s*\{[\s\S]*?\}\s*from\s*'[^']+';/g, '')
    .replace(/^loadBookings\(true, true\);$/m, '')
    .replace(/^loadArchives\(\);$/m, '');
  vm.runInContext(source, context);
  return { context, element, calls, run: code => vm.runInContext(code, context) };
}

module.exports = (async () => {
  const archives = setup('archives.js');
  archives.run("archivedBookings = [{id: 1, bookingReference: 'A'}, {id: 2, bookingReference: 'B'}]");
  archives.element('selectAllArchives').checked = true;
  archives.element('selectAllArchives').listeners.change();
  assert.equal(archives.run('selectedIds.size'), 2);
  await archives.element('deleteSelectedBtn').listeners.click();
  assert.equal(archives.calls.length, 0, 'Opening delete dialog must not delete');
  assert.equal(archives.element('submitDeleteBooking').disabled, true);
  for (const value of ['', 'delete', ' DELETE ', 'DELET']) {
    archives.element('deleteBookingConfirmation').value = value;
    archives.element('deleteBookingConfirmation').listeners.input();
    assert.equal(archives.element('submitDeleteBooking').disabled, true);
    await archives.element('deleteBookingForm').listeners.submit({ preventDefault() {} });
  }
  assert.equal(archives.calls.length, 0, 'Only exact DELETE authorizes deletion');
  archives.element('cancelDeleteBooking').listeners.click();
  assert.equal(archives.element('deleteBookingDialog').open, false);
  await archives.element('deleteSelectedBtn').listeners.click();
  archives.element('deleteBookingConfirmation').value = 'DELETE';
  archives.element('deleteBookingConfirmation').listeners.input();
  assert.equal(archives.element('submitDeleteBooking').disabled, false);
  const deleting = archives.element('deleteBookingForm').listeners.submit({ preventDefault() {} });
  await archives.element('deleteBookingForm').listeners.submit({ preventDefault() {} });
  await deleting;
  assert.equal(archives.calls.length, 2);
  assert.equal(archives.run('archivedBookings.length'), 1);
  assert.equal(archives.run("selectedIds.has('2')"), true);
  assert.match(archives.element('archiveMessage').textContent, /1 booking.*Could not delete: B: Rejected/);
  assert.equal(archives.element('deleteSelectedBtn').disabled, false);
  assert.equal(archives.element('deleteBookingDialog').open, true, 'Partial failure stays open');
  assert.equal(archives.element('deleteBookingError').hidden, false);
  assert.equal(archives.element('submitDeleteBooking').disabled, true, 'Retry requires typing DELETE again');
  assert.equal(archives.run('pendingDeleteIds.join()'), '2', 'Retry targets only failed deletions');
  archives.context.apiRequest = async (url, options) => { archives.calls.push({ url, options }); return []; };
  archives.element('deleteBookingConfirmation').value = 'DELETE';
  await archives.element('deleteBookingForm').listeners.submit({ preventDefault() {} });
  assert.equal(archives.calls.length, 3);
  assert.equal(archives.calls[2].url, '/api/admin/archives/bookings/2');
  assert.equal(archives.element('deleteBookingDialog').open, false);

  const bookings = setup('bookings.js');
  bookings.run("bookingsCache = [{id: 1, bookingStatus: 'COMPLETED'}, {id: 2, bookingStatus: 'CANCELLED'}, {id: 3, bookingStatus: 'PENDING'}]");
  bookings.element('selectAllBookings').checked = true;
  bookings.element('selectAllBookings').listeners.change();
  assert.equal(bookings.run('selectedArchiveIds.size'), 2);
  assert.equal(bookings.run("selectedArchiveIds.has('3')"), false);
  // Preserve the server's remaining records when refreshing after a partial failure.
  const api = bookings.context.apiRequest;
  bookings.context.apiRequest = async (url, options) => options ? api(url, options) : [
    { id: 2, bookingStatus: 'CANCELLED' }, { id: 3, bookingStatus: 'PENDING' }
  ];
  await bookings.element('archiveSelectedBtn').listeners.click();
  assert.equal(bookings.calls.length, 2);
  assert.equal(bookings.calls[0].options.method, 'PUT');
  assert.equal(JSON.parse(bookings.calls[0].options.body).reason, 'Finished event');
  assert.equal(bookings.run("selectedArchiveIds.has('2')"), true);
  assert.equal(bookings.run('isUpdating'), false);
  assert.match(bookings.element('bookingMessage').textContent, /1 booking.*Could not archive/);
  console.log('PASS: bulk selection eligibility, archive reasons, deletion, partial failures, retry selection, and control recovery.');
})();
